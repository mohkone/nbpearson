# nbpearson relevant AI-assisted outputs — supplementary material

This distribution contains 39 unchanged files selected from the frozen 41-file
content-relevant inventory, plus original software legal notices and disclosure/
verification metadata. Two superseded integrated manuscript texts are excluded.
The current manuscript is a separate editorial artifact, not silently substituted
for an original inventory entry. No private prompts, response histories, author
worksheets, session links, credentials or personal home paths are included.

The original files retain their project-relative layout under `original_outputs/`.
They comprise software/tests/examples and installation/API text, the full A/B/C
tutorial with its synthetic fixture/expected results, eight unchanged figure PDFs,
seven deterministic figure scripts and seven pinned scalar CSVs. The figure PDFs
and scalar observations were not regenerated. Saved scalar observations are
scientific context, not AI-generated experimental data.

This is a record of relevant outputs and known disclosure facts. It is not a
complete transcript, a newly released software version, an installable source
archive or a complete executable reproduction of the biological campaign or all
figures. Existing scripts may depend on original project layout and dependencies
outside this limited selection. Use the separate frozen A/B/C tutorial distribution
for its documented installation procedure; no new tutorial execution occurred.

Inspect `DISCLOSURE_METADATA.json`, `RIGHTS_AND_SCOPE.md` and `FILE_MANIFEST.json`.
The original inventory is identified by its SHA-256; its earlier proposed-only
status is superseded for this selected material by the investigator's authorization
of 17 November 2026. That authorization is not an invented institutional approval
or a licence for third-party data/binaries.

Verify the extracted distribution with standard-library Python 3.10+:

```bash
python3 verify_manifest.py
```

The verifier hashes bytes only and executes no selected scientific software.
Repository URL/DOI and visibility belong in the actual deposit receipt after upload
and independent retrieval verification; no public availability is claimed here.

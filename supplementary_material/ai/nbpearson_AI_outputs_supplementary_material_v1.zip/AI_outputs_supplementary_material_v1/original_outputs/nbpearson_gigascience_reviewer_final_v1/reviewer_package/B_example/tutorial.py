"""Bounded fixed-NB operator tutorial using the existing 16-by-3 fixture."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import svds

from nbpearson import FixedMargins, __version__, build_operator, counts_fingerprint


HERE = Path(__file__).resolve().parent
REPRESENTATIONS = ("interpolated", "interpolated_grouped", "exact_grouped")


def relative_error(actual, reference):
    denominator = float(np.linalg.norm(reference))
    absolute = float(np.linalg.norm(actual - reference))
    if denominator == 0:
        raise ValueError("Zero reference: use an explicit absolute-error contract")
    return absolute / denominator


def compare_recorded(actual, expected, location="output"):
    """Check structure exactly and numeric values to an explicit smoke tolerance."""
    if isinstance(expected, dict):
        assert actual.keys() == expected.keys(), location
        for key in expected:
            compare_recorded(actual[key], expected[key], location + "." + key)
    elif isinstance(expected, list):
        assert isinstance(actual, list) and len(actual) == len(expected), location
        for i, value in enumerate(expected):
            compare_recorded(actual[i], value, location + "[" + str(i) + "]")
    elif isinstance(expected, float):
        np.testing.assert_allclose(actual, expected, rtol=1e-10, atol=2e-10,
                                   err_msg=location)
    else:
        assert actual == expected, location


def run():
    fixture_path = HERE / "fixture" / "counts_csr.json"
    fixture = json.loads(fixture_path.read_text())
    counts = sparse.csr_matrix(
        (np.asarray(fixture["data"], dtype=np.int64),
         np.asarray(fixture["indices"], dtype=np.int32),
         np.asarray(fixture["indptr"], dtype=np.int32)),
        shape=tuple(fixture["shape"]), dtype=np.int64,
    )
    assert __version__ == "0.1.0.dev1"
    assert counts.shape == (16, 3) and counts.nnz == 40
    input_before = tuple(a.copy() for a in (counts.data, counts.indices, counts.indptr))

    # Compute original fixed margins once; every representation receives them.
    depths = np.asarray(counts.sum(axis=1), dtype=np.float64).ravel()
    gene_totals = np.asarray(counts.sum(axis=0), dtype=np.float64).ravel()
    proportions = gene_totals / gene_totals.sum()
    fixed = FixedMargins(depths=depths, proportions=proportions,
                         counts_fingerprint=counts_fingerprint(counts),
                         source="documented 16x3 synthetic fixture; original axes")

    # Independent direct formula: only this tiny fixture is materialized.
    dense_counts = counts.toarray().astype(np.float64)
    mu = depths[:, None] * proportions[None, :]
    residual = np.clip((dense_counts - mu) / np.sqrt(mu + mu * mu / 100.0),
                       -10.0, 10.0)
    direct = residual - residual.mean(axis=0, keepdims=True)
    direct_singular = np.linalg.svd(direct, compute_uv=False)[0]
    v = np.array([1.0, -1.0, 0.5], dtype=np.float64)
    w = np.arange(16, dtype=np.float64)
    V = np.column_stack((v, -v))
    W = np.column_stack((w, np.ones(16, dtype=np.float64)))
    reference_products = (direct @ v, direct.T @ w, direct @ V, direct.T @ W)
    output = {
        "version": __version__, "fixture_sha256": hashlib.sha256(fixture_path.read_bytes()).hexdigest(),
        "shape": list(counts.shape), "nnz": counts.nnz, "dtype_counts": str(counts.dtype),
        "theta": 100.0, "clip": 10.0, "centering": "columns after clipping; no gene scaling",
        "depths": depths.tolist(), "gene_totals": gene_totals.tolist(),
        "proportions": proportions.tolist(), "counts_fingerprint": fixed.counts_fingerprint,
        "direct_singular_value": float(direct_singular), "representations": {},
    }
    diagnostics = {}
    for representation in REPRESENTATIONS:
        options = {} if representation == "exact_grouped" else {"matrix_rtol": 1e-6, "max_nodes": 128}
        result = build_operator(counts, representation=representation, theta=100.0,
                                clip=10.0, margins=fixed,
                                memory_budget_bytes=512 * 2**20, **options)
        operator, info = result.operator, result.diagnostics
        diagnostics[representation] = info
        assert operator.shape == (16, 3) and operator.dtype == np.dtype("float64")
        assert info["margins"]["contract"] == "fixed_binary64_margins"
        assert info["floating_validation"] == "NOT_EVALUATED"
        products = (operator.matvec(v), operator.rmatvec(w),
                    operator.matmat(V), operator.rmatmat(W))
        matrix = operator.matmat(np.eye(3, dtype=np.float64))
        matrix_error = relative_error(matrix, direct)
        product_errors = [relative_error(a, b) for a, b in zip(products, reference_products)]
        assert matrix_error <= 1e-6 and max(product_errors) <= 1e-6
        for actual, reference in zip(products, reference_products):
            np.testing.assert_allclose(actual, reference, rtol=1e-12, atol=2e-10)
        null_absolute = float(np.linalg.norm(operator.rmatvec(np.ones(16))))
        assert null_absolute <= 1e-11

        # nbpearson supplies no SVD algorithm. This explicitly invokes SciPy.
        u, singular, vt = svds(operator, k=1, solver="arpack", tol=1e-10,
                               maxiter=1000,
                               v0=np.random.default_rng(6619).normal(size=3))
        np.testing.assert_allclose(singular[0], direct_singular, rtol=1e-10, atol=1e-11)
        left_absolute = float(np.linalg.norm(direct @ vt.T - u * singular))
        right_absolute = float(np.linalg.norm(direct.T @ u - vt.T * singular))
        triplet = max(left_absolute, right_absolute) / float(np.linalg.norm(singular))
        assert triplet <= 1e-8
        assert np.isfinite(matrix).all() and all(np.isfinite(p).all() for p in products)
        output["representations"][representation] = {
            "shape": list(operator.shape), "dtype": str(operator.dtype),
            "product_shapes": [list(p.shape) for p in products],
            "matvec": products[0].tolist(), "rmatvec": products[1].tolist(),
            "matmat": products[2].tolist(), "rmatmat": products[3].tolist(),
            "matrix_relative_error": matrix_error, "product_relative_errors": product_errors,
            "transpose_constant_absolute_error": null_absolute,
            "singular_value": float(singular[0]),
            "triplet_left_absolute": left_absolute, "triplet_right_absolute": right_absolute,
            "original_target_triplet_residual": triplet,
            "selection_status": info["analytic_selection"]["status"],
            "interpolation_nodes": info["analytic_selection"]["interpolation_nodes"],
            "distinct_depths": info["U"],
            "floating_validation": info["floating_validation"],
            "operator_storage_bytes": info["operator_storage_bytes"],
            "arrays_storage_bytes": info["arrays_storage_bytes"],
            "clipping_counts": info["clipping_counts"],
        }
    for old, new in zip(input_before, (counts.data, counts.indices, counts.indptr)):
        np.testing.assert_array_equal(old, new)
    output["input_unchanged"] = True
    return output, diagnostics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--diagnostics", type=Path)
    parser.add_argument("--expected", type=Path)
    args = parser.parse_args()
    output, diagnostics = run()
    if args.expected:
        compare_recorded(output, json.loads(args.expected.read_text()))
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True, allow_nan=False) + "\n")
    if args.diagnostics:
        args.diagnostics.write_text(json.dumps(diagnostics, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"status": "PASS_THREE_REPRESENTATIONS_FOUR_PRODUCTS_AND_EXTERNAL_SVD",
                      "version": __version__, "shape": [16, 3],
                      "expected_values_checked": args.expected is not None,
                      "floating_validation": "NOT_EVALUATED"}, sort_keys=True))


if __name__ == "__main__":
    main()

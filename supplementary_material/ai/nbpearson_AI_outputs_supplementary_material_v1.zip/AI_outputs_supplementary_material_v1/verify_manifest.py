"""Read-only standard-library file verifier; does not run scientific software."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'FILE_MANIFEST.json').read_text())
errors=[]
for item in manifest['files']:
 p=root/item['path']
 if not p.is_file():errors.append({'path':item['path'],'error':'missing'});continue
 if p.stat().st_size!=item['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
  errors.append({'path':item['path'],'error':'size/hash mismatch'})
expected={x['path'] for x in manifest['files']}|set(manifest['self_exclusions'])
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
if actual!=expected:errors.append({'inventory_difference':sorted(actual.symmetric_difference(expected))})
print(json.dumps({'status':'PASS_FILE_IDENTITIES' if not errors else 'FAIL','checked':len(manifest['files']),'errors':errors,'numerical_execution':False},indent=2))
raise SystemExit(bool(errors))

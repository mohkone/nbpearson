# Rights, scope and exclusions

The investigator authorized dissemination of the relevant selected AI outputs on
17 November 2026, subject to material-specific identity/privacy/third-party rights
checks. The authorization does not imply independent institutional ethics findings,
individual author attestations or retrospective exact model metadata.

Original nbpearson software and its applicable documentation retain their existing
MIT licence, Copyright (c) 2026 Mohamed Kone. Original LICENSE and
THIRD_PARTY_NOTICES.md files accompany both selected software/tutorial units. No
licence text is changed. NumPy/SciPy/BPCells, Python/build environments, third-party
binaries and raw provider matrices are not bundled. Imports or mentions of an
external dependency do not redistribute its implementation.

The author-created figure PDFs, plotting scripts and saved scalar result/context
CSVs are included under the investigator's dissemination authority. Their content
is not third-party raw matrices, donor records or third-party source/binary payloads.
Provider-derived scientific observations retain their factual provenance and are
not attributed to AI generation. This supplement does not assign a blanket MIT,
CC BY or other reuse licence to nonsoftware scientific/manuscript material. Keep
any repository licence description consistent with these material-specific terms.

Excluded: two superseded integrated manuscript/addendum texts; private chats,
private author communications and approval worksheets; credentials/configuration;
personal home paths; third-party raw matrices and withheld biological product/
solution arrays; third-party dependency source/binaries; unverified historical model
labels. Original frozen files are unchanged. No file is redacted and presented as
an original. Privacy decisions remove whole unselected files instead.

Software numerical implementation identities remain evaluated commit
c0f41107f888d69713c8e22e488bf1e7386f8c4d and package 0.1.0.dev1. Public software
release source remains e6ed51e58ddce5f12f39d6a36b59d42f240191ed under tag v0.1.0.
This archive does not modify that release or the existing Zenodo software archive.

"""Read-only wrapper identity check; no scientific code imports."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
m=json.loads((root/'DISTRIBUTION_MANIFEST.json').read_text())
errors=[]
for row in m['files']:
 p=root/row['path']
 if not p.is_file() or p.is_symlink():errors.append({'path':row['path'],'error':'missing or symlink'});continue
 d=p.read_bytes()
 if len(d)!=row['bytes'] or hashlib.sha256(d).hexdigest()!=row['sha256']:errors.append({'path':row['path'],'error':'identity mismatch'})
expected={r['path'] for r in m['files']}|{'DISTRIBUTION_MANIFEST.json'}
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
if actual!=expected:errors.append({'error':'inventory difference','paths':sorted(actual^expected)})
print(json.dumps({'pass':not errors,'files_checked':len(m['files']),'errors':errors,'scope':'Local identity only; no scientific execution or proof of public/reviewer access'},indent=2))
raise SystemExit(bool(errors))

# Évaluation confirmatoire sur données réelles V1

## Décision et portée exécutée

**GO — les nouveaux résultats soutiennent une contribution logicielle délimitée dans les conditions testées.** Cette décision ne porte ni sur une nouveauté acquise, ni sur une supériorité universelle, ni sur l’acceptation d’un article.

Sur 72 pipelines planifiés, **66 ACP sont achevées et vérifiées** : 36 nbpearson, 6 Scanpy et 24 BPCells. **54 satisfont tous les critères finaux observés** : les 36 nbpearson, les 6 Scanpy exécutées et les 12 BPCells slow=TRUE. Les 12 BPCells slow=FALSE convergent et passent les critères de matrice/produits, mais dépassent le seuil de résidus des triplets. Les six absences Scanpy correspondent à deux refus de préflight et quatre répétitions suivantes non lancées, sans OOM ou timeout observé.

Sources chiffrées : [real_accuracy_results.csv](real_accuracy_results.csv), [real_performance_results.csv](real_performance_results.csv), [real_depth_diversity.csv](real_depth_diversity.csv), clés dataset/method/repetition. Les résultats individuels et les 40 temps de produits par pipeline sont conservés. Les [résultats synthétiques historiques](../nbpearson_confirmatory_v1/CONFIRMATORY_REPORT.md) et rev3 ne sont ni relancés ni fusionnés avec cette session. Les répétitions de processus ne sont pas des réplications biologiques.

## Sources, préparation et paramètres

Admission sous [A1 approuvé](../nbpearson_data_recovery_v1/provenance_resolution_v1/approval_a1_v1/APPROVAL_RECEIPT.json), avec provenance externe partielle déclarée :

- PBMC 10k Chromium X : SHA-256 `42a789ff3f92f0e117d1ff4ffcb2fa8edee87dd2a03d83a81502709344a38bf0`, Cell Ranger 6.1.0, source 36601 caractéristiques × 11996 observations.
- Mouse Brain NextGEM : SHA-256 `895365af6c20b7a1dd80604ef19f1f963fc3b3c7738ba1589d49cf64651f62fe`, Cell Ranger 8.0.0, source 33696 × 9684. molecule_info est exclu.

Les fichiers approuvés ont été rehashés avant préparation. Les comptes non négatifs entiers sont sélectionnés selon le [protocole gelé](../nbpearson_confirmatory_v1/CONFIRMATORY_PROTOCOL.md), sans HVG, normalisation ou log1p. La lecture CSC est bornée ; chaque cible est un CSR observations × gènes. Axes, index originaux, exclusions, comptes et marges binary64 propres à chaque cible sont conservés dans inputs_r2 et [REAL_DATA_PREPARATION.json](REAL_DATA_PREPARATION.json). Les exports R ont été contrôlés bit à bit pour n et p ; Scanpy a recalculé les mêmes marges sur cet univers.

| Cible | N | G | nnz | Sparsité | U_d | U_d/N | Nœuds A/B | Entrées plafonnées |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| PBMC petite | 1000 | 1000 | 164880 | 0.835120 | 567 | 0.567000 | 48 | 71 |
| PBMC grande | 9999 | 2000 | 3159138 | 0.842027 | 2354 | 0.235424 | 57 | 66 |
| Mouse petite | 1000 | 1000 | 122789 | 0.877211 | 418 | 0.418000 | 34 | 66 |
| Mouse grande | 9684 | 2000 | 2228468 | 0.884941 | 1391 | 0.143639 | 40 | 78 |

Une seule ligne nulle a été retirée après sélection : PBMC grande, position sélectionnée 7232 et index source 817 (base zéro), sans remplacement. Aucune colonne sélectionnée n’a été retirée. Les caractéristiques nulles avant sélection ne sont pas des exclusions parmi les 1000/2000 gènes retenus. Les tailles petite/grande sont imbriquées par source : **deux ressources distinctes du développement, pas quatre cohortes ni une preuve inter-donneurs**.

theta=100 ; clip=sqrt(N), avant centrage par gène ; variance NB standard ; marges figées identiques entre bras. Pour A/B : matrix_rtol=1e-6, max_nodes=128, 16 premières paires adjacentes disjointes, borne sur N. A=interpolated ; B=interpolated_grouped ; C=exact_grouped, sans approximation d’interpolation mais flottant. Le constructeur conserve NOT_EVALUATED pour sa validation flottante : les statuts ci-dessous proviennent uniquement des comparaisons effectivement exécutées.

## Fidélité, convergence et sous-espaces

La référence utilise la formule directe binary64 en blocs de 256 lignes, moyenne stable et norme centrée en deux passes. Elle n’est pas une vérité en arithmétique réelle. Les quatre ACP directes ont convergé ; leurs triplets 20/21 ont passé le contrôle indépendant de résidus. Tous les gaps autorisent ici l’interprétation des sous-espaces selon la règle gelée.

Maximum par méthode sur les répétitions/cibles exécutées ; angles en radians. Critères : matrice et produits 1e-6, résidus des triplets 1e-8, singulières et angles interprétables 1e-6. Les valeurs absolues et normes figurent dans le CSV et les verification.json.

| Méthode | ACP | Erreur matrice relative max | Erreur produits max | Résidu triplets retenus max | Erreur singulières max | Angle max | Tous critères |
|---|---:|---:|---:|---:|---:|---:|---:|
| interpolated | 12 | 2.14898171e-16 | 2.33309638e-15 | 4.63474761e-15 | 2.30217024e-15 | 8.77796175e-14 | 12/12 |
| interpolated_grouped | 12 | 2.14798482e-16 | 2.44872043e-15 | 5.31727327e-15 | 2.45993083e-15 | 5.2255796e-14 | 12/12 |
| exact_grouped | 12 | 1.56940477e-16 | 2.39848229e-15 | 5.90510844e-15 | 2.95133733e-15 | 2.19286713e-14 | 12/12 |
| scanpy | 6 | 9.91727846e-17 | 8.4815129e-16 | 2.25685714e-15 | 2.51119402e-15 | 6.06163666e-14 | 6/6 |
| BPCells_FALSE | 12 | 5.07263621e-07 | 5.95586463e-07 | 3.72809703e-07 | 2.11125592e-07 | 2.52145968e-06 | 0/12 |
| BPCells_TRUE | 12 | 2.5714393e-15 | 6.07336982e-15 | 5.05125179e-13 | 1.01920482e-14 | 7.92210645e-12 | 12/12 |

Les 36 nbpearson ont une erreur matricielle maximale 2.14898171e-16 et un résidu retenu maximal 5.90510844e-15. Cela reproduit la fidélité sur ces comptes, sans certification flottante universelle ni conclusion sur des matrices presque nulles. Le L évalué en flottant n’est pas un minorant certifié ; la sélection analytique, l’erreur d’opérateur, la résolution SVD et sa troncature demeurent distinctes.

Le mode rapide BPCells n’est **pas hors tolérance matricielle** ici. Ses 12 erreurs de matrice et quatre produits passent 1e-6, comme ses valeurs singulières. Ses 12 résidus de triplets dépassent 1e-8 ; neuf angles dépassent 1e-6 rad et trois, sur Mouse grande, passent. Ses temps restent visibles comme compromis précision–coût, mais ne sont pas classés à précision finale égale.

| Cible | Gap référence 20/21 | Matrice BPCells rapide | Résidu BPCells rapide | Angle maximal rapide (rad) | Critère angle |
|---|---:|---:|---:|---:|---|
| PBMC petite | 0.769860572 | 4.35428531e-07 | 2.48538636e-07 | 2.52145968e-06 | OUTSIDE_TOLERANCE |
| PBMC grande | 1.99649059 | 3.31076053e-07 | 1.51166617e-07 | 1.09225025e-06 | OUTSIDE_TOLERANCE |
| Mouse petite | 0.708903 | 5.07263621e-07 | 3.72809703e-07 | 2.12195128e-06 | OUTSIDE_TOLERANCE |
| Mouse grande | 1.74102325 | 3.85445139e-07 | 1.426711e-07 | 8.89549923e-07 | SATISFIED |

Les huit vérifications matricielles natives R (quatre cibles × deux modes) sont séparées des chronométrages et référencées par les trois répétitions correspondantes. Les produits effectivement sauvegardés et les triplets de chaque pipeline R sont vérifiés individuellement. Seule la dernière sortie de chaque lot de dix produits est sauvegardée, pas les dix tableaux intermédiaires ; les quarante durées individuelles restent disponibles.

## Construction + ACP

Secondes : médiane [minimum, maximum], trois processus neufs par cellule exécutée. Les temps rapides (*) sont hors critères finaux ; un refus de préflight n’est pas un temps infini.

**Réserves de comparabilité :** cette campagne possède un nouvel ordre réel mélangé et gelé ; aucune médiane historique ou synthétique n’est réutilisée. SciPy ARPACK utilise k21/ncv64/tol1e-10/maxiter10000 et un v0 gaussien seed6619 ; Scanpy conserve sklearn ARPACK, tol0 et son départ natif ; BPCells utilise Spectra k=nu=nv=21/ncv64/tol1e-10/maxitr10000 et set.seed(6619), sans v0 partagé avec Python. Les pipelines incluent validation/copies et centrage nécessaires. Python mesure un intervalle global construction+ACP, R somme les deux sous-temps. Les compteurs d’itération ne sont pas forcés égaux. Aucun écart inter-runtime n’est attribué au seul opérateur.

| Cible | A | B | C | Scanpy | BPCells rapide* | BPCells lent |
|---|---|---|---|---|---|---|
| PBMC petite | 0.109008 [0.103105, 0.109954] | 0.104087 [0.102695, 0.108437] | 0.167724 [0.154273, 0.178803] | 0.197671 [0.197619, 0.240007] | 0.223000 [0.220000, 0.239000] | 1.004000 [1.001000, 1.009000] |
| PBMC grande | 0.973818 [0.967567, 1.032645] | 0.976686 [0.913775, 1.008432] | 1.328785 [1.281662, 1.353993] | PRÉFLIGHT — non exécuté | 3.066000 [3.060000, 3.087000] | 14.166000 [14.130000, 14.199000] |
| Mouse petite | 0.068751 [0.065361, 0.070597] | 0.072075 [0.069559, 0.073028] | 0.098933 [0.097062, 0.104905] | 0.185306 [0.179849, 0.191452] | 0.158000 [0.153000, 0.167000] | 0.794000 [0.762000, 0.802000] |
| Mouse grande | 0.746582 [0.710380, 0.759311] | 0.774988 [0.678611, 0.777795] | 0.882104 [0.859039, 1.028137] | PRÉFLIGHT — non exécuté | 1.915000 [1.906000, 1.926000] | 9.583000 [9.568000, 9.605000] |

La médiane B est inférieure à A seulement sur PBMC petite ; elle n’est pas uniformément plus basse. Sur ces quatre cibles, A/B ont les mêmes nombres de produits du solveur, conservés par type et largeur dans le CSV. C est exécutable et fidèle mais son fond U_d×G coûte davantage ici. Les comparaisons temporelles se limitent à ces configurations, trois répétitions et ces runtimes.

## Compression et stockage

Octets permanents exposés par les opérateurs ; les comptes communs, marges, sondes, copies temporaires et espaces SVD restent distincts. La colonne « métadonnées B » comprend groupes, multiplicités, profondeurs distinctes et moyenne de base. Les stockages totaux A/B/C incluent toutes leurs propres composantes, dont C_mean, et ne sont pas des pics RAM.

| Cible | CSR comptes communs | Correction C | Facteur gauche A / B | Métadonnées B | Facteur droit | Table exacte C | Opérateur total A / B / C |
|---|---:|---:|---|---:|---:|---:|---|
| PBMC petite | 1982564 | 1982564 | 384000 / 217728 | 17456 | 384000 | 4536000 | 2758564 / 2609748 / 6551636 |
| PBMC grande | 37949656 | 37949656 | 4559544 / 1073424 | 118112 | 912000 | 37664000 | 43437200 / 40069192 / 75763312 |
| Mouse petite | 1477472 | 1477472 | 272000 / 113696 | 14960 | 272000 | 3344000 | 2029472 / 1886128 / 4852160 |
| Mouse grande | 26780356 | 26780356 | 3098880 / 445120 | 100048 | 640000 | 22256000 | 30535236 / 27981524 / 49168084 |

B réduit le stockage permanent sur les quatre cibles à profondeurs répétées, mais la correction sparse domine une partie du coût total. Cette réduction n’implique pas un gain identique de RSS. L’exact groupé signifie sans interpolation, pas sans arrondis ; sa table pourrait devenir N×G si toutes les profondeurs étaient distinctes. Le stockage natif C++ BPCells n’est pas exposé : la taille de l’enveloppe R n’est jamais présentée comme son stockage total.

## Produits fixes et mémoire de processus

Médiane du temps moyen par appel de chaque lot, en millisecondes ; mêmes sondes, une chauffe puis dix appels après ACP. Les quatre opérations complètes incluent correction et centrage. La finitude est contrôlée hors temps en Python **et R**, conformément à ce protocole ; cela diffère de certains résultats historiques. R utilise proc.time, de résolution plus grossière que perf_counter Python. Les données complètes des six bras restent dans le CSV et products.csv.

| Cible | Représentation | matvec ms | rmatvec ms | matmat8 ms | rmatmat8 ms |
|---|---|---:|---:|---:|---:|
| PBMC petite | A | 0.142093 | 0.192018 | 0.539353 | 0.580857 |
| PBMC petite | B | 0.138011 | 0.186394 | 0.504185 | 0.595355 |
| PBMC grande | A | 2.620106 | 2.757760 | 9.592489 | 8.956448 |
| PBMC grande | B | 3.193539 | 3.259041 | 9.677510 | 9.651429 |
| Mouse petite | A | 0.112780 | 0.156521 | 0.403530 | 0.441769 |
| Mouse petite | B | 0.117949 | 0.160112 | 0.415260 | 0.515599 |
| Mouse grande | A | 1.859837 | 1.945625 | 6.609130 | 6.174183 |
| Mouse grande | B | 1.819672 | 1.885750 | 6.852014 | 7.023905 |

Le produit transposé de largeur 8 de B est plus coûteux que celui de A sur les quatre cibles. Le bénéfice de compression n’établit donc pas un avantage systématique du produit, ni une règle automatique de choix. Le temps pipeline n’est pas divisé par le nombre d’appels pour en déduire un coût unitaire.

Pic RSS **observé**, maximum des trois processus, en Mio (2^20 octets). Frontière commune : lancement → imports → chargement → construction → ACP → produits → export → sortie ; vérification dans un processus distinct. Les baselines de runtime diffèrent et sont consignées. Aucune comparaison RSS/nbytes n’est faite.

| Cible | A | B | C | Scanpy | BPCells rapide | BPCells lent |
|---|---:|---:|---:|---|---:|---:|
| PBMC petite | 90.63 | 90.82 | 96.83 | 305.23 | 260.25 | 260.82 |
| PBMC grande | 227.38 | 228.73 | 244.94 | non exécuté | 419.27 | 419.33 |
| Mouse petite | 88.03 | 88.26 | 93.76 | 303.77 | 254.30 | 254.29 |
| Mouse grande | 185.82 | 186.19 | 198.62 | non exécuté | 369.54 | 369.51 |

## Budgets, préflights et incidents conservés

Un thread numérique et 512 Mio par processus ; watchdog PID principal VmRSS/VmHWM toutes les 50 ms, 300 s pour **tout le processus**, ou reliquat global inférieur. Il ne somme pas les descendants et n’assure pas l’absence de pic transitoire entre échantillons. Aucun arrêt temps/RSS n’a été déclenché. Maximum observé sur tous les enfants nouveaux : 439701504 octets.

Le cumul final est **532.244052 s**, dont 50,19525759114185 s historiques reportées ; pas de remise à zéro. Ce cumul inclut préparation, qualifications, échecs, références, pipelines, vérifications et consolidation/rédaction gardée, dans le plafond 1800 s. Le registre distingue chargement, construction, ACP, produits, export, temps total et vérification. L’installation et les transferts antérieurs restent extérieurs au benchmark.

Scanpy grande a été refusé selon la formule gelée baseline_imports + 6×8NG + 3×CSR_bytes + 64 Mio :

- PBMC grande : baseline après imports 270274560 octets ; estimation 1411136392 octets, supérieure à 536870912.
- Mouse grande : baseline après imports 270401536 octets ; estimation 1347515468 octets, supérieure à 536870912.

Le refus conservateur ne prouve pas qu’une autre politique mémoire empêcherait Scanpy de traiter ces données. Les répétitions suivantes n’ont pas été relancées, aucune durée d’achèvement ou accélération n’est inférée de ces absences.

Deux incidents de plomberie sont conservés **avant toute ACP réelle** : la première préparation a détecté un pool Matrix Market chargé tardivement, dont le respect d’un thread n’était pas établi ; la révision r2 précharge l’extension avant threadpool_limits(1). La première qualification R a échoué à sérialiser la classe simple.list de R.version ; r2 retire cette classe pour le JSON seulement. Scripts, sorties partielles, reçus et temps des échecs sont conservés dans [PREPARATION_HARNESS_AMENDMENT.json](PREPARATION_HARNESS_AMENDMENT.json) et [NATIVE_HARNESS_AMENDMENT.json](NATIVE_HARNESS_AMENDMENT.json). La petite cible PBMC est identique entre les deux préparations pour comptes, marges, axes et sondes. Aucun échec budgétaire n’a été relancé. Une erreur ultérieure du rédacteur de rapport, qui attendait une médiane pour une configuration non exécutée, est conservée dans runs/real_report_writing ; sa révision r2 affiche le préflight sans durée. Les CSV et les critères n’ont pas changé.

Une correction d’unité de centrage R a été intégrée avant sa première exécution : norme des sommes de colonnes, moyenne conservée séparément. Les préflights, le report du budget et les contrôles des sorties sauvegardées sont des corrections de harnais tracées ; aucun cœur numérique ou critère n’a changé. Une clarification documentaire après campagne précise que seul le candidat Scanpy admis matérialise ses petits résidus ; l’oracle reste diffusé. La rédaction initiale est archivée, pas réécrite comme une autre expérience.

## Réponses et recommandation

1. **Fidélité reproduite sur les deux nouvelles ressources : oui, dans les quatre univers fixés.** Les 36 exécutions dev1 satisfont matrice, produits, adjoint, centrage, triplets, valeurs singulières et angles interprétables. Les limites de quasi-nullité, d’arrondis et de norme flottante restent ouvertes hors des régimes observés.
2. **Compression utile pour le stockage : oui, lorsque les profondeurs se répètent ici.** Les U_d/N vont de 0,143639 à 0,567 ; le stockage B est moindre dans les quatre cibles. Le RSS et les coûts de produits/pipeline n’offrent pas un gain uniforme. Aucune règle de sélection automatique n’est proposée.
3. **Contribution logicielle délimitée soutenue : oui.** Le paquet installé fournit une transformation NB fixée avec trois représentations explicites, précision observée et ressources documentées. Les comparateurs officiels sont conservés ; BPCells constitue déjà un calcul implicite pertinent. Les coûts locaux du pipeline sont utiles, sans comparaison à solveur identique ni revendication de première méthode NB implicite.

**Recommandation unique : GO pour cette contribution logicielle délimitée, en conservant toutes ces limites et les résultats défavorables.** Deux sources, tailles imbriquées, provenance partielle acceptée sous A1, trois répétitions, matériel/concurrence non entièrement contrôlés, amendements de harnais et refus conservateurs limitent la généralisation. Aucune généralisation inter-donneurs, qualité biologique, nouveauté mathématique, supériorité générale ou certification flottante ne découle de cette campagne. Aucun manuscrit, paquet, dépôt public ou résultat historique n’a été modifié.

## Traçabilité et environnement

Paquet installé hors src, cinq sources identiques au wheel évalué SHA-256 `6334eb9758d004ba7171b8c430f4b1df9d659ac2327ff152db26905b282238e7`. Python 3.12.3, NumPy 2.5.4, SciPy 1.18.1 et Scanpy 1.12.5 ; R 4.5.3, BPCells 0.3.1, Matrix 1.7.6, jsonlite 2.0.0. Les signatures, threadpools, sessionInfo, build et BLAS/LAPACK enregistrés font foi ; aucune documentation actuelle n’est substituée à ces signatures.

L’état matériel observé avant cette campagne (CPU, mémoire, plateforme) est dans [REAL_DATA_EXECUTION_MANIFEST.json](REAL_DATA_EXECUTION_MANIFEST.json), avec la réserve sur charge concurrente/alimentation/fréquences non contrôlées. Les preuves individuelles résident dans runs/*/receipt.json, pipeline.json, verification.json et les preuves matricielles R. [ledger.json](ledger.json) conserve tous les temps imputés et incidents. Les clichés CONSOLIDATION_INPUT_MANIFEST.json/CONSOLIDATION_INPUT_LEDGER.json fixent les versions lues par le consolidateur avant les ajouts de clôture ; les empreintes de ses sources sont donc vérifiables sans attendre que ces registres évolutifs restent identiques à leur état intermédiaire.

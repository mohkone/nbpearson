# Évaluation réelle confirmatoire V1 — référence au protocole gelé

Cette reprise exécute uniquement la partie réelle du [protocole confirmatoire V1](../nbpearson_confirmatory_v1/CONFIRMATORY_PROTOCOL.md), SHA-256 `2f4377a2a9bcbc0f0531f623fd46d69ed61a301e3de01cad8718dc015c51b35c`. Elle n’en remplace aucune définition scientifique. Les 27 pipelines synthétiques ne sont pas relancés et restent des résultats distincts.

## Admission et conservation

L’approbation [A1](../nbpearson_data_recovery_v1/provenance_resolution_v1/approval_a1_v1/APPROVAL_RECEIPT.json), datée du 14 novembre 2026 UTC, couvre les deux matrices et accepte explicitement l’absence d’URL exacte Mouse. Les empreintes approuvées ont été revérifiées avant tout calcul :

- PBMC : `42a789ff3f92f0e117d1ff4ffcb2fa8edee87dd2a03d83a81502709344a38bf0` ; HDF5 36 601 caractéristiques × 11 996 observations, Cell Ranger 6.1.0.
- Mouse NextGEM : `895365af6c20b7a1dd80604ef19f1f963fc3b3c7738ba1589d49cf64651f62fe` ; HDF5 33 696 × 9 684, Cell Ranger 8.0.0.

L’admission est conforme à l’amendement documentaire, sans authentification cryptographique indépendante de l’origine ni validation rétroactive des transferts. Le fichier molecule_info est exclu. Dev1, son wheel, rev3, V2.1, les archives confirmatoires et les reçus A1 sont conservés ; les empreintes sont dans preservation_before.json.

## Préparation prospective

Pour chaque ressource, ordre des observations par SHA-256 de UTF-8 `NBPEARSON-CONFIRMATORY-V1|` suivi du code-barres exact, égalités départagées par cet identifiant. Deux cibles : les premières min(1 000, disponibles) observations et 1 000 gènes positifs ; puis les premières min(10 000, disponibles) et 2 000 gènes positifs. Les gènes sont explicitement Gene Expression et triés par identifiant stable unique. Leur positivité est établie sur les observations de chaque cible. Retrait des seules marges nulles après sélection, indices conservés et aucun remplacement.

La lecture du CSC source et la construction du CSR observations × gènes sont bornées. La préparation et la référence directe des vérificateurs ne densifient pas globalement les comptes ou résidus. Le chemin officiel Scanpy, reconstruit comme candidat uniquement pour les petites cibles admises, matérialise ses résidus denses ; ce candidat n’est pas l’oracle. Marges binary64 calculées une fois après exclusions : n = CSR.sum(1), t = CSR.sum(0), M = NumPy.sum(t), p = t/M. Chaque cible conserve ses comptes, axes, exclusions, marges, opérandes fixes et empreintes. Les exports R à 17 chiffres sont vérifiés contre les valeurs binary64 figées.

## Paramètres, comparateurs et critères inchangés

NB standard ; theta = 100 ; clip = sqrt(N), avant centrage par gène, sans standardisation. Les trois représentations dev1 sont choisies explicitement ; matrix_rtol = 1e-6, max_nodes = 128 et 16 premières paires adjacentes disjointes sur N pour les interpolants. Le L flottant n’est pas un minorant certifié et le diagnostic de construction reste NOT_EVALUATED sans comparaison exécutée.

Six bras : interpolated, interpolated_grouped, exact_grouped, Scanpy officiel, BPCells slow=FALSE et slow=TRUE. Trois processus neufs par bras/cible admis, soit 72 pipelines planifiés. Le nouvel ordre réel complet est mélangé une seule fois avec Python random.Random(71306).shuffle, puis sauvegardé avant sa première exécution. L’ordre historique synthétique n’est pas réécrit.

SciPy : ARPACK, 21 triplets dont 20 retenus, ncv=64, tol=1e-10, maxiter=10000, vecteur gaussien seed6619. Scanpy conserve son chemin officiel et ses paramètres natifs consignés dans le protocole. BPCells 0.3.1 : Spectra, k=nu=nv=21, ncv=64, tol=1e-10, maxitr=10000, set.seed(6619), min_var=0 et centrage natif explicite. Les solveurs et initialisations inter-runtimes ne sont pas identiques.

Critères : erreurs relatives de matrice et quatre produits ≤1e-6 ; résidus agrégés des triplets ≤1e-8 ; erreur singulière ≤1e-6 ; angles ≤1e-6 rad seulement si gap20/21 > 2×erreur matricielle absolue + maximum des résidus absolus retenus. Cible exactement nulle : relatif indéfini, contrat absolu nommé 1e-12, sans epsilon. Une référence directe non convergée ou non vérifiée entraîne NOT_EVALUATED pour la comparaison spectrale. Convergence, fidélité et troncature restent distinctes.

## Budget et périmètres

Le registre historique contient **50,19525759114185 s** de processus numériques déjà comptées ; elles sont reportées, sans remise à zéro, dans BUDGET_CARRY_FORWARD.json. Le plafond cumulé reste 1 800 s. Préparation, qualifications réelles, échecs, références, pipelines, vérifications et consolidation numérique sont imputés. La rédaction documentaire et le contrôle préalable des empreintes ne sont pas des temps algorithmiques.

Un thread numérique. Watchdog externe dès le lancement jusqu’à la sortie : VmRSS/VmHWM du PID principal toutes les 50 ms, 512 Mio et 300 s par processus, ou le reliquat global s’il est inférieur. L’échantillonnage n’est pas une garantie instantanée et ne somme pas les descendants. Détection, signal et sortie observée sont séparés dans les reçus. Un arrêt bloque les répétitions restantes du même bras/cible ; aucune durée censurée n’est présentée comme achèvement.

Préflights gelés : Scanpy = baseline après imports + 6×8NG + 3×CSR_bytes + 64 Mio ; R = baseline après imports + 4×CSR_bytes + 6×8×256G + 64 Mio + 4×8(N+G)64. L’API dev1 garde sa propre admission. Estimation refusée et dépassement RSS observé sont deux statuts distincts, sans fallback.

Pas d’échauffement du pipeline. Produits après ACP : mêmes sondes gaussiennes normalisées seed71305, un échauffement puis dix appels par direction et largeur 8 ; finitude hors chronométrage dans les deux runtimes. Chargement, construction, ACP, export, processus et vérification restent séparés. Aucun classement n’est construit avec les anciennes sessions rev3 ou synthétiques.

## Qualification et adaptation du harnais avant mesures

Les copies locales du harnais ajoutent les préflights manquants, le report du budget, les phases et reçus d’erreur, la vérification des produits effectivement sauvegardés et le contrôle des triplets de référence avant usage spectral. L’interface de centrage R exprime la norme des sommes de colonnes, avec la norme de leur moyenne séparée. Aucun code de nbpearson ou BPCells, formule cible ou seuil n’est modifié.

Avant la campagne, qualification matrice/produits sur les petites cibles réelles ; les qualifications synthétiques et Decimal déjà réalisées sont seulement référencées. Le mode rapide reste évalué même hors critère numérique. Une vérification matricielle native R par mode/cible est menée séparément et peut servir de preuve commune aux trois répétitions, dont produits et triplets sauvegardés sont vérifiés individuellement. Aucun objet préparé par un vérificateur n’est injecté gratuitement dans une construction chronométrée.

Une référence ACP directe en blocs est tentée une fois par cible, sous le même garde ; ses triplets sont contrôlés indépendamment. Si elle s’arrête, les produits directs restent utilisables pour les contrôles sans présenter une ACP de référence achevée. Toutes les non-exécutions et violations de précision seront conservées.

## Clarification documentaire après exécution

La phrase de préparation ci-dessus précise l’exception Scanpy déjà prévue par le protocole initial : ses petites cibles admises matérialisent les résidus dans le parcours officiel et dans la reconstruction du candidat pour vérification. La référence directe demeure calculée par blocs. Cette clarification corrige une formulation trop générale, sans changement de code, cible, admission ou résultat. La version antérieure aux mesures est conservée dans amendments/REAL_DATA_PROTOCOL_REFERENCE_PRE_RUN.md et ses empreintes sont liées dans le manifeste.

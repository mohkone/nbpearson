"""Run only frozen real targets; never rerun the historical stress experiment."""
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone
from guard import ROOT, PROJECT, PYTHON, RUNTIME, run, records, budget

MF = ROOT / "REAL_DATA_EXECUTION_MANIFEST.json"
INPUTS = ROOT / "inputs_r2"
R = RUNTIME / "bin/Rscript"


def read(path):
    return json.loads(Path(path).read_text())


def persist(**updates):
    manifest = read(MF)
    manifest.update(updates)
    MF.write_text(json.dumps(manifest, indent=2) + "\n")


def guarded(label, command):
    prior = [row for row in records() if row["label"] == label]
    return prior[0] if prior else run(label, command)


def native_proof(name, method):
    label = name + "_" + method + "_matrix_r2"
    result = guarded(label, [R, "--vanilla", ROOT / "native_bpcells_r2.R", "verify",
                             INPUTS / name, ROOT / "runs" / label,
                             "TRUE" if method.endswith("TRUE") else "FALSE"])
    proof = ROOT / "runs" / label / "verification_matrix.json"
    return result, proof if result["status"] == "COMPLETED" and proof.exists() else None


def main():
    manifest = read(MF)
    for filename, digest in manifest["harness_frozen_sha256"].items():
        assert hashlib.sha256((ROOT / filename).read_bytes()).hexdigest() == digest, filename
    assert hashlib.sha256((PROJECT / "nbpearson_confirmatory_v1/CONFIRMATORY_PROTOCOL.md").read_bytes()).hexdigest() == manifest["protocol_sha256"]
    preparation = read(ROOT / "REAL_DATA_PREPARATION.json")
    assert preparation["status"] == "PREPARED_FROZEN_TARGETS"
    targets = [entry["name"] for entry in preparation["inputs"]]
    qualifications = []
    blocked = {}
    persist(status="QUALIFYING_REAL_HARNESS", real_inputs=targets,
            no_new_synthetic_qualification=True)
    for name in targets:
        if not name.endswith("common_small"):
            continue
        for method in ("interpolated", "interpolated_grouped", "exact_grouped", "scanpy"):
            label = "qualification_" + name + "_" + method
            result = guarded(label, [PYTHON, ROOT / "worker.py", "qualify", INPUTS / name,
                                     ROOT / "runs" / label, method])
            proof = ROOT / "runs" / label / "qualification.json"
            item = dict(dataset=name, method=method, receipt=result)
            if proof.exists():
                value = read(proof)
                passed = (value["matrix_relative_error"] is not None
                          and value["matrix_relative_error"] <= 1e-6
                          and all(e["relative_error"] is not None and e["relative_error"] <= 1e-6
                                  for e in value["products"].values())
                          and value["adjoint_scaled_error"] <= 1e-6
                          and value["center_scaled_error"] <= 1e-6)
                item["observed_matrix_products_pass"] = passed
                if not passed and method != "scanpy":
                    qualifications.append(item)
                    persist(status="STOPPED_PYTHON_QUALIFICATION_CRITERIA", qualifications=qualifications)
                    return
            elif result["status"] != "COMPLETED":
                qualifications.append(item)
                persist(status="STOPPED_PYTHON_QUALIFICATION_PROCESS_FAILURE", qualifications=qualifications)
                return
            qualifications.append(item)
        for method in ("BPCells_FALSE", "BPCells_TRUE"):
            result, proof = native_proof(name, method)
            qualifications.append(dict(dataset=name, method=method, receipt=result,
                                       matrix_proof=str(proof) if proof else None,
                                       numerical_status=read(proof)["status"] if proof else "NOT_EVALUATED"))
            if proof is None:
                # A mapping/runtime/verification error must be resolved before timing.
                persist(status="STOPPED_NATIVE_QUALIFICATION_PROCESS_FAILURE", qualifications=qualifications)
                return
        persist(qualifications=qualifications)
    persist(status="QUALIFICATION_COMPLETED_STARTING_DIRECT_REFERENCES", qualifications=qualifications,
            qualification_policy="Native approximation criterion failures are retained and do not remove that arm.")

    references = {}
    for name in targets:
        label = name + "_reference"
        result = guarded(label, [PYTHON, ROOT / "worker.py", "reference", INPUTS / name,
                                 ROOT / "runs" / label])
        if result["status"] != "COMPLETED":
            continue
        proof_label = label + "_verify"
        checked = guarded(proof_label, [PYTHON, ROOT / "verify_real.py", INPUTS / name,
                                       ROOT / "runs" / proof_label, ROOT / "runs" / label])
        proof = ROOT / "runs" / proof_label / "verification.json"
        if checked["status"] == "COMPLETED" and proof.exists() and read(proof)["status"] == "REFERENCE_TRIPLETS_SATISFIED":
            references[name] = str(ROOT / "runs" / label)
    persist(status="RUNNING_REAL_PIPELINES", gated_references=references)
    executions = []
    omitted = []
    for job in manifest["schedule"]:
        name, method, repetition = job["dataset"], job["method"], job["repetition"]
        key = name + "|" + method
        label = f"{name}_{method}_r{repetition}"
        if key in blocked:
            omitted.append(dict(**job, label=label, status="NOT_EXECUTED_PREVIOUS_ARM_STOP", cause=blocked[key]))
            persist(executions=executions, nonexecutions=omitted, blocked_arms=blocked)
            continue
        if budget()["remaining_seconds"] <= 0:
            omitted.append(dict(**job, label=label, status="NOT_RUN_GLOBAL_LIMIT"))
            persist(executions=executions, nonexecutions=omitted, blocked_arms=blocked)
            continue
        native = method.startswith("BPCells_")
        native_file = None
        if native:
            matrix_process, native_file = native_proof(name, method)
            if native_file is None:
                blocked[key] = dict(status=matrix_process["status"], phase="native_matrix_verification",
                                    label=matrix_process["label"])
                omitted.append(dict(**job, label=label, status="NOT_RUN_NATIVE_PROOF_UNAVAILABLE", cause=blocked[key]))
                persist(executions=executions, nonexecutions=omitted, blocked_arms=blocked)
                continue
            command = [R, "--vanilla", ROOT / "native_bpcells_r2.R", "run", INPUTS / name,
                       ROOT / "runs" / label, "TRUE" if method.endswith("TRUE") else "FALSE"]
        else:
            command = [PYTHON, ROOT / "worker.py", "run", INPUTS / name, ROOT / "runs" / label, method]
        result = guarded(label, command)
        pipeline = ROOT / "runs" / label / "pipeline.json"
        pipeline_status = read(pipeline).get("status") if pipeline.exists() else "NOT_MATERIALIZED"
        item = dict(**job, label=label, process_status=result["status"], pipeline_status=pipeline_status)
        executions.append(item)
        if result["status"] != "COMPLETED" or pipeline_status != "COMPLETED":
            error_file = ROOT / "runs" / label / "error.json"
            blocked[key] = dict(status=result["status"], pipeline_status=pipeline_status,
                                label=label, error=read(error_file) if error_file.exists() else None)
            persist(executions=executions, nonexecutions=omitted, blocked_arms=blocked)
            continue
        verify_label = label + "_verify"
        verification = guarded(verify_label, [PYTHON, ROOT / "verify_real.py", INPUTS / name,
            ROOT / "runs" / verify_label, ROOT / "runs" / label,
            references.get(name, "-"), native_file or "-"])
        item["verification_process_status"] = verification["status"]
        proof = ROOT / "runs" / verify_label / "verification.json"
        item["verification_status"] = read(proof).get("status") if proof.exists() else "NOT_EVALUATED"
        persist(executions=executions, nonexecutions=omitted, blocked_arms=blocked)
    persist(status="REAL_PIPELINE_PHASE_FINISHED", executions=executions,
            nonexecutions=omitted, blocked_arms=blocked, budget_at_pipeline_end=budget(),
            pipeline_phase_finished_utc=datetime.now(timezone.utc).isoformat())


if __name__ == "__main__":
    main()

# Décision scientifique finale — GO délimité

**GO — Les nouveaux résultats soutiennent la contribution logicielle délimitée dans les conditions testées.**

La preuve est celle de [cette campagne réelle](REAL_DATA_CONFIRMATORY_REPORT.md), séparée de rev3 et des 27 pipelines synthétiques : 66 ACP achevées sur quatre cibles fixées provenant de deux ressources 10x, dont 54 satisfont tous les critères finaux. Les **36 exécutions nbpearson dev1** satisfont les critères gelés sur les deux sources. Les comptes, marges, axes, paramètres et version du paquet sont fixés et traçables.

La compression du facteur gauche réduit le stockage permanent dans les quatre cibles à profondeurs répétées. Elle n’améliore pas uniformément le temps construction+ACP, le coût des produits ou le RSS. Son produit transposé par blocs est plus coûteux ici. Le choix des trois représentations reste manuel.

Les 12 BPCells lents et les six Scanpy exécutés satisfont les critères finaux. Les 12 BPCells rapides passent matrice/produits à 1e-6 mais échouent aux résidus des triplets à 1e-8 ; neuf angles sont hors seuil. Les six absences Scanpy sont deux refus de préflight et quatre répétitions non lancées, sans OOM mesuré. Ces résultats sont conservés et ne sont pas convertis en temps infinis.

Les pipelines natifs Python et R restent différents par solveur, initialisation, runtime et granularité de chronométrage. Aucune supériorité générale du seul opérateur n’est établie. Les preuves matricielles R sont huit contrôles au total (quatre cibles × deux modes), réutilisés pour leurs trois répétitions, non 24 observations indépendantes ; les produits sauvegardés et triplets sont contrôlés par pipeline. Les tailles imbriquées ne prouvent pas une généralisation inter-donneurs.

La provenance externe reste partielle sous A1 ; les deux incidents de harnais avant ACP et leurs corrections sont conservés. Les limites connues des matrices presque nulles, du L flottant non certifié, des écarts spectraux et du watchdog observé subsistent.

**Une seule recommandation : retenir GO pour l’utilité numérique et informatique délimitée démontrée, avec ces réserves.** Cette décision n’est ni une certification universelle, ni une priorité méthodologique, ni une décision d’acceptation éditoriale. Aucun nouveau développement, benchmark, changement de méthode, publication ou investigation n’est engagé après cette clôture.

Preuves : [accuracy](real_accuracy_results.csv), [performance](real_performance_results.csv), [profondeurs et stockage](real_depth_diversity.csv), [manifest](REAL_DATA_EXECUTION_MANIFEST.json), [préparation](REAL_DATA_PREPARATION.json), [protocole de reprise](REAL_DATA_PROTOCOL_REFERENCE.md).

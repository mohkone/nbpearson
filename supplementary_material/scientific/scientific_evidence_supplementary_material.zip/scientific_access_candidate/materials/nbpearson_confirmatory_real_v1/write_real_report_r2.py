"""Write reports from completed local tables only; no numerical core imports."""
import csv
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
METHODS = ("interpolated", "interpolated_grouped", "exact_grouped", "scanpy", "BPCells_FALSE", "BPCells_TRUE")
NAMES = {"pbmc_10k_common_small": "PBMC petite", "pbmc_10k_larger": "PBMC grande",
         "mouse_brain_nextgem_10k_common_small": "Mouse petite", "mouse_brain_nextgem_10k_larger": "Mouse grande"}
OPS = ("matvec", "rmatvec", "matmat8", "rmatmat8")


def read_csv(name):
    with (ROOT / name).open(newline="") as handle:
        return list(csv.DictReader(handle))


def maximum(rows, key):
    return max(float(row[key]) for row in rows if row.get(key))


def main():
    accuracy = read_csv("real_accuracy_results.csv")
    performance = read_csv("real_performance_results.csv")
    diversity = read_csv("real_depth_diversity.csv")
    preparation = json.loads((ROOT / "REAL_DATA_PREPARATION.json").read_text())
    summary = json.loads((ROOT / "real_completed_summary.json").read_text())
    manifest = json.loads((ROOT / "REAL_DATA_EXECUTION_MANIFEST.json").read_text())
    ledger = json.loads((ROOT / "ledger.json").read_text())
    datasets = [item["name"] for item in preparation["inputs"]]
    grouped = {(item["dataset"], item["method"]): item for item in summary["summary"]}
    assert len(accuracy) == len(performance) == len(diversity) == 66
    assert len({row["pipeline_label"] for row in performance}) == 66
    assert sum(row["all_frozen_observed_criteria_satisfied"] == "True" for row in accuracy) == 54
    assert all(row["matrix_status"] == "SATISFIED" for row in accuracy)
    assert all(row[op + "_status"] == "SATISFIED" for row in accuracy for op in OPS)
    assert all(row["reference_triplet_gate_status"] == "SATISFIED" for row in accuracy)
    for filename in ("REAL_DATA_CONFIRMATORY_REPORT.md", "FINAL_SCIENTIFIC_DECISION.md"):
        assert not (ROOT / filename).exists(), "Refusing report overwrite"

    data_lines = []
    storage_lines = []
    cost_lines = []
    product_lines = []
    memory_lines = []
    gap_lines = []
    for item in preparation["inputs"]:
        name = item["name"]
        rows = [row for row in performance if row["dataset"] == name]
        first = {method: next((row for row in rows if row["method"] == method), None) for method in METHODS}
        a, b, c = (first[method] for method in METHODS[:3])
        ds = NAMES[name]
        data_lines.append(f"| {ds} | {item['N']} | {item['G']} | {item['nnz']} | {item['sparsity']:.6f} | {item['U_d']} | {item['U_d_over_N']:.6f} | {a['interpolation_nodes']} | {a['clipped_entries']} |")
        da, db, dc = (json.loads(row["storage_detail"]) for row in (a, b, c))
        group_metadata = sum(db.get(key, 0) for key in ("groups", "multiplicity", "depth_values", "basis_mean"))
        storage_lines.append(f"| {ds} | {item['CSR_bytes']} | {da['C']} | {da['left']} / {db['left']} | {group_metadata} | {db['right']} | {dc['table']} | {a['operator_storage_bytes']} / {b['operator_storage_bytes']} / {c['operator_storage_bytes']} |")
        cells = []
        rss_cells = []
        for method in METHODS:
            values = grouped.get((name, method))
            if values is None or values.get("repetitions_completed", 0) == 0:
                cells.append("PRÉFLIGHT — non exécuté")
                rss_cells.append("non exécuté")
            else:
                cells.append(f"{values['construction_pca_median_seconds']:.6f} [{values['construction_pca_min_seconds']:.6f}, {values['construction_pca_max_seconds']:.6f}]")
                rss_cells.append(f"{values['peak_rss_max_bytes'] / 2**20:.2f}")
        cost_lines.append("| " + ds + " | " + " | ".join(cells) + " |")
        memory_lines.append("| " + ds + " | " + " | ".join(rss_cells) + " |")
        for method in METHODS[:2]:
            values = grouped[(name, method)]
            costs = [f"{values[op + '_seconds_per_call_median'] * 1000:.6f}" for op in OPS]
            product_lines.append("| " + ds + " | " + ("A" if method == "interpolated" else "B") + " | " + " | ".join(costs) + " |")
        ar = next(row for row in accuracy if row["dataset"] == name)
        fast = next(row for row in accuracy if row["dataset"] == name and row["method"] == "BPCells_FALSE")
        gap_lines.append(f"| {ds} | {float(ar['reference_gap_20_21']):.9g} | {float(fast['matrix_relative_error']):.9g} | {float(fast['triplet_relative_residual']):.9g} | {max(float(fast['left_angle_radians']), float(fast['right_angle_radians'])):.9g} | {fast['angle_status']} |")

    precision_lines = []
    for method in METHODS:
        rows = [row for row in accuracy if row["method"] == method]
        product_max = max(float(row[op + "_relative_error"]) for row in rows for op in OPS)
        angle_max = max(float(row[key]) for row in rows for key in ("left_angle_radians", "right_angle_radians"))
        passed = sum(row["all_frozen_observed_criteria_satisfied"] == "True" for row in rows)
        precision_lines.append(f"| {method} | {len(rows)} | {maximum(rows,'matrix_relative_error'):.9g} | {product_max:.9g} | {maximum(rows,'triplet_relative_residual'):.9g} | {maximum(rows,'singular_relative_error'):.9g} | {angle_max:.9g} | {passed}/{len(rows)} |")

    nb = [row for row in accuracy if row["method"] in METHODS[:3]]
    all_peak = max(row["peak_rss_bytes"] for row in ledger)
    preflights = []
    for name in datasets:
        if not name.endswith("larger"):
            continue
        values = json.loads((ROOT / "runs" / (name + "_scanpy_r1") / "preflight.json").read_text())
        preflights.append(f"- {NAMES[name]} : baseline après imports {values['baseline_after_import_bytes']} octets ; estimation {values['estimated_peak_bytes']} octets, supérieure à 536870912.")

    report = f"""# Évaluation confirmatoire sur données réelles V1

## Décision et portée exécutée

**GO — les nouveaux résultats soutiennent une contribution logicielle délimitée dans les conditions testées.** Cette décision ne porte ni sur une nouveauté acquise, ni sur une supériorité universelle, ni sur l’acceptation d’un article.

Sur 72 pipelines planifiés, **66 ACP sont achevées et vérifiées** : 36 nbpearson, 6 Scanpy et 24 BPCells. **54 satisfont tous les critères finaux observés** : les 36 nbpearson, les 6 Scanpy exécutées et les 12 BPCells slow=TRUE. Les 12 BPCells slow=FALSE convergent et passent les critères de matrice/produits, mais dépassent le seuil de résidus des triplets. Les six absences Scanpy correspondent à deux refus de préflight et quatre répétitions suivantes non lancées, sans OOM ou timeout observé.

Sources chiffrées : [real_accuracy_results.csv](real_accuracy_results.csv), [real_performance_results.csv](real_performance_results.csv), [real_depth_diversity.csv](real_depth_diversity.csv), clés dataset/method/repetition. Les résultats individuels et les 40 temps de produits par pipeline sont conservés. Les [résultats synthétiques historiques](../nbpearson_confirmatory_v1/CONFIRMATORY_REPORT.md) et rev3 ne sont ni relancés ni fusionnés avec cette session. Les répétitions de processus ne sont pas des réplications biologiques.

## Sources, préparation et paramètres

Admission sous [A1 approuvé](../nbpearson_data_recovery_v1/provenance_resolution_v1/approval_a1_v1/APPROVAL_RECEIPT.json), avec provenance externe partielle déclarée :

- PBMC 10k Chromium X : SHA-256 `42a789ff3f92f0e117d1ff4ffcb2fa8edee87dd2a03d83a81502709344a38bf0`, Cell Ranger 6.1.0, source 36601 caractéristiques × 11996 observations.
- Mouse Brain NextGEM : SHA-256 `895365af6c20b7a1dd80604ef19f1f963fc3b3c7738ba1589d49cf64651f62fe`, Cell Ranger 8.0.0, source 33696 × 9684. molecule_info est exclu.

Les fichiers approuvés ont été rehashés avant préparation. Les comptes non négatifs entiers sont sélectionnés selon le [protocole gelé](../nbpearson_confirmatory_v1/CONFIRMATORY_PROTOCOL.md), sans HVG, normalisation ou log1p. La lecture CSC est bornée ; chaque cible est un CSR observations × gènes. Axes, index originaux, exclusions, comptes et marges binary64 propres à chaque cible sont conservés dans inputs_r2 et [REAL_DATA_PREPARATION.json](REAL_DATA_PREPARATION.json). Les exports R ont été contrôlés bit à bit pour n et p ; Scanpy a recalculé les mêmes marges sur cet univers.

| Cible | N | G | nnz | Sparsité | U_d | U_d/N | Nœuds A/B | Entrées plafonnées |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(data_lines)}

Une seule ligne nulle a été retirée après sélection : PBMC grande, position sélectionnée 7232 et index source 817 (base zéro), sans remplacement. Aucune colonne sélectionnée n’a été retirée. Les caractéristiques nulles avant sélection ne sont pas des exclusions parmi les 1000/2000 gènes retenus. Les tailles petite/grande sont imbriquées par source : **deux ressources distinctes du développement, pas quatre cohortes ni une preuve inter-donneurs**.

theta=100 ; clip=sqrt(N), avant centrage par gène ; variance NB standard ; marges figées identiques entre bras. Pour A/B : matrix_rtol=1e-6, max_nodes=128, 16 premières paires adjacentes disjointes, borne sur N. A=interpolated ; B=interpolated_grouped ; C=exact_grouped, sans approximation d’interpolation mais flottant. Le constructeur conserve NOT_EVALUATED pour sa validation flottante : les statuts ci-dessous proviennent uniquement des comparaisons effectivement exécutées.

## Fidélité, convergence et sous-espaces

La référence utilise la formule directe binary64 en blocs de 256 lignes, moyenne stable et norme centrée en deux passes. Elle n’est pas une vérité en arithmétique réelle. Les quatre ACP directes ont convergé ; leurs triplets 20/21 ont passé le contrôle indépendant de résidus. Tous les gaps autorisent ici l’interprétation des sous-espaces selon la règle gelée.

Maximum par méthode sur les répétitions/cibles exécutées ; angles en radians. Critères : matrice et produits 1e-6, résidus des triplets 1e-8, singulières et angles interprétables 1e-6. Les valeurs absolues et normes figurent dans le CSV et les verification.json.

| Méthode | ACP | Erreur matrice relative max | Erreur produits max | Résidu triplets retenus max | Erreur singulières max | Angle max | Tous critères |
|---|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(precision_lines)}

Les 36 nbpearson ont une erreur matricielle maximale {maximum(nb,'matrix_relative_error'):.9g} et un résidu retenu maximal {maximum(nb,'triplet_relative_residual'):.9g}. Cela reproduit la fidélité sur ces comptes, sans certification flottante universelle ni conclusion sur des matrices presque nulles. Le L évalué en flottant reste un minorant non certifié ; la sélection analytique, l’erreur d’opérateur, la résolution SVD et sa troncature demeurent distinctes.

Le mode rapide BPCells n’est **pas hors tolérance matricielle** ici. Ses 12 erreurs de matrice et quatre produits passent 1e-6, comme ses valeurs singulières. Ses 12 résidus de triplets dépassent 1e-8 ; neuf angles dépassent 1e-6 rad et trois, sur Mouse grande, passent. Ses temps restent visibles comme compromis précision–coût, mais ne sont pas classés à précision finale égale.

| Cible | Gap référence 20/21 | Matrice BPCells rapide | Résidu BPCells rapide | Angle maximal rapide (rad) | Critère angle |
|---|---:|---:|---:|---:|---|
{chr(10).join(gap_lines)}

Les huit vérifications matricielles natives R (quatre cibles × deux modes) sont séparées des chronométrages et référencées par les trois répétitions correspondantes. Les produits effectivement sauvegardés et les triplets de chaque pipeline R sont vérifiés individuellement. Seule la dernière sortie de chaque lot de dix produits est sauvegardée, pas les dix tableaux intermédiaires ; les quarante durées individuelles restent disponibles.

## Construction + ACP

Secondes : médiane [minimum, maximum], trois processus neufs par cellule exécutée. Les temps rapides (*) sont hors critères finaux ; un refus de préflight n’est pas un temps infini.

**Réserves de comparabilité :** cette campagne possède un nouvel ordre réel mélangé et gelé ; aucune médiane historique ou synthétique n’est réutilisée. SciPy ARPACK utilise k21/ncv64/tol1e-10/maxiter10000 et un v0 gaussien seed6619 ; Scanpy conserve sklearn ARPACK, tol0 et son départ natif ; BPCells utilise Spectra k=nu=nv=21/ncv64/tol1e-10/maxitr10000 et set.seed(6619), sans v0 partagé avec Python. Les pipelines incluent validation/copies et centrage nécessaires. Python mesure un intervalle global construction+ACP, R somme les deux sous-temps. Les compteurs d’itération ne sont pas forcés égaux. Aucun écart inter-runtime n’est attribué au seul opérateur.

| Cible | A | B | C | Scanpy | BPCells rapide* | BPCells lent |
|---|---|---|---|---|---|---|
{chr(10).join(cost_lines)}

La médiane B est inférieure à A seulement sur PBMC petite ; elle n’est pas uniformément plus basse. Sur ces quatre cibles, A/B ont les mêmes nombres de produits du solveur, conservés par type et largeur dans le CSV. C est exécutable et fidèle mais son fond U_d×G coûte davantage ici. Les comparaisons temporelles se limitent à ces configurations, trois répétitions et ces runtimes.

## Compression et stockage

Octets permanents exposés par les opérateurs ; les comptes communs, marges, sondes, copies temporaires et espaces SVD restent distincts. La colonne « métadonnées B » comprend groupes, multiplicités, profondeurs distinctes et moyenne de base. Les stockages totaux A/B/C incluent toutes leurs propres composantes, dont C_mean, et ne sont pas des pics RAM.

| Cible | CSR comptes communs | Correction C | Facteur gauche A / B | Métadonnées B | Facteur droit | Table exacte C | Opérateur total A / B / C |
|---|---:|---:|---|---:|---:|---:|---|
{chr(10).join(storage_lines)}

B réduit le stockage permanent sur les quatre cibles à profondeurs répétées, mais la correction sparse domine une partie du coût total. Cette réduction n’implique pas un gain identique de RSS. L’exact groupé signifie sans interpolation, pas sans arrondis ; sa table pourrait devenir N×G si toutes les profondeurs étaient distinctes. Le stockage natif C++ BPCells n’est pas exposé : la taille de l’enveloppe R n’est jamais présentée comme son stockage total.

## Produits fixes et mémoire de processus

Médiane du temps moyen par appel de chaque lot, en millisecondes ; mêmes sondes, une chauffe puis dix appels après ACP. Les quatre opérations complètes incluent correction et centrage. La finitude est contrôlée hors temps en Python **et R**, conformément à ce protocole ; cela diffère de certains résultats historiques. R utilise proc.time, de résolution plus grossière que perf_counter Python. Les données complètes des six bras restent dans le CSV et products.csv.

| Cible | Représentation | matvec ms | rmatvec ms | matmat8 ms | rmatmat8 ms |
|---|---|---:|---:|---:|---:|
{chr(10).join(product_lines)}

Le produit transposé de largeur 8 de B est plus coûteux que celui de A sur les quatre cibles. Le bénéfice de compression n’établit donc pas un avantage systématique du produit, ni une règle automatique de choix. Le temps pipeline n’est pas divisé par le nombre d’appels pour en déduire un coût unitaire.

Pic RSS **observé**, maximum des trois processus, en Mio (2^20 octets). Frontière commune : lancement → imports → chargement → construction → ACP → produits → export → sortie ; vérification dans un processus distinct. Les baselines de runtime diffèrent et sont consignées. Aucune comparaison RSS/nbytes n’est faite.

| Cible | A | B | C | Scanpy | BPCells rapide | BPCells lent |
|---|---:|---:|---:|---|---:|---:|
{chr(10).join(memory_lines)}

## Budgets, préflights et incidents conservés

Un thread numérique et 512 Mio par processus ; watchdog PID principal VmRSS/VmHWM toutes les 50 ms, 300 s pour **tout le processus**, ou reliquat global inférieur. Il ne somme pas les descendants et n’assure pas l’absence de pic transitoire entre échantillons. Aucun arrêt temps/RSS n’a été déclenché. Maximum observé sur tous les enfants nouveaux : {all_peak} octets.

Le cumul final est **__FINAL_BUDGET_SECONDS__ s**, dont 50,19525759114185 s historiques reportées ; pas de remise à zéro. Ce cumul inclut préparation, qualifications, échecs, références, pipelines, vérifications et consolidation/rédaction gardée, dans le plafond 1800 s. Le registre distingue chargement, construction, ACP, produits, export, temps total et vérification. L’installation et les transferts antérieurs restent extérieurs au benchmark.

Scanpy grande a été refusé selon la formule gelée baseline_imports + 6×8NG + 3×CSR_bytes + 64 Mio :

{chr(10).join(preflights)}

Le refus conservateur ne prouve pas qu’une autre politique mémoire empêcherait Scanpy de traiter ces données. Les répétitions suivantes n’ont pas été relancées, aucune durée d’achèvement ou accélération n’est inférée de ces absences.

Deux incidents de plomberie sont conservés **avant toute ACP réelle** : la première préparation a détecté un pool Matrix Market chargé tardivement, dont le respect d’un thread n’était pas établi ; la révision r2 précharge l’extension avant threadpool_limits(1). La première qualification R a échoué à sérialiser la classe simple.list de R.version ; r2 retire cette classe pour le JSON seulement. Scripts, sorties partielles, reçus et temps des échecs sont conservés dans [PREPARATION_HARNESS_AMENDMENT.json](PREPARATION_HARNESS_AMENDMENT.json) et [NATIVE_HARNESS_AMENDMENT.json](NATIVE_HARNESS_AMENDMENT.json). La petite cible PBMC est identique entre les deux préparations pour comptes, marges, axes et sondes. Aucun échec budgétaire n’a été relancé. Une erreur ultérieure du rédacteur de rapport, qui attendait une médiane pour une configuration non exécutée, est conservée dans runs/real_report_writing ; sa révision r2 affiche le préflight sans durée. Les CSV et les critères n’ont pas changé.

Une correction d’unité de centrage R a été intégrée avant sa première exécution : norme des sommes de colonnes, moyenne conservée séparément. Les préflights, le report du budget et les contrôles des sorties sauvegardées sont des corrections de harnais tracées ; aucun cœur numérique ou critère n’a changé. Une clarification documentaire après campagne précise que seul le candidat Scanpy admis matérialise ses petits résidus ; l’oracle reste diffusé. La rédaction initiale est archivée, pas réécrite comme une autre expérience.

## Réponses et recommandation

1. **Fidélité reproduite sur les deux nouvelles ressources : oui, dans les quatre univers fixés.** Les 36 exécutions dev1 satisfont matrice, produits, adjoint, centrage, triplets, valeurs singulières et angles interprétables. Les limites de quasi-nullité, d’arrondis et de norme flottante restent ouvertes hors des régimes observés.
2. **Compression utile pour le stockage : oui, lorsque les profondeurs se répètent ici.** Les U_d/N vont de 0,143639 à 0,567 ; le stockage B est moindre dans les quatre cibles. Le RSS et les coûts de produits/pipeline n’offrent pas un gain uniforme. Aucune règle de sélection automatique n’est proposée.
3. **Contribution logicielle délimitée soutenue : oui.** Le paquet installé fournit une transformation NB fixée avec trois représentations explicites, précision observée et ressources documentées. Les comparateurs officiels sont conservés ; BPCells constitue déjà un calcul implicite pertinent. Les coûts locaux du pipeline sont utiles, sans comparaison à solveur identique ni revendication de première méthode NB implicite.

**Recommandation unique : GO pour cette contribution logicielle délimitée, en conservant toutes ces limites et les résultats défavorables.** Deux sources, tailles imbriquées, provenance partielle acceptée sous A1, trois répétitions, matériel/concurrence non entièrement contrôlés, amendements de harnais et refus conservateurs limitent la généralisation. Aucune généralisation inter-donneurs, qualité biologique, nouveauté mathématique, supériorité générale ou certification flottante ne découle de cette campagne. Aucun manuscrit, paquet, dépôt public ou résultat historique n’a été modifié.

## Traçabilité et environnement

Paquet installé hors src, cinq sources identiques au wheel évalué SHA-256 `6334eb9758d004ba7171b8c430f4b1df9d659ac2327ff152db26905b282238e7`. Python 3.12.3, NumPy 2.5.4, SciPy 1.18.1 et Scanpy 1.12.5 ; R 4.5.3, BPCells 0.3.1, Matrix 1.7.6, jsonlite 2.0.0. Les signatures, threadpools, sessionInfo, build et BLAS/LAPACK enregistrés font foi ; aucune documentation actuelle n’est substituée à ces signatures.

L’état matériel observé avant cette campagne (CPU, mémoire, plateforme) est dans [REAL_DATA_EXECUTION_MANIFEST.json](REAL_DATA_EXECUTION_MANIFEST.json), avec la réserve sur charge concurrente/alimentation/fréquences non contrôlées. Les preuves individuelles résident dans runs/*/receipt.json, pipeline.json, verification.json et les preuves matricielles R. [ledger.json](ledger.json) conserve tous les temps imputés et incidents. Les clichés CONSOLIDATION_INPUT_MANIFEST.json/CONSOLIDATION_INPUT_LEDGER.json fixent les versions lues par le consolidateur avant les ajouts de clôture ; les empreintes de ses sources sont donc vérifiables sans attendre que ces registres évolutifs restent identiques à leur état intermédiaire.
"""
    decision = f"""# Décision scientifique finale — GO délimité

**GO — Les nouveaux résultats soutiennent la contribution logicielle délimitée dans les conditions testées.**

La preuve est celle de [cette campagne réelle](REAL_DATA_CONFIRMATORY_REPORT.md), séparée de rev3 et des 27 pipelines synthétiques : 66 ACP achevées sur quatre cibles fixées provenant de deux ressources 10x, dont 54 satisfont tous les critères finaux. Les **36 exécutions nbpearson dev1** satisfont les critères gelés sur les deux sources. Les comptes, marges, axes, paramètres et version du paquet sont fixés et traçables.

La compression du facteur gauche réduit le stockage permanent dans les quatre cibles à profondeurs répétées. Elle n’améliore pas uniformément le temps construction+ACP, le coût des produits ou le RSS. Son produit transposé par blocs est plus coûteux ici. Le choix des trois représentations reste manuel.

Les 12 BPCells lents et les six Scanpy exécutés satisfont les critères finaux. Les 12 BPCells rapides passent matrice/produits à 1e-6 mais échouent aux résidus des triplets à 1e-8 ; neuf angles sont hors seuil. Les six absences Scanpy sont deux refus de préflight et quatre répétitions non lancées, sans OOM mesuré. Ces résultats sont conservés et ne sont pas convertis en temps infinis.

Les pipelines natifs Python et R restent différents par solveur, initialisation, runtime et granularité de chronométrage. Aucune supériorité générale du seul opérateur n’est établie. Les preuves matricielles R sont huit contrôles par configuration, non 24 observations indépendantes ; les produits sauvegardés et triplets sont contrôlés par pipeline. Les tailles imbriquées ne prouvent pas une généralisation inter-donneurs.

La provenance externe reste partielle sous A1 ; les deux incidents de harnais avant ACP et leurs corrections sont conservés. Les limites connues des matrices presque nulles, du L flottant non certifié, des écarts spectraux et du watchdog observé subsistent.

**Une seule recommandation : retenir GO pour l’utilité numérique et informatique délimitée démontrée, avec ces réserves.** Cette décision n’est ni une certification universelle, ni une priorité méthodologique, ni une décision d’acceptation éditoriale. Aucun nouveau développement, benchmark, changement de méthode, publication ou investigation n’est engagé après cette clôture.

Preuves : [accuracy](real_accuracy_results.csv), [performance](real_performance_results.csv), [profondeurs et stockage](real_depth_diversity.csv), [manifest](REAL_DATA_EXECUTION_MANIFEST.json), [préparation](REAL_DATA_PREPARATION.json), [protocole de reprise](REAL_DATA_PROTOCOL_REFERENCE.md).
"""
    (ROOT / "REAL_DATA_CONFIRMATORY_REPORT.md").write_text(report)
    (ROOT / "FINAL_SCIENTIFIC_DECISION.md").write_text(decision)
    print("Wrote bounded real report and one scientific decision from 66 traceable pipeline rows.")


if __name__ == "__main__":
    main()

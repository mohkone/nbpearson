"""Bounded I/O harness for the four fixed real-data targets; no work on import."""
import argparse
import hashlib
import json
import math
import time
from datetime import datetime, timezone
from pathlib import Path

import h5py
import numpy as np
from scipy import io, sparse
# Preload the optional I/O extension BEFORE entering threadpool_limits.
# Its lazily registered pool otherwise appears after the context was entered.
from scipy.io._fast_matrix_market import _fmm_core  # noqa: F401
from threadpoolctl import threadpool_info, threadpool_limits

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
APPROVAL = PROJECT / 'nbpearson_data_recovery_v1/provenance_resolution_v1/approval_a1_v1/APPROVAL_RECEIPT.json'
MEMORY_LIMIT = 512 * 2**20
MAX_SLICE_ENTRIES = 1_000_000
MAX_SLICE_COLUMNS = 128
PREFIX = 'NBPEARSON-CONFIRMATORY-V1|'
TARGETS = (('common_small', 1000, 1000), ('larger', 10000, 2000))


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha256(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024*1024), b''):
            result.update(block)
    return result.hexdigest()


def rss():
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.startswith('VmRSS:'):
            return int(line.split()[1])*1024
    raise RuntimeError('RSS unavailable')


def strings(dataset):
    result = [v.decode('utf-8', errors='strict') if isinstance(v, bytes) else str(v)
              for v in dataset[()]]
    if any(not v or any(c in v for c in '\t\r\n') for v in result):
        raise ValueError('Missing or non-tabular source identifier')
    return result


def columns(matrix, pointers, selected):
    """Read bounded contiguous runs of selected CSC columns in file order."""
    ordered = np.sort(np.asarray(selected, dtype=np.int64))
    start = 0
    n_features = int(matrix['shape'][0])
    while start < len(ordered):
        stop = start + 1
        first = int(ordered[start])
        if int(pointers[first+1]-pointers[first]) > MAX_SLICE_ENTRIES:
            raise MemoryError('One source column exceeds the fixed I/O slice cap')
        while stop < len(ordered):
            following = int(ordered[stop])
            if following != int(ordered[stop-1])+1 or stop-start >= MAX_SLICE_COLUMNS:
                break
            if int(pointers[following+1]-pointers[first]) > MAX_SLICE_ENTRIES:
                break
            stop += 1
        last = int(ordered[stop-1])
        lo, hi = int(pointers[first]), int(pointers[last+1])
        index = np.asarray(matrix['indices'][lo:hi], dtype=np.int64)
        value = np.asarray(matrix['data'][lo:hi])
        if len(index) != len(value) or np.any(index < 0) or np.any(index >= n_features):
            raise ValueError('Invalid source CSC indices or lengths')
        if not np.isfinite(value).all() or np.any(value < 0) or np.any(value != np.floor(value)):
            raise ValueError('Nonfinite, negative or noninteger selected counts')
        for column in ordered[start:stop]:
            column = int(column)
            a, b = int(pointers[column])-lo, int(pointers[column+1])-lo
            idx = index[a:b]
            if len(idx)>1 and np.any(np.diff(idx)<=0):
                raise ValueError('Noncanonical source CSC column')
            yield column, idx, value[a:b]
        start = stop


def distribution(values):
    values = np.asarray(values)
    return dict(minimum=float(values.min()), median=float(np.median(values)),
                maximum=float(values.max()), mean=float(values.mean()),
                quantiles_0_25_50_75_100=np.quantile(values,[0,.25,.5,.75,1]).tolist())


def prepare(source, target, requested_n, requested_g, output_root, phase_dir):
    started = time.perf_counter()
    name = source['source']+'_'+target
    out = output_root/name
    out.mkdir(parents=True, exist_ok=False)
    if phase_dir:
        (phase_dir/'phase.txt').write_text('preparing:'+name)
    path = PROJECT/source['local_path']
    if path.stat().st_size != source['size_bytes'] or sha256(path) != source['sha256']:
        raise ValueError('Approved source size or SHA-256 changed')
    with h5py.File(path,'r') as handle:
        matrix = handle['matrix']
        source_shape = tuple(int(v) for v in matrix['shape'][()])
        if list(source_shape) != source['technical_validation']['shape_features_by_observations']:
            raise ValueError('Approved source dimensions changed')
        features, observations = source_shape
        ids, names = strings(matrix['features/id']), strings(matrix['features/name'])
        kinds, barcodes = strings(matrix['features/feature_type']), strings(matrix['barcodes'])
        if any(len(a)!=features for a in (ids,names,kinds)) or len(barcodes)!=observations:
            raise ValueError('Source axis dimensions disagree')
        if len(set(ids))!=features or len(set(barcodes))!=observations:
            raise ValueError('Duplicate stable IDs/barcodes require adjudication')
        gene_expression = np.array([kind=='Gene Expression' for kind in kinds])
        if not gene_expression.any():
            raise ValueError('No explicit Gene Expression features')
        pointers = np.asarray(matrix['indptr'][()],dtype=np.int64)
        if len(pointers)!=observations+1 or pointers[0]!=0 or np.any(np.diff(pointers)<0):
            raise ValueError('Invalid source CSC pointers')
        if int(pointers[-1])!=len(matrix['data']) or len(matrix['data'])!=len(matrix['indices']):
            raise ValueError('Invalid source CSC entry lengths')
        ordered = sorted(range(observations),key=lambda i:(
            hashlib.sha256((PREFIX+barcodes[i]).encode('utf-8')).digest(),barcodes[i]))
        selected_obs = np.asarray(ordered[:min(requested_n,observations)],dtype=np.int64)
        # Positive presence is equivalent to strictly positive gene sum for
        # nonnegative counts. These are not the final fixed numerical margins.
        present = np.zeros(features,dtype=bool)
        gene_nnz = np.zeros(features,dtype=np.int64)
        for _,indices,values in columns(matrix,pointers,selected_obs):
            positive = values>0
            present[indices[positive]] = True
            gene_nnz += np.bincount(indices[positive],minlength=features)
        eligible = [i for i in range(features) if gene_expression[i] and present[i]]
        eligible.sort(key=lambda i:ids[i])
        selected_genes = np.asarray(eligible[:requested_g],dtype=np.int64)
        if not len(selected_genes):
            raise ValueError('No positive Gene Expression features on fixed observations')
        selected_nnz = int(gene_nnz[selected_genes].sum())
        csr_estimate = 12*selected_nnz+4*(len(selected_obs)+1)
        preflight = dict(baseline_rss_bytes=rss(),estimated_CSR_bytes=csr_estimate,
            CSR_copies_and_export_workspace_bytes=4*csr_estimate,
            bounded_IO_workspace_bytes=24*MAX_SLICE_ENTRIES,
            metadata_misc_workspace_bytes=64*2**20,memory_budget_bytes=MEMORY_LIMIT,
            formula='current_RSS + 4*estimated_CSR_bytes + 24*slice_entries + 64MiB; admission estimate, not RSS guarantee')
        preflight['estimated_peak_bytes'] = (preflight['baseline_rss_bytes']+
            preflight['CSR_copies_and_export_workspace_bytes']+preflight['bounded_IO_workspace_bytes']+
            preflight['metadata_misc_workspace_bytes'])
        preflight['status'] = 'ADMITTED' if preflight['estimated_peak_bytes']<=MEMORY_LIMIT else 'NOT_ADMITTED_MEMORY'
        save(out/'preparation_preflight.json',preflight)
        if preflight['status']!='ADMITTED':
            raise MemoryError('Preparation estimate exceeds 512MiB before sparse count allocation')
        feature_map = np.full(features,-1,dtype=np.int32)
        feature_map[selected_genes] = np.arange(len(selected_genes),dtype=np.int32)
        row_position = np.full(observations,-1,dtype=np.int32)
        row_position[selected_obs] = np.arange(len(selected_obs),dtype=np.int32)
        data_parts,index_parts = [None]*len(selected_obs),[None]*len(selected_obs)
        lengths = np.zeros(len(selected_obs),dtype=np.int32)
        for column,indices,values in columns(matrix,pointers,selected_obs):
            mapped = feature_map[indices]
            keep = (mapped>=0)&(values>0)
            ix, val = mapped[keep],np.asarray(values[keep],dtype=np.float64)
            order = np.argsort(ix)
            row = int(row_position[column])
            index_parts[row],data_parts[row] = ix[order],val[order]
            lengths[row] = len(ix)
        ptr = np.empty(len(lengths)+1,dtype=np.int32)
        ptr[0]=0
        np.cumsum(lengths,out=ptr[1:])
        if int(ptr[-1])!=selected_nnz:
            raise ValueError('Prepared nnz differs from fixed source selection')
        data,index = np.concatenate(data_parts),np.concatenate(index_parts)
        del data_parts,index_parts
        x = sparse.csr_matrix((data,index,ptr),shape=(len(selected_obs),len(selected_genes)),copy=False)
        del data,index,ptr
    # Strictly positive stored counts permit empty-margin exclusion without
    # preliminary floating sums or recalculation on another count universe.
    row_keep = np.diff(x.indptr)>0
    column_keep = np.bincount(x.indices,minlength=x.shape[1])>0
    removed_rows,removed_columns = np.flatnonzero(~row_keep),np.flatnonzero(~column_keep)
    original_removed_rows,original_removed_columns = selected_obs[removed_rows],selected_genes[removed_columns]
    if not row_keep.all() or not column_keep.all():
        x = x[row_keep][:,column_keep].tocsr()
        selected_obs,selected_genes = selected_obs[row_keep],selected_genes[column_keep]
    x.sort_indices()
    if not x.has_canonical_format or np.any(x.data<=0) or not np.isfinite(x.data).all() or np.any(x.data!=np.floor(x.data)):
        raise ValueError('Prepared counts are not canonical positive integers')
    depth = np.asarray(x.sum(1)).ravel()
    totals = np.asarray(x.sum(0)).ravel()
    overall = totals.sum()
    proportion = totals/overall
    if not np.isfinite(overall) or overall<=0 or not (depth>0).all() or not (proportion>0).all():
        raise ValueError('Unusable final fixed binary64 margins')
    n,g = x.shape
    unique,multiplicities = np.unique(depth,return_counts=True)
    rng=np.random.default_rng(71305)
    probes={}
    for key,shape in [('v',(g,)),('w',(n,)),('V',(g,8)),('W',(n,8))]:
        a=rng.normal(size=shape)
        a/=np.linalg.norm(a,axis=0)
        probes[key]=a
    sparse.save_npz(out/'counts.npz',x)
    np.savez(out/'parameters.npz',depth=depth,p=proportion)
    np.savez(out/'probes.npz',**probes)
    export_threadpools = threadpool_info()
    if not all(pool['num_threads'] == 1 for pool in export_threadpools):
        raise RuntimeError('Preparation export requires one thread in every registered numerical pool')
    io.mmwrite(out/'counts_gene_by_obs.mtx',x.T,field='integer')
    for key,a in probes.items():
        np.savetxt(out/(key+'.tsv'),a,fmt='%.17g',delimiter='\t')
    np.savetxt(out/'depth.tsv',depth,fmt='%.17g')
    np.savetxt(out/'proportion.tsv',proportion,fmt='%.17g')
    np.savetxt(out/'config.tsv',[100,math.sqrt(n),n,g],fmt='%.17g')
    (out/'observations.tsv').write_text('original_index\tbarcode\n'+''.join(
        f'{int(i)}\t{barcodes[int(i)]}\n' for i in selected_obs))
    (out/'genes.tsv').write_text('original_index\tstable_id\tname\n'+''.join(
        f'{int(i)}\t{ids[int(i)]}\t{names[int(i)]}\n' for i in selected_genes))
    save(out/'selection_indices.json',dict(
        selected_observations_original_indices_before_zero_exclusion=ordered[:min(requested_n,observations)],
        selected_genes_original_indices_before_zero_exclusion=eligible[:requested_g],
        retained_observations_original_indices=selected_obs.tolist(),retained_genes_original_indices=selected_genes.tolist(),
        removed_rows_within_selection=removed_rows.tolist(),removed_columns_within_selection=removed_columns.tolist(),
        removed_rows_original_indices=original_removed_rows.tolist(),removed_columns_original_indices=original_removed_columns.tolist(),
        non_Gene_Expression_original_indices=np.flatnonzero(~gene_expression).tolist(),
        Gene_Expression_nonpositive_on_selected_observations_original_indices=np.flatnonzero(gene_expression&~present).tolist(),
        no_replacement_after_exclusion=True))
    csr_bytes=x.data.nbytes+x.indices.nbytes+x.indptr.nbytes
    metadata=dict(N=n,G=g,nnz=int(x.nnz),CSR_bytes=csr_bytes,orientation_R_counts='genes_by_observations',
        orientation_python_counts='observations_by_genes',memory_budget_bytes=MEMORY_LIMIT,
        theta=100,clip=math.sqrt(n),fixed_parameter_dtype='binary64',source=source['source'],target=target,
        status='PREPARED' if n>=100 and min(n,g)>64 else 'NOT_ADMITTED_DIMENSIONS')
    save(out/'metadata.json',metadata)
    record=dict(name=name,kind='independent_real_target',source=source['source'],target=target,status=metadata['status'],
        source_local_path=source['local_path'],source_sha256=source['sha256'],source_shape_features_by_observations=list(source_shape),
        source_count_dtype='int32 source; retained counts converted to binary64',N=n,G=g,nnz=int(x.nnz),
        density=x.nnz/(n*g),sparsity=1-x.nnz/(n*g),U_d=len(unique),U_d_over_N=len(unique)/n,
        multiplicity=multiplicities.tolist(),multiplicity_summary=distribution(multiplicities),
        depth_min=float(depth.min()),depth_max=float(depth.max()),depth_max_over_min=float(depth.max()/depth.min()),
        depth_distribution=distribution(depth),gene_total_distribution=distribution(totals),
        total_count_binary64=float(overall),maximum_count=float(x.data.max()),CSR_bytes=csr_bytes,
        parameters_bytes=depth.nbytes+proportion.nbytes,probe_bytes=sum(a.nbytes for a in probes.values()),probe_seed=71305,
        requested_observations=requested_n,requested_genes=requested_g,eligible_positive_Gene_Expression_features=len(eligible),
        removed_rows=removed_rows.tolist(),removed_columns=removed_columns.tolist(),
        removed_rows_original_indices=original_removed_rows.tolist(),removed_columns_original_indices=original_removed_columns.tolist(),
        observation_order='SHA256 UTF-8 of NBPEARSON-CONFIRMATORY-V1| plus exact barcode; tie exact barcode',
        gene_order='ascending exact unique stable feature ID positive on this target selected observations',
        margin_contract='CSR binary64 sum(1), CSR binary64 sum(0), NumPy sum of column totals, p=t/M; once after exclusions independently per target',
        no_normalization_log1p_HVG_or_model_fit=True,clipping_order='before gene centering in later algorithms, not applied to saved counts',
        no_dense_count_or_residual_matrix=True,IO_slice_entries=MAX_SLICE_ENTRIES,IO_slice_columns=MAX_SLICE_COLUMNS,
        preparation_preflight=preflight,preparation_seconds=time.perf_counter()-started,
        python_r_parameter_export='%.17g; native run compares little-endian binary64 roundtrip',
        threadpools_before_MatrixMarket_export=export_threadpools)
    record['sha256']={p.name:sha256(p) for p in sorted(out.iterdir()) if p.is_file()}
    save(out/'input.json',record)
    print(name,'PREPARED',n,g,int(x.nnz),'U_d',len(unique),flush=True)
    return record


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-root',type=Path,default=ROOT/'inputs')
    parser.add_argument('--receipt',type=Path,default=ROOT/'REAL_DATA_PREPARATION.json')
    parser.add_argument('--phase-output',type=Path)
    args=parser.parse_args()
    if args.receipt.exists():
        raise RuntimeError('Refusing to overwrite preparation receipt')
    approval=json.loads(APPROVAL.read_text())
    if approval['current_admission_status']!='ADMITTED_UNDER_DOCUMENTARY_AMENDMENT' or not approval['conformity_review']['Mouse_missing_exact_URL_acceptance_explicit']:
        raise ValueError('Approved A1 including Mouse exception required before preparation')
    records=[]
    for source in approval['sources']:
        if source['source'] not in ('pbmc_10k','mouse_brain_nextgem_10k'):
            raise ValueError('Unapproved source; molecule_info is not an input')
        for target,n,g in TARGETS:
            records.append(prepare(source,target,n,g,args.output_root,args.phase_output))
    save(args.receipt,dict(created_utc=datetime.now(timezone.utc).isoformat(),status='PREPARED_FROZEN_TARGETS',
        approval_receipt=str(APPROVAL.relative_to(PROJECT)),approval_receipt_sha256=sha256(APPROVAL),
        protocol='nbpearson_confirmatory_v1/CONFIRMATORY_PROTOCOL.md',protocol_sha256=approval['protocol']['sha256'],
        sources_admitted_under_A1=True,molecule_info_excluded=True,input_count=len(records),inputs=records,
        software=dict(numpy=np.__version__,h5py=h5py.__version__)))


if __name__=='__main__':
    with threadpool_limits(limits=1):
        main()

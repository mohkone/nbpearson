"""Prospective harness only: frozen installed dev1, official Scanpy, direct reference.

CLI: run INPUT OUTPUT METHOD; reference INPUT OUTPUT;
     verify INPUT OUTPUT METHOD_RUN_DIR [REFERENCE_DIR].
No prototype imports, installation, download, or numerical-core edits.
"""
import csv
import json
import math
import inspect
import sys
import time
from pathlib import Path

import numpy as np
import scipy
from scipy import sparse
from scipy.linalg import subspace_angles
from scipy.sparse.linalg import LinearOperator, svds

NB_METHODS = ("interpolated", "interpolated_grouped", "exact_grouped")
STARTED = time.perf_counter()


def memory():
    values = {}
    for line in Path("/proc/self/status").read_text().splitlines():
        if line.startswith(("VmRSS:", "VmHWM:")):
            values[line.split(":")[0]] = int(line.split()[1]) * 1024
    return values


def save(path, values):
    def default(value):
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, np.generic):
            return value.item()
        raise TypeError(type(value).__name__)
    Path(path).write_text(json.dumps(values, default=default, indent=2) + "\n")


def prepare_output(path):
    path = Path(path)
    if path.exists():
        if set(p.name for p in path.iterdir()) - {"process.log"}:
            raise RuntimeError("Refusing existing result directory: " + str(path))
    else:
        path.mkdir(parents=True)
    return path


def phase(output, value):
    (output / "phase.txt").write_text(value)


def load(directory):
    start = time.perf_counter()
    directory = Path(directory)
    x = sparse.load_npz(directory / "counts.npz").astype(np.float64)
    with np.load(directory / "parameters.npz") as f:
        d = np.array(f["depth"] if "depth" in f else f["d"], dtype=np.float64)
        p = np.array(f["p"], dtype=np.float64)
    with np.load(directory / "probes.npz") as f:
        q = {name: np.array(f[name]) for name in ("v", "w", "V", "W")}
    assert x.shape == (len(d), len(p))
    assert np.all(d > 0) and np.all(p > 0)
    assert np.isfinite(x.data).all() and np.all(x.data >= 0)
    assert np.all(x.data == np.floor(x.data))
    assert min(x.shape) >= 64 and x.shape[0] >= 100
    return x, d, p, q, time.perf_counter() - start


def raw_blocks(x, d, p):
    c = math.sqrt(x.shape[0])
    for a in range(0, x.shape[0], 256):
        b = min(a + 256, x.shape[0])
        mu = d[a:b, None] * p[None, :]
        r = (x[a:b].toarray() - mu) / np.sqrt(mu + mu * mu / 100.0)
        yield a, b, np.clip(r, -c, c)


def direct_mean(x, d, p):
    mean = np.zeros(x.shape[1])
    compensation = np.zeros_like(mean)
    for _, _, r in raw_blocks(x, d, p):
        y = r.sum(0) / x.shape[0] - compensation
        updated = mean + y
        compensation = (updated - mean) - y
        mean = updated
    return mean


class Direct(LinearOperator):
    def __init__(self, x, d, p):
        self.x, self.d, self.p = x, d, p
        self.mean = direct_mean(x, d, p)
        super().__init__(dtype=np.dtype(float), shape=x.shape)

    def _matvec(self, v):
        return self._matmat(np.asarray(v).reshape(-1, 1)).ravel()

    def _rmatvec(self, w):
        return self._rmatmat(np.asarray(w).reshape(-1, 1)).ravel()

    def _matmat(self, v):
        result = np.empty((self.shape[0], v.shape[1]))
        for a, b, r in raw_blocks(self.x, self.d, self.p):
            result[a:b] = (r - self.mean) @ v
        return result

    def _rmatmat(self, w):
        result = np.zeros((self.shape[1], w.shape[1]))
        for a, b, r in raw_blocks(self.x, self.d, self.p):
            result += (r - self.mean).T @ w[a:b]
        return result


class DenseCentered(LinearOperator):
    def __init__(self, residual):
        self.residual = np.asarray(residual, dtype=float)
        self.mean = self.residual.mean(0)
        super().__init__(dtype=np.dtype(float), shape=self.residual.shape)

    def _matvec(self, v):
        return self.residual @ v - self.mean @ v

    def _rmatvec(self, w):
        return self.residual.T @ w - self.mean * w.sum()

    def _matmat(self, v):
        return self.residual @ v - (self.mean @ v)[None, :]

    def _rmatmat(self, w):
        return self.residual.T @ w - self.mean[:, None] * w.sum(0)[None, :]


class Counted(LinearOperator):
    def __init__(self, op):
        self.op = op
        self.counts = {k: {"calls": 0, "columns": 0}
                       for k in ("matvec", "rmatvec", "matmat", "rmatmat")}
        super().__init__(dtype=np.dtype(float), shape=op.shape)

    def apply(self, name, values, transpose=False):
        self.counts[name]["calls"] += 1
        self.counts[name]["columns"] += 1 if values.ndim == 1 else values.shape[1]
        return self.op.T @ values if transpose else self.op @ values

    def _matvec(self, v):
        return self.apply("matvec", np.asarray(v).ravel())

    def _rmatvec(self, w):
        return self.apply("rmatvec", np.asarray(w).ravel(), True)

    def _matmat(self, v):
        return self.apply("matmat", v)

    def _rmatmat(self, w):
        return self.apply("rmatmat", w, True)


def scanpy_margins(x, d, p):
    nd = np.asarray(x.sum(1)).ravel()
    totals = np.asarray(x.sum(0)).ravel()
    np_ = totals / totals.sum()
    if not np.array_equal(nd, d) or not np.array_equal(np_, p):
        raise ValueError("Official Scanpy recalculated margins differ from fixed inputs")
    return {"depths_equal": True, "proportions_equal": True}


def construct(method, x, d, p):
    start = time.perf_counter()
    if method in NB_METHODS:
        import nbpearson
        assert nbpearson.__version__ == "0.1.0.dev1"
        assert "src" not in Path(nbpearson.__file__).parts
        fixed = nbpearson.FixedMargins(d, p, nbpearson.counts_fingerprint(x),
                                      "confirmatory_real_v1 frozen full-universe binary64 inputs")
        kwargs = {} if method == "exact_grouped" else {
            "matrix_rtol": 1e-6, "max_nodes": 128, "n_norm_pairs": 16}
        result = nbpearson.build_operator(
            x, representation=method, theta=100., clip=math.sqrt(x.shape[0]),
            margins=fixed, memory_budget_bytes=512 * 2**20, **kwargs)
        meta = {"package_diagnostics": result.diagnostics,
                "permanent_own_bytes": result.diagnostics["operator_storage_bytes"]}
        return result.operator, meta, time.perf_counter() - start
    if method == "direct":
        op = Direct(x, d, p)
        return op, {"permanent_own_bytes": op.mean.nbytes,
                    "scope": "mean only; common sparse inputs separate"}, time.perf_counter()-start
    if method == "scanpy":
        import scanpy as sc
        from anndata import AnnData
        margins = scanpy_margins(x, d, p)
        adata = AnnData(x.astype(np.float64, copy=True))
        sc.experimental.pp.normalize_pearson_residuals(
            adata, theta=100., clip=math.sqrt(x.shape[0]), check_values=True, inplace=True)
        op = DenseCentered(adata.X)
        return op, {"margins": margins,
                    "permanent_own_bytes": op.residual.nbytes+op.mean.nbytes}, time.perf_counter()-start
    raise ValueError(method)


def approximation_rows(op, method, a, b):
    if method == "scanpy":
        return op.residual[a:b] - op.mean
    if method == "direct":
        raise ValueError("Direct reference cannot be its own matrix verifier")
    result = op._correction[a:b].toarray() - op._mean
    if method == "exact_grouped":
        return result + op._table[op._groups[a:b]]
    left = op._left[a:b] if method == "interpolated" else op._left[op._groups[a:b]]
    return result + left @ op._right.T


def error(actual, expected):
    absolute = float(np.linalg.norm(actual-expected))
    norm = float(np.linalg.norm(expected))
    return {"absolute_error": absolute, "reference_norm": norm,
            "relative_error": absolute/norm if norm else None}


def initialize(method):
    if method == "scanpy":
        import scanpy
        version = {"scanpy": scanpy.__version__}
    elif method in NB_METHODS:
        import nbpearson
        assert nbpearson.__version__ == "0.1.0.dev1"
        assert "src" not in Path(nbpearson.__file__).parts
        version = {"nbpearson": nbpearson.__version__, "package_file": nbpearson.__file__}
    else:
        version = {}
    from threadpoolctl import threadpool_info
    pools = threadpool_info()
    if any(pool.get("num_threads") != 1 for pool in pools):
        raise RuntimeError("Numerical thread policy violated")
    if method == "scanpy":
        version["normalize_pearson_residuals_signature"] = str(inspect.signature(scanpy.experimental.pp.normalize_pearson_residuals))
        version["normalize_pearson_residuals_pca_signature"] = str(inspect.signature(scanpy.experimental.pp.normalize_pearson_residuals_pca))
    return {"python": sys.version.split()[0], "numpy": np.__version__,
            "scipy": scipy.__version__, **version, "threadpools": pools,
            "rss_after_imports": memory()}



def scanpy_preflight(x, imports):
    """Frozen dense admission formula, before Scanpy construction or SVD."""
    baseline = int(imports["rss_after_imports"]["VmRSS"])
    csr_bytes = sum(a.nbytes for a in (x.data, x.indices, x.indptr))
    estimate = baseline + 6 * 8 * x.shape[0] * x.shape[1] + 3 * csr_bytes + 64 * 2**20
    return dict(status="ADMITTED" if estimate <= 512 * 2**20
                else "NOT_RUN_DENSE_MEMORY_PREFLIGHT",
                baseline_after_import_bytes=baseline, csr_bytes=int(csr_bytes),
                estimated_peak_bytes=int(estimate), memory_budget_bytes=512 * 2**20,
                formula="baseline_after_import+6*8*N*G+3*CSR_bytes+64MiB",
                policy="estimated admission; not measured OOM or universal RSS guarantee")


def run(input_dir, output, method):
    imports = initialize(method)
    x, d, p, q, loading = load(input_dir)
    assert min(x.shape)>64, "Frozen ARPACK ncv64 requires min(shape)>64"
    info = {"method": method, "loading_seconds": loading, **imports,
            "rss_after_loading": memory(), "N": x.shape[0], "G": x.shape[1],
            "nnz": x.nnz, "U_d": len(np.unique(d))}
    if method == "scanpy":
        phase(output, "memory_preflight")
        admission = scanpy_preflight(x, imports)
        save(output / "preflight.json", admission)
        info["memory_preflight"] = admission
        if admission["status"] != "ADMITTED":
            info.update(status="NOT_RUN_DENSE_MEMORY_PREFLIGHT",
                        solver_status="NOT_EXECUTED", construction_seconds=None,
                        pca_seconds=None, construction_pca_seconds=None,
                        script_seconds=time.perf_counter()-STARTED,
                        rss_at_end=memory())
            save(output / "pipeline.json", info)
            phase(output, "not_run_dense_memory_preflight")
            return
    phase(output, "pipeline")
    begin = time.perf_counter()
    if method != "scanpy":
        phase(output, "construction")
        op, meta, construction = construct(method, x, d, p)
        counted = Counted(op)
        phase(output, "PCA")
        t = time.perf_counter()
        u, s, vt = svds(counted, k=21, ncv=64, tol=1e-10, maxiter=10000,
                       solver="arpack", v0=np.random.default_rng(6619).normal(size=min(x.shape)))
        pca = time.perf_counter()-t
        info.update(counts=counted.counts, solver="SciPy ARPACK",
                    solver_settings={"k":21,"ncv":64,"tol":1e-10,"maxiter":10000,
                                     "v0":"Gaussian seed6619"})
    else:
        import scanpy as sc
        from anndata import AnnData
        from scanpy.experimental.pp import _normalization as native
        times = {}
        original_norm, original_pca = native.normalize_pearson_residuals, native.pca
        def measured_norm(*args, **kwargs):
            phase(output, "construction_native_scanpy")
            t = time.perf_counter()
            value = original_norm(*args, **kwargs)
            times["normalization"] = time.perf_counter()-t
            return value
        def measured_pca(*args, **kwargs):
            phase(output, "PCA_native_scanpy")
            t = time.perf_counter()
            value = original_pca(*args, **kwargs)
            times["pca"] = time.perf_counter()-t
            return value
        margin_status = scanpy_margins(x, d, p)
        adata = AnnData(x.astype(np.float64, copy=True))
        native.normalize_pearson_residuals, native.pca = measured_norm, measured_pca
        try:
            result = sc.experimental.pp.normalize_pearson_residuals_pca(
                adata, theta=100., clip=math.sqrt(x.shape[0]), n_comps=21,
                random_state=6619,
                kwargs_pca=dict(zero_center=True,svd_solver="arpack",mask_var=None,dtype="float64"),
                mask_var=None,check_values=True,inplace=False)
        finally:
            native.normalize_pearson_residuals, native.pca = original_norm, original_pca
        s = np.sqrt(result.uns["pca"]["variance"]*(x.shape[0]-1))
        vt = np.asarray(result.varm["PCs"]).T
        u = np.asarray(result.obsm["X_pca"])/s
        pca = times["pca"]
        construction = time.perf_counter()-begin-pca
        meta = {"margins":margin_status,"normalization_seconds":times["normalization"]}
        op = None
        info.update(counts="NOT_EXPOSED_BY_NATIVE_API",
                    solver="Scanpy official / sklearn PCA ARPACK",
                    solver_settings={"k":21,"random_state":6619,"tol":0,
                                     "ncv":"NOT_EXPOSED","maxiter":"NOT_EXPOSED",
                                     "v0":"native sklearn; not Gaussian identity"})
    total = time.perf_counter()-begin
    phase(output, "pipeline_done")
    order = np.argsort(s)[::-1]
    u, s, vt = u[:,order], s[order], vt[order]
    if not (np.isfinite(u).all() and np.isfinite(s).all() and np.isfinite(vt).all()):
        raise FloatingPointError("Nonfinite SVD output")
    info.update(status="COMPLETED",solver_status="CONVERGED",metadata=meta,
                construction_seconds=construction,pca_seconds=pca,
                construction_pca_seconds=total,gap_20_21=float(s[19]-s[20]),
                rss_after_pipeline=memory(),niter="NOT_EXPOSED")
    if method == "scanpy":
        t = time.perf_counter()
        op = DenseCentered(result.X)
        info["post_pipeline_product_adapter_seconds"] = time.perf_counter()-t
        info["metadata"]["permanent_own_bytes"] = op.residual.nbytes+op.mean.nbytes
    phase(output, "products")
    outputs = {}
    rows = []
    for name, operand, transpose in [
            ("matvec",q["v"],False),("rmatvec",q["w"],True),
            ("matmat8",q["V"],False),("rmatmat8",q["W"],True)]:
        fn = (lambda: op.T @ operand) if transpose else (lambda: op @ operand)
        fn()
        for call in range(1,11):
            t = time.perf_counter()
            actual = fn()
            seconds = time.perf_counter()-t
            if not np.isfinite(actual).all():
                raise FloatingPointError("Nonfinite product")
            rows.append({"operation":name,"call":call,"seconds":seconds,
                         "columns":8 if name.endswith("8") else 1})
        outputs[name] = actual
    phase(output, "export")
    t = time.perf_counter()
    np.savez(output/"solution.npz",u=u,s=s,vt=vt)
    np.savez(output/"product_outputs.npz",**outputs)
    with (output/"products.csv").open("w") as f:
        writer = csv.DictWriter(f,fieldnames=["operation","call","seconds","columns"])
        writer.writeheader(); writer.writerows(rows)
    info.update(export_seconds=time.perf_counter()-t,rss_at_end=memory(),
                script_seconds=time.perf_counter()-STARTED)
    save(output/"pipeline.json",info)
    phase(output, "done")


def verify(input_dir, output, run_dir, reference_dir=None):
    started = time.perf_counter()
    run_dir = Path(run_dir)
    run_info = json.loads((run_dir/"pipeline.json").read_text())
    method = run_info["method"]
    imports = initialize(method)
    x,d,p,q,loading = load(input_dir)
    op,meta,construction = construct(method,x,d,p)
    mean = direct_mean(x,d,p)
    norm_terms,error_terms = [],[]
    forward = np.empty((x.shape[0],9))
    reverse = np.zeros((x.shape[1],9))
    V = np.column_stack((q["v"],q["V"]))
    W = np.column_stack((q["w"],q["W"]))
    with np.load(run_dir/"solution.npz") as f:
        u,s,vt = f["u"],f["s"],f["vt"]
    av = np.empty((x.shape[0],20))
    atu = np.zeros((x.shape[1],20))
    for a,b,raw in raw_blocks(x,d,p):
        truth = raw-mean
        approx = approximation_rows(op,method,a,b)
        norm_terms.append(float(np.sum(truth*truth)))
        error_terms.append(float(np.sum((approx-truth)**2)))
        forward[a:b] = truth@V
        reverse += truth.T@W[a:b]
        av[a:b] = truth@vt[:20].T
        atu += truth.T@u[a:b,:20]
    norm = math.sqrt(math.fsum(norm_terms))
    absolute = math.sqrt(math.fsum(error_terms))
    relative = absolute/norm if norm else None
    products = {kind:error(actual,expected) for kind,actual,expected in [
        ("matvec",op@q["v"],forward[:,0]),
        ("rmatvec",op.T@q["w"],reverse[:,0]),
        ("matmat8",op@q["V"],forward[:,1:]),
        ("rmatmat8",op.T@q["W"],reverse[:,1:])]}
    adjoint = abs(float(q["w"]@(op@q["v"])-(op.T@q["w"])@q["v"]))
    center = float(np.linalg.norm(op.T@np.ones(x.shape[0])))
    left = float(np.linalg.norm(av-u[:,:20]*s[:20]))
    right = float(np.linalg.norm(atu-vt[:20].T*s[:20]))
    snorm = float(np.linalg.norm(s[:20]))
    residual = max(left,right)/snorm if snorm else None
    matrix_ok = relative is not None and relative<=1e-6
    product_ok = all(e["relative_error"] is not None and e["relative_error"]<=1e-6
                     for e in products.values())
    adjoint_scaled = adjoint/norm if norm else None
    center_scaled = center/(norm*math.sqrt(x.shape[0])) if norm else None
    numeric_ok = matrix_ok and product_ok and adjoint_scaled<=1e-6 and center_scaled<=1e-6
    triplet_ok = residual is not None and residual<=1e-8
    out = dict(status="VERIFIED_AT_COMMON_TOLERANCE" if numeric_ok and triplet_ok else "OUTSIDE_COMMON_TOLERANCE",
               method=method,matrix_absolute_error=absolute,reference_norm=norm,
               matrix_relative_error=relative,products=products,
               matrix_status="SATISFIED" if matrix_ok else "OUTSIDE_OR_UNDEFINED",
               adjoint_absolute_error=adjoint,adjoint_scaled_error=adjoint_scaled,
               center_absolute_error=center,center_scaled_error=center_scaled,
               Av_residual_absolute=left,ATu_residual_absolute=right,
               triplet_relative_residual=residual,
               triplet_status="SATISFIED" if triplet_ok else "OUTSIDE_OR_UNDEFINED",
               left_orthogonality_error=float(np.linalg.norm(u[:,:20].T@u[:,:20]-np.eye(20))),
               right_orthogonality_error=float(np.linalg.norm(vt[:20]@vt[:20].T-np.eye(20))),
               gap_20_21=float(s[19]-s[20]),subspace_status="NOT_EVALUATED",
               metadata=meta,loading_seconds=loading,construction_seconds=construction,**imports)
    if reference_dir is not None:
        reference_dir = Path(reference_dir)
        ref_info = json.loads((reference_dir/"pipeline.json").read_text())
        assert ref_info["status"]=="COMPLETED" and ref_info["method"]=="direct"
        with np.load(reference_dir/"solution.npz") as f:
            rs,ru,rvt=f["s"],f["u"],f["vt"]
        gap = float(rs[19]-rs[20])
        singular = None if np.any(rs[:20]==0) else float(np.max(abs(s[:20]-rs[:20])/abs(rs[:20])))
        interpretable = gap>2*absolute+max(left,right)
        out.update(reference_gap_20_21=gap,singular_relative_error=singular,
                   subspace_status="EVALUATED_WITH_GAP" if interpretable else "NOT_INTERPRETABLE_GAP",
                   left_angle_radians=float(subspace_angles(u[:,:20],ru[:,:20]).max()) if interpretable else None,
                   right_angle_radians=float(subspace_angles(vt[:20].T,rvt[:20].T).max()) if interpretable else None)
        if singular is None or singular>1e-6 or (interpretable and max(out["left_angle_radians"],out["right_angle_radians"])>1e-6):
            out["status"]="FINAL_PRECISION_OUTSIDE_TOLERANCE"
    out.update(verification_seconds=time.perf_counter()-started,rss_at_end=memory(),
               floating_point_certificate=False)
    save(output/"verification.json",out)
    phase(output,"done")



def qualify(input_dir, output, method):
    imports = initialize(method)
    x,d,p,q,loading=load(input_dir)
    if method == 'scanpy':
        admission=scanpy_preflight(x,imports)
        save(output/'preflight.json',admission)
        if admission['status']!='ADMITTED':
            save(output/'qualification.json',dict(status='NOT_RUN_DENSE_MEMORY_PREFLIGHT',method=method,memory_preflight=admission,loading_seconds=loading,**imports))
            phase(output,'not_run_dense_memory_preflight')
            return
    op,meta,construction=construct(method,x,d,p)
    mean=direct_mean(x,d,p)
    terms=[];norms=[];forward=np.empty((x.shape[0],9));reverse=np.zeros((x.shape[1],9))
    V=np.column_stack((q['v'],q['V']));W=np.column_stack((q['w'],q['W']))
    for a,b,raw in raw_blocks(x,d,p):
        truth=raw-mean;candidate=approximation_rows(op,method,a,b)
        terms.append(float(np.sum((candidate-truth)**2)));norms.append(float(np.sum(truth**2)))
        forward[a:b]=truth@V;reverse+=truth.T@W[a:b]
    norm=math.sqrt(math.fsum(norms));absolute=math.sqrt(math.fsum(terms))
    prod={k:error(a,b) for k,a,b in [('matvec',op@q['v'],forward[:,0]),('rmatvec',op.T@q['w'],reverse[:,0]),('matmat8',op@q['V'],forward[:,1:]),('rmatmat8',op.T@q['W'],reverse[:,1:])]}
    adj=abs(float(q['w']@(op@q['v'])-(op.T@q['w'])@q['v']))
    center=float(np.linalg.norm(op.T@np.ones(x.shape[0])))
    save(output/'qualification.json',dict(status='QUALIFICATION_OBSERVED_NOT_CERTIFIED',method=method,matrix_absolute_error=absolute,reference_norm=norm,matrix_relative_error=absolute/norm if norm else None,products=prod,adjoint_scaled_error=adj/norm if norm else None,center_scaled_error=center/(norm*np.sqrt(x.shape[0])) if norm else None,construction_seconds=construction,metadata=meta,loading_seconds=loading,**imports))
    phase(output,'done')

def main_impl():
    action,input_dir,output_dir = sys.argv[1:4]
    output = prepare_output(output_dir)
    phase(output,"setup")
    if action=="qualify":
        qualify(input_dir,output,sys.argv[4])
    elif action=="run":
        run(input_dir,output,sys.argv[4])
    elif action=="reference":
        run(input_dir,output,"direct")
    elif action=="verify":
        phase(output,"verification")
        verify(input_dir,output,sys.argv[4],sys.argv[5] if len(sys.argv)>5 else None)
    else:
        raise ValueError(action)


def main():
    try:
        main_impl()
    except Exception as exc:
        output = Path(sys.argv[3]) if len(sys.argv) > 3 else None
        kind = type(exc).__name__
        if kind == "ResourceLimitError":
            status = "RESOURCE_ADMISSION_REFUSED"
        elif kind == "SelectionError":
            status = "ANALYTICAL_SELECTION_REFUSED"
        elif kind == "ArpackNoConvergence":
            status = "SOLVER_NONCONVERGENCE"
        elif isinstance(exc, MemoryError):
            status = "MEMORY_ALLOCATION_FAILURE"
        elif isinstance(exc, FloatingPointError):
            status = "NONFINITE_NUMERICAL_RESULT"
        elif isinstance(exc, (ValueError, AssertionError)):
            status = "INPUT_OR_CONTRACT_ERROR"
        else:
            status = "HARNESS_OR_RUNTIME_ERROR"
        if output is not None and output.is_dir():
            phase_file = output / "phase.txt"
            save(output / "error.json", dict(
                status=status, exception_type=kind, message=str(exc),
                failed_phase=phase_file.read_text().strip() if phase_file.exists() else "setup",
                diagnostics=getattr(exc, "diagnostics", None),
                partial_eigenvalues_count=len(getattr(exc, "eigenvalues", [])),
                script_seconds=time.perf_counter()-STARTED, rss_at_failure=memory()))
        raise


if __name__=="__main__":
    main()

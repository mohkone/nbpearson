#!/usr/bin/env Rscript
# Harness-only adaptation of local_run_031/bpcells_compare.R.
# Native BPCells transformation and Spectra remain unchanged.
# Rscript --vanilla native_bpcells.R {qualify|run|verify} INPUT OUTPUT {FALSE|TRUE}
# Real-data harness revision: frozen preflights, margin binding, streamed verification.
# INPUT: counts_gene_by_obs.mtx, depth.tsv, proportion.tsv,
# config.tsv = theta, clip, N, G, and v.tsv,w.tsv,V.tsv,W.tsv.
# For qualify only: oracle_obs_by_gene.tsv (tiny independent reference).
# Do not execute measurements until the parent protocol has been frozen.

args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==4L, args[[1]] %in% c("qualify","run","verify"),
          args[[4]] %in% c("FALSE","TRUE"))
action <- args[[1]]
input <- normalizePath(args[[2]], mustWork=TRUE)
output <- args[[3]]
slow <- identical(args[[4]],"TRUE")
if (dir.exists(output)) {
    existing <- list.files(output,all.files=TRUE,no..=TRUE)
    # A fresh external watchdog may already have opened its process log.
    if (length(setdiff(existing,"process.log"))) {
        stop("Refusing to overwrite an existing result directory")
    }
} else dir.create(output,recursive=TRUE,showWarnings=FALSE)
phase <- function(value) writeLines(value,file.path(output,"phase.txt"))
phase("setup")
elapsed <- function() proc.time()[[3]]
process_started <- elapsed()
rss <- function() {
    lines <- readLines("/proc/self/status",warn=FALSE)
    extract <- function(key) {
        value <- lines[startsWith(lines,paste0(key,":"))]
        if (!length(value)) return(NA_real_)
        as.numeric(strsplit(trimws(sub(paste0(key,":"),"",value[[1]])),
                            "[[:space:]]+")[[1]][[1]])*1024
    }
    list(rss_bytes=extract("VmRSS"),high_water_bytes=extract("VmHWM"))
}
rss_before_import <- rss()
suppressPackageStartupMessages({
    library(BPCells)
    library(Matrix)
    library(jsonlite)
})
stopifnot(as.character(packageVersion("BPCells"))=="0.3.1")
options(digits=17)
rss_after_import <- rss()
imports_seconds <- elapsed()-process_started
required <- c("sctransform_pearson","svds","add_rows","convert_matrix_type")
stopifnot(all(required %in% getNamespaceExports("BPCells")))
required_formals <- c("mat","gene_theta","gene_beta","cell_read_counts",
                      "min_var","clip_range","columns_are_cells","slow")
stopifnot(all(required_formals %in% names(formals(BPCells::sctransform_pearson))))
# This is the already-qualified historical native one-thread matrix product
# wrapper. It does not replace a BPCells operation with a local numerical port.
serial <- function(mat) {
    getFromNamespace("parallel_split","BPCells")(mat,threads=1L,chunks=4L)
}
write_json(list(
    R=R.version.string,
    R_version=unclass(R.version),
    external_software_versions=as.list(extSoftVersion()),
    BPCells_package_path=system.file(package="BPCells"),
    BPCells=as.character(packageVersion("BPCells")),
    Matrix=as.character(packageVersion("Matrix")),
    jsonlite=as.character(packageVersion("jsonlite")),
    description=as.list(packageDescription("BPCells"))[c("Version","Built",
        "RemoteSha","GithubSHA1","RemoteRepo","RemoteRef")],
    transform_formals=names(formals(BPCells::sctransform_pearson)),
    svds_formals=names(formals(BPCells::svds)),
    threads=as.list(Sys.getenv(c("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS","BLIS_NUM_THREADS","VECLIB_MAXIMUM_THREADS"))),
    native_product_wrapper="parallel_split(mat,threads=1,chunks=4)",
    native_initialization="set.seed(6619); no public native v0 argument; not identical to SciPy",
    rss_before_import=rss_before_import,
    rss_after_import=rss_after_import
),file.path(output,"provenance.json"),auto_unbox=TRUE,pretty=TRUE,digits=NA,null="null")
capture.output(sessionInfo(),file=file.path(output,"sessionInfo.txt"))
dput(body(getFromNamespace("parallel_split","BPCells")),
     file=file.path(output,"installed_parallel_split.R"))

# Read only the small frozen configuration/metadata before allocating counts.
phase("preflight_before_loading")
config <- scan(file.path(input,"config.tsv"),quiet=TRUE)
metadata_path <- file.path(input,"metadata.json")
if (!file.exists(metadata_path)) metadata_path <- file.path(input,"input.json")
metadata <- read_json(metadata_path,simplifyVector=TRUE)
stopifnot(length(config)==4L,config[[1]]==100,config[[2]]>=sqrt(config[[1]]),
          as.numeric(metadata$N)==config[[3]],as.numeric(metadata$G)==config[[4]])
N <- as.integer(config[[3]])
G <- as.integer(config[[4]])
NNZ <- as.numeric(metadata$nnz)
csr_bytes <- if (!is.null(metadata$CSR_bytes)) as.numeric(metadata$CSR_bytes) else
             if (!is.null(metadata$csr_bytes)) as.numeric(metadata$csr_bytes) else
             12*NNZ+4*(N+1)
stopifnot(is.finite(csr_bytes),csr_bytes>0,is.finite(NNZ),NNZ>=0)
preflight_estimate <- rss_after_import$rss_bytes+4*csr_bytes+
                     6*8*256*G+64*2^20+4*8*(N+G)*64
preflight <- function(stage) {
    record <- list(status=if(preflight_estimate<=512*2^20)
                         "ADMITTED_ESTIMATED" else "NOT_RUN_MEMORY_PREFLIGHT",
        stage=stage,N=N,G=G,nnz=NNZ,CSR_bytes=csr_bytes,
        baseline_after_import_bytes=rss_after_import$rss_bytes,
        estimated_peak_bytes=preflight_estimate,memory_budget_bytes=512*2^20,
        formula="baseline_after_import+4*CSR_bytes+6*8*256*G+64MiB+4*8*(N+G)*64",
        current_rss=rss(),admission_is_RSS_guarantee=FALSE)
    write_json(record,file.path(output,paste0("preflight_",stage,".json")),
               auto_unbox=TRUE,pretty=TRUE,digits=NA,null="null")
    if (preflight_estimate>512*2^20) {
        write_json(c(record,list(slow=slow,action=action)),
                   file.path(output,"pipeline.json"),
                   auto_unbox=TRUE,pretty=TRUE,digits=NA,null="null")
        phase("not_run_memory_preflight")
        quit(status=0L)
    }
    invisible(record)
}
preflight("before_loading")
phase("loading")
load_started <- elapsed()
X <- methods::as(Matrix::readMM(file.path(input,"counts_gene_by_obs.mtx")),"dgCMatrix")
n <- scan(file.path(input,"depth.tsv"),quiet=TRUE)
p <- scan(file.path(input,"proportion.tsv"),quiet=TRUE)
config <- scan(file.path(input,"config.tsv"),quiet=TRUE)
q <- list(
    v=matrix(scan(file.path(input,"v.tsv"),quiet=TRUE),ncol=1L),
    w=matrix(scan(file.path(input,"w.tsv"),quiet=TRUE),ncol=1L),
    V=as.matrix(read.table(file.path(input,"V.tsv"))),
    W=as.matrix(read.table(file.path(input,"W.tsv")))
)
stopifnot(nrow(X)==G,ncol(X)==N,length(X@x)==NNZ)
loading_seconds <- elapsed()-load_started
rss_after_loading <- rss()
# Cross-runtime parameter round-trip, outside construction/PCA timing.
margin_connection <- file(file.path(output,"roundtrip_margins.bin"),"wb")
writeBin(c(n,p),margin_connection,size=8L,endian="little")
close(margin_connection)
validate_input <- function() {
    stopifnot(length(config)==4L,
        config[[1]]==100,config[[2]]>=sqrt(config[[1]]),
        nrow(X)==length(p),ncol(X)==length(n),
        ncol(X)==config[[3]],nrow(X)==config[[4]],
        all(is.finite(X@x)),all(X@x>=0),all(X@x==floor(X@x)),
        all(is.finite(n)),all(n>0),all(is.finite(p)),all(p>0),
        all(p<=1),abs(sum(p)-1)<=8*.Machine$double.eps,
        nrow(q$v)==nrow(X),nrow(q$V)==nrow(X),
        nrow(q$w)==ncol(X),nrow(q$W)==ncol(X),
        ncol(q$V)==8L,ncol(q$W)==8L,
        all(vapply(q,function(a)all(is.finite(a)),logical(1))))
    # Validation only: never replace the frozen binary64 margins.
    observed_n <- as.numeric(Matrix::colSums(X))
    observed_t <- as.numeric(Matrix::rowSums(X))
    observed_p <- observed_t/sum(observed_t)
    stopifnot(identical(as.double(n),observed_n),
              identical(as.double(p),observed_p))
}
construct <- function() {
    start <- elapsed()
    validate_input()
    iterable <- methods::as(X,"IterableMatrix")
    iterable <- BPCells::convert_matrix_type(iterable,"double")
    raw <- BPCells::sctransform_pearson(
        iterable,gene_theta=rep(config[[1]],nrow(X)),gene_beta=p,
        cell_read_counts=n,min_var=0,
        clip_range=c(-config[[2]],config[[2]]),
        columns_are_cells=TRUE,slow=slow)
    mean_started <- elapsed()
    means <- as.numeric(serial(raw)%*%matrix(1/ncol(X),ncol(X),1L))
    centered <- serial(BPCells::add_rows(raw,-means))
    stopifnot(methods::is(centered,"IterableMatrix"),all(is.finite(means)))
    list(mat=centered,means=means,
        mean_seconds=elapsed()-mean_started,
        construction_seconds=elapsed()-start)
}
relative_error <- function(actual,reference) {
    absolute <- sqrt(sum((actual-reference)^2))
    norm <- sqrt(sum(reference^2))
    list(absolute=absolute,reference_norm=norm,
         relative=if(norm==0)NULL else absolute/norm)
}
write_numeric <- function(a,name) {
    write.table(a,file.path(output,name),sep="\t",row.names=FALSE,col.names=FALSE)
}

# Independent direct binary64 reference: no BPCells reconstruction on truth side.
raw_reference_block <- function(indices) {
    mu <- outer(p,n[indices])
    value <- (as.matrix(X[,indices,drop=FALSE])-mu)/sqrt(mu+mu*mu/config[[1]])
    pmin(pmax(value,-config[[2]]),config[[2]])
}
compensated_add <- function(total,compensation,term) {
    increment <- term-compensation
    updated <- total+increment
    list(total=updated,compensation=(updated-total)-increment)
}
verify_matrix <- function(built) {
    start <- elapsed()
    block_starts <- seq.int(1L,N,by=256L)
    reference_mean <- numeric(G)
    mean_compensation <- numeric(G)
    for (first in block_starts) {
        indices <- seq.int(first,min(first+255L,N))
        raw <- raw_reference_block(indices)
        stopifnot(all(is.finite(raw)))
        z <- compensated_add(reference_mean,mean_compensation,rowSums(raw)/N)
        reference_mean <- z$total
        mean_compensation <- z$compensation
    }
    norm_total <- 0
    norm_compensation <- 0
    error_total <- 0
    error_compensation <- 0
    centered_mean <- numeric(G)
    centered_compensation <- numeric(G)
    joined_v <- cbind(q$v,q$V)
    joined_w <- cbind(q$w,q$W)
    direct_forward <- matrix(0,N,ncol(joined_v))
    direct_reverse <- matrix(0,G,ncol(joined_w))
    reverse_compensation <- matrix(0,G,ncol(joined_w))
    for (first in block_starts) {
        indices <- seq.int(first,min(first+255L,N))
        truth <- raw_reference_block(indices)-reference_mean
        actual <- as.matrix(built$mat[,indices,drop=FALSE])
        stopifnot(identical(dim(truth),dim(actual)),all(is.finite(actual)),
                  ncol(actual)<=256L,nrow(actual)==G)
        # Two-pass centered squared norm, never sum(T^2)-N*mean(T)^2.
        z <- compensated_add(norm_total,norm_compensation,sum(truth*truth))
        norm_total <- z$total
        norm_compensation <- z$compensation
        difference <- actual-truth
        z <- compensated_add(error_total,error_compensation,sum(difference*difference))
        error_total <- z$total
        error_compensation <- z$compensation
        z <- compensated_add(centered_mean,centered_compensation,rowSums(actual)/N)
        centered_mean <- z$total
        centered_compensation <- z$compensation
        direct_forward[indices,] <- t(truth)%*%joined_v
        z <- compensated_add(direct_reverse,reverse_compensation,
                             truth%*%joined_w[indices,,drop=FALSE])
        direct_reverse <- z$total
        reverse_compensation <- z$compensation
    }
    actual_products <- list(
        matvec=t(built$mat)%*%q$v,
        rmatvec=built$mat%*%q$w,
        matmat8=t(built$mat)%*%q$V,
        rmatmat8=built$mat%*%q$W)
    expected_products <- list(
        matvec=direct_forward[,1L,drop=FALSE],
        rmatvec=direct_reverse[,1L,drop=FALSE],
        matmat8=direct_forward[,-1L,drop=FALSE],
        rmatmat8=direct_reverse[,-1L,drop=FALSE])
    product_errors <- lapply(names(actual_products),function(name) {
        actual <- actual_products[[name]]
        expected <- expected_products[[name]]
        stopifnot(identical(dim(actual),dim(expected)),all(is.finite(actual)))
        e <- relative_error(actual,expected)
        product_pass <- if(e$reference_norm==0)e$absolute<=1e-12 else e$relative<=1e-6
        list(absolute_error=e$absolute,reference_norm=e$reference_norm,
             relative_error=e$relative,
             relative_status=if(e$reference_norm==0)"UNDEFINED_ZERO_REFERENCE" else "DEFINED",
             status=if(product_pass)"SATISFIED" else "OUTSIDE_TOLERANCE")
    })
    names(product_errors) <- names(actual_products)
    absolute <- sqrt(error_total)
    norm <- sqrt(norm_total)
    relative <- if(norm==0)NULL else absolute/norm
    center_absolute <- sqrt(sum(centered_mean*centered_mean))
    center_scaled <- if(norm==0)NULL else center_absolute*sqrt(N)/norm
    pass <- if(norm==0)absolute<=1e-12 else relative<=1e-6
    center_pass <- if(norm==0)center_absolute*sqrt(N)<=1e-12 else center_scaled<=1e-6
    adjoint_absolute <- abs(sum(q$w*actual_products$matvec)-
                            sum(q$v*actual_products$rmatvec))
    adjoint_scaled <- if(norm==0)NULL else adjoint_absolute/norm
    adjoint_pass <- if(norm==0)adjoint_absolute<=1e-12 else adjoint_scaled<=1e-6
    products_pass <- all(vapply(product_errors,function(e)e$status=="SATISFIED",logical(1)))
    list(status=if(pass&&center_pass&&adjoint_pass&&products_pass)"SATISFIED" else "OUTSIDE_TOLERANCE",
         slow=slow,N=N,G=G,nnz=NNZ,
         matrix_absolute_error=absolute,reference_norm=norm,
         matrix_relative_error=relative,
         relative_status=if(norm==0)"UNDEFINED_ZERO_REFERENCE" else "DEFINED",
         matrix_threshold=if(norm==0)1e-12 else 1e-6,
         threshold_contract=if(norm==0)"named_zero_reference_absolute" else "relative",
         matrix_status=if(pass)"SATISFIED" else "OUTSIDE_TOLERANCE",
         # Interface: absolute is the norm of column sums; mean norm is separate.
         center_absolute_error=center_absolute*N,
         center_mean_norm=center_absolute,
         center_absolute_units="norm_of_centered_column_sums",
         center_reference_scaled_error=center_scaled,
         center_status=if(center_pass)"SATISFIED" else "OUTSIDE_TOLERANCE",
         products=product_errors,
         adjoint_absolute_error=adjoint_absolute,
         adjoint_reference_scaled_error=adjoint_scaled,
         adjoint_status=if(adjoint_pass)"SATISFIED" else "OUTSIDE_TOLERANCE",
         reference_mean_norm=sqrt(sum(reference_mean*reference_mean)),
         native_mean_difference_norm=sqrt(sum((built$means-reference_mean)^2)),
         reference_method="Independent direct binary64 NB formula in blocks of at most256 observations, compensated mean accumulation, second-pass centered squared norms",
         floating_point_certificate=FALSE,
         frozen_margins_validated_against_exported_counts=TRUE,
         margin_inputs_recalculated_for_use=FALSE,
         counts_orientation="genes_by_observations",
         mathematical_target_orientation="observations_by_genes",
         construction_seconds=built$construction_seconds,
         mean_seconds=built$mean_seconds,
         verification_seconds=elapsed()-start,
         imports_seconds=imports_seconds,loading_seconds=loading_seconds,
         rss_after_import=rss_after_import,rss_after_loading=rss_after_loading,
         rss_at_end=rss())
}

preflight("before_pipeline")
phase("construction")
built <- construct()
if (action=="verify") {
    phase("verification")
    verification <- verify_matrix(built)
    verification$script_elapsed_seconds <- elapsed()-process_started
    write_json(verification,file.path(output,"verification_matrix.json"),
               auto_unbox=TRUE,pretty=TRUE,digits=NA,null="null")
} else if (action=="qualify") {
    stopifnot(nrow(X)*ncol(X)<=40000L)
    reference <- as.matrix(read.table(file.path(input,"oracle_obs_by_gene.tsv")))
    actual <- t(as.matrix(built$mat))
    stopifnot(identical(dim(actual),dim(reference)),all(is.finite(actual)))
    product_outputs <- list(
        matvec=t(built$mat)%*%q$v,
        rmatvec=built$mat%*%q$w,
        matmat8=t(built$mat)%*%q$V,
        rmatmat8=built$mat%*%q$W)
    expected <- list(
        matvec=reference%*%q$v,
        rmatvec=t(reference)%*%q$w,
        matmat8=reference%*%q$V,
        rmatmat8=t(reference)%*%q$W)
    errors <- lapply(names(product_outputs),function(name)
        relative_error(product_outputs[[name]],expected[[name]]))
    names(errors) <- names(product_outputs)
    write_json(list(status="QUALIFICATION_OBSERVED_NOT_CERTIFIED",slow=slow,
        matrix=relative_error(actual,reference),products=errors,
        center_absolute=sqrt(sum(colMeans(actual)^2)),
        adjoint_absolute=abs(sum(q$w*product_outputs$matvec)-
                             sum(q$v*product_outputs$rmatvec)),
        construction_seconds=built$construction_seconds,
        loading_seconds=loading_seconds,
        rss_after_import=rss_after_import,rss_after_loading=rss_after_loading,
        rss_at_end=rss()
    ),file.path(output,"qualification.json"),auto_unbox=TRUE,pretty=TRUE,
      digits=NA,null="null")
    write_numeric(actual,"actual_obs_by_gene.tsv")
} else {
    stopifnot(21L<min(dim(X)),64L<=min(dim(X)))
    preflight("before_SVD")
    phase("PCA")
    set.seed(6619)
    pca_started <- elapsed()
    fit <- BPCells::svds(
        built$mat,k=21L,nu=21L,nv=21L,
        opts=list(ncv=64L,tol=1e-10,maxitr=10000L),threads=1L)
    pca_seconds <- elapsed()-pca_started
    order <- order(fit$d,decreasing=TRUE)
    values <- fit$d[order]
    left <- fit$v[,order,drop=FALSE]  # observations after transpose orientation
    right <- fit$u[,order,drop=FALSE] # genes after transpose orientation
    stopifnot(all(is.finite(values)),all(is.finite(left)),all(is.finite(right)))
    phase("pipeline_done")
    pipeline <- list(
        status=if(fit$nconv==21L)"COMPLETED" else "NOT_CONVERGED",
        slow=slow,N=ncol(X),G=nrow(X),nnz=length(X@x),
        theta=config[[1]],clip=config[[2]],k_requested=21L,k_retained=20L,
        ncv=64L,tolerance=1e-10,maxitr=10000L,
        nconv=fit$nconv,niter=fit$niter,nops=fit$nops,
        solver="BPCells native Spectra",
        initialization="set.seed(6619); native start not claimed identical to SciPy",
        imports_seconds=imports_seconds,loading_seconds=loading_seconds,
        construction_seconds=built$construction_seconds,
        mean_seconds=built$mean_seconds,pca_seconds=pca_seconds,
        total_construction_pca_seconds=built$construction_seconds+pca_seconds,
        gap_20_21=if(length(values)>=21L)values[[20]]-values[[21]] else NULL,
        rss_after_import=rss_after_import,rss_after_loading=rss_after_loading,
        rss_after_pipeline=rss(),
        permanent_storage_bytes=NULL,
        storage_status="NOT_EXPOSED_NATIVE_CPP_STORAGE",
        r_wrapper_object_size_bytes=as.numeric(object.size(built$mat)),
        storage_warning="R object.size is wrapper size, not complete native storage or RSS",
        matrix_validation="NOT_EVALUATED_IN_THIS_TIMING_PROCESS",
        floating_point_certificate=FALSE
    )
    # Products follow the PCA. No product warm-up precedes the pipeline.
    phase("products")
    operations <- list(
        matvec=function()t(built$mat)%*%q$v,
        rmatvec=function()built$mat%*%q$w,
        matmat8=function()t(built$mat)%*%q$V,
        rmatmat8=function()built$mat%*%q$W)
    product_rows <- list()
    for (name in names(operations)) {
        fn <- operations[[name]]
        invisible(fn()) # one fixed warm-up for each product type
        times <- numeric(10L)
        for (i in seq_len(10L)) {
            t0 <- elapsed()
            result <- fn()
            times[[i]] <- elapsed()-t0
            # Finitude check outside timed region, matching the prospective plan.
            stopifnot(all(is.finite(result)))
        }
        product_rows[[name]] <- data.frame(operation=name,call=seq_len(10L),
            seconds=times,columns=if(grepl("8",name))8L else 1L)
        write_numeric(result,paste0("product_",name,".tsv"))
    }
    write.csv(do.call(rbind,product_rows),file.path(output,"products.csv"),
              row.names=FALSE)
    phase("export")
    export_started <- elapsed()
    write_numeric(values,"singular_values.tsv")
    write_numeric(left,"u_observations.tsv")
    write_numeric(right,"v_genes.tsv")
    pipeline$export_seconds <- elapsed()-export_started
    pipeline$script_elapsed_seconds <- elapsed()-process_started
    pipeline$rss_at_end <- rss()
    write_json(pipeline,file.path(output,"pipeline.json"),
        auto_unbox=TRUE,pretty=TRUE,digits=NA,null="null")
}
phase("done")

"""Consolidate completed, traceable real pipelines only; standard library only.

Run once after the campaign. No constructor, numerical verification or PCA is run.
Nonexecutions/censored runs remain in the execution manifest and ledger, not as
completed costs. Individual product calls remain in their original products.csv.
"""
import csv
import hashlib
import json
import math
import statistics
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OPERATIONS = ('matvec', 'rmatvec', 'matmat8', 'rmatmat8')


def read(path):
    return json.loads(Path(path).read_text())


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def small_path(path):
    path = Path(path)
    try:
        return str(path.relative_to(ROOT))
    except ValueError:
        return str(path)


def json_cell(value):
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    return value


def nested(values, *keys):
    for key in keys:
        if not isinstance(values, dict):
            return None
        values = values.get(key)
    return values


def rss_at(pipeline, stage):
    value = pipeline.get(stage)
    if not isinstance(value, dict):
        return None
    return value.get('VmRSS', value.get('rss_bytes'))


def rows_csv(path, rows, initial_fields):
    fields = list(initial_fields)
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open('x', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows({key: json_cell(value) for key, value in row.items()} for row in rows)


def verification_index(records):
    """Use the last completed verifier receipt, never the most favourable error."""
    found = {}
    for record in records:
        if record.get('status') != 'COMPLETED':
            continue
        command = record.get('command', [])
        positions = [i for i, part in enumerate(command) if Path(str(part)).name == 'verify_real.py']
        if not positions:
            continue
        index = positions[0]
        if len(command) <= index + 3:
            continue
        run_label = Path(command[index + 3]).name
        directory = ROOT / record['output']
        proof = directory / 'verification.json'
        if proof.is_file():
            found[run_label] = (proof, record)
    return found


def actual_products(directory):
    path = directory / 'products.csv'
    with path.open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    costs = {}
    for operation in OPERATIONS:
        calls = [row for row in rows if row['operation'] == operation]
        if len(calls) != 10:
            raise ValueError('Completed run does not contain ten fixed product calls: ' + str(directory))
        times = [float(row['seconds']) for row in calls]
        if not all(math.isfinite(t) and t >= 0 for t in times):
            raise ValueError('Invalid saved product duration')
        widths = [int(row['columns']) for row in calls]
        expected = 8 if operation.endswith('8') else 1
        if widths != [expected] * 10:
            raise ValueError('Saved product widths differ from the frozen protocol')
        costs[operation + '_calls'] = len(calls)
        costs[operation + '_seconds_total'] = sum(times)
        costs[operation + '_seconds_per_call'] = sum(times) / len(times)
        costs[operation + '_seconds_per_call_min'] = min(times)
        costs[operation + '_seconds_per_call_max'] = max(times)
    return costs, path


def settings(pipeline):
    if isinstance(pipeline.get('solver_settings'), dict):
        return pipeline['solver_settings']
    return {key: pipeline.get(key) for key in ('k_requested', 'k_retained', 'ncv', 'tolerance', 'maxitr', 'initialization')}


def get_preflight(directory, pipeline, diagnostics):
    value = nested(diagnostics, 'resources', 'estimated_peak_bytes')
    if value is not None:
        return value, diagnostics['resources']
    for key in ('memory_preflight', 'preflight'):
        if isinstance(pipeline.get(key), dict):
            return pipeline[key].get('estimated_peak_bytes'), pipeline[key]
    for filename in ('preflight.json', 'preflight_before_SVD.json', 'preflight_before_pipeline.json', 'preflight_before_loading.json'):
        path = directory / filename
        if path.is_file():
            values = read(path)
            return values.get('estimated_peak_bytes'), values
    return None, None


def main():
    started = time.perf_counter()
    destinations = [ROOT / name for name in (
        'real_accuracy_results.csv', 'real_performance_results.csv',
        'real_depth_diversity.csv', 'real_completed_summary.json',
        'consolidation_receipt.json')]
    if any(path.exists() for path in destinations):
        raise RuntimeError('Refusing to overwrite consolidated real outputs')
    manifest_path = ROOT / 'REAL_DATA_EXECUTION_MANIFEST.json'
    preparation_path = ROOT / 'REAL_DATA_PREPARATION.json'
    ledger_path = ROOT / 'ledger.json'
    manifest, preparation, records = read(manifest_path), read(preparation_path), read(ledger_path)
    input_records = preparation['inputs'] if isinstance(preparation, dict) else preparation
    inputs = {item['name']: item for item in input_records}
    by_label = {record['label']: record for record in records}
    verifications = verification_index(records)
    accuracy, performance, diversity, omitted = [], [], [], []
    source_artifacts = {small_path(path): sha256(path) for path in (manifest_path, preparation_path, ledger_path)}
    for job in manifest['schedule']:
        name, method, repetition = job['dataset'], job['method'], job['repetition']
        label = f'{name}_{method}_r{repetition}'
        rec = by_label.get(label)
        directory = ROOT / 'runs' / label
        pipeline_path = directory / 'pipeline.json'
        if rec is None or rec.get('status') != 'COMPLETED' or not pipeline_path.is_file():
            omitted.append(dict(**job, label=label, process_status=None if rec is None else rec.get('status'),
                                consolidation_status='NOT_A_COMPLETED_PIPELINE'))
            continue
        pipe = read(pipeline_path)
        if pipe.get('status') != 'COMPLETED':
            omitted.append(dict(**job, label=label, process_status=rec.get('status'),
                                pipeline_status=pipe.get('status'), consolidation_status='NOT_A_COMPLETED_PIPELINE'))
            continue
        data = inputs[name]
        if (pipe['N'], pipe['G'], pipe['nnz']) != (data['N'], data['G'], data['nnz']):
            raise ValueError('Pipeline and frozen input dimensions/nnz differ: ' + label)
        meta = pipe.get('metadata', {})
        diag = meta.get('package_diagnostics', {})
        selection = diag.get('analytic_selection', {})
        arrays = diag.get('arrays_storage_bytes', {})
        common = dict(dataset=name, source=data['source'], target=data['target'],
                      data_kind='independent_real_target', method=method, repetition=repetition,
                      N=data['N'], G=data['G'], nnz=data['nnz'], density=data['density'],
                      sparsity=data['sparsity'], U_d=data['U_d'], U_d_over_N=data['U_d_over_N'],
                      interpolation_nodes=selection.get('interpolation_nodes'),
                      polynomial_degree=selection.get('polynomial_degree'),
                      source_sha256=data['source_sha256'],
                      counts_sha256=data.get('sha256', {}).get('counts.npz'),
                      parameters_sha256=data.get('sha256', {}).get('parameters.npz'),
                      pipeline_label=label, pipeline_path=small_path(pipeline_path))
        product_costs, products_path = actual_products(directory)
        source_artifacts[small_path(pipeline_path)] = sha256(pipeline_path)
        source_artifacts[small_path(products_path)] = sha256(products_path)
        estimated, resource_detail = get_preflight(directory, pipe, diag)
        own_storage = meta.get('permanent_own_bytes', pipe.get('permanent_storage_bytes'))
        storage_status = ('EXPOSED_ARRAY_BYTES' if own_storage is not None else
                          pipe.get('storage_status', 'NOT_EXPOSED'))
        counts = pipe.get('counts', 'NOT_EXPOSED_BY_NATIVE_API')
        clip_count = nested(diag, 'clipping_counts', 'clipped_entries')
        full_columns = diag.get('full_columns')
        perf = dict(**common,
            components_retained=20, triplets_computed=21,
            solver=pipe.get('solver'), solver_settings=settings(pipe),
            solver_convergence=pipe.get('solver_status', pipe['status']),
            niter=pipe.get('niter'), nops=pipe.get('nops'), nconv=pipe.get('nconv'),
            loading_seconds=pipe.get('loading_seconds'), construction_seconds=pipe.get('construction_seconds'),
            selection_seconds=selection.get('selection_seconds'),
            pca_seconds=pipe.get('pca_seconds'),
            construction_pca_seconds=pipe.get('construction_pca_seconds', pipe.get('total_construction_pca_seconds')),
            export_seconds=pipe.get('export_seconds'),
            full_process_seconds=rec['elapsed_seconds'], peak_process_rss_bytes=rec['peak_rss_bytes'],
            rss_after_import_bytes=rss_at(pipe, 'rss_after_imports') or rss_at(pipe, 'rss_after_import'),
            rss_after_loading_bytes=rss_at(pipe, 'rss_after_loading'),
            rss_boundary=rec.get('rss_scope'), memory_budget_bytes=rec.get('process_memory_limit_bytes'),
            estimated_peak_bytes=estimated, estimated_resources=resource_detail,
            operator_storage_bytes=own_storage, operator_storage_status=storage_status,
            storage_detail=arrays or None, common_CSR_bytes=data.get('CSR_bytes'),
            common_parameters_bytes=data.get('parameters_bytes'), common_probe_bytes=data.get('probe_bytes'),
            native_wrapper_object_bytes=pipe.get('r_wrapper_object_size_bytes'),
            solver_product_counts=counts, clipped_entries=clip_count, full_columns=full_columns,
            analytic_status=selection.get('status', 'NOT_APPLICABLE_NO_INTERPOLATION' if method in ('exact_grouped', 'scanpy') or method.startswith('BPCells_') else None),
            L=selection.get('L'), Delta_r=selection.get('Delta_r'), relative_bound=selection.get('relative_upper_bound'),
            L_certified=False, floating_validation_at_construction=diag.get('floating_validation', pipe.get('matrix_validation', 'NOT_EVALUATED')),
            floating_point_certificate=False, products_individual_csv=small_path(products_path),
            product_warmup_policy='After PCA: one warmup then ten calls per operation; finitude checks outside timer',
            **product_costs)
        for operation in ('matvec', 'rmatvec', 'matmat', 'rmatmat'):
            entry = counts.get(operation, {}) if isinstance(counts, dict) else {}
            perf['solver_' + operation + '_calls'] = entry.get('calls')
            perf['solver_' + operation + '_columns'] = entry.get('columns')
        performance.append(perf)
        depth = dict(**common, analytic_status=perf['analytic_status'],
                     operator_storage_bytes=own_storage, operator_storage_status=storage_status,
                     C_bytes=arrays.get('C'), C_mean_bytes=arrays.get('C_mean'),
                     left_factor_bytes=arrays.get('left'), right_factor_bytes=arrays.get('right'),
                     group_indices_bytes=arrays.get('groups'), multiplicity_bytes=arrays.get('multiplicity'),
                     distinct_depth_values_bytes=arrays.get('depth_values'),
                     basis_mean_bytes=arrays.get('basis_mean'), exact_table_bytes=arrays.get('table'),
                     background_mean_bytes=arrays.get('background_mean'),
                     dense_residual_array_and_mean_bytes=own_storage if method == 'scanpy' else None,
                     common_CSR_bytes=data.get('CSR_bytes'), common_parameters_bytes=data.get('parameters_bytes'),
                     common_probe_bytes=data.get('probe_bytes'), estimated_peak_bytes=estimated,
                     peak_process_rss_bytes=rec['peak_rss_bytes'], clipped_entries=clip_count,
                     full_columns=full_columns, depth_min=data.get('depth_min'), depth_max=data.get('depth_max'),
                     depth_max_over_min=data.get('depth_max_over_min'),
                     multiplicity_summary=data.get('multiplicity_summary'),
                     removed_rows_count=len(data.get('removed_rows', [])),
                     removed_columns_count=len(data.get('removed_columns', [])))
        diversity.append(depth)
        pair = verifications.get(label)
        if pair is None:
            default = directory.parent / (label + '_verify') / 'verification.json'
            default_receipt = by_label.get(label + '_verify')
            if default.is_file() and default_receipt and default_receipt.get('status') == 'COMPLETED':
                pair = default, default_receipt
        verification_path, verification_receipt = pair if pair is not None else (None, None)
        v = read(verification_path) if verification_path is not None else {}
        if verification_path is not None:
            source_artifacts[small_path(verification_path)] = sha256(verification_path)
        matrix = v.get('matrix', {})
        triplet = nested(v, 'triplets', '20') or {}
        spectral = v.get('spectral', {})
        gate = v.get('reference_triplet_gate')
        gate_status = ('SATISFIED' if all(item.get('status') == 'SATISFIED' for item in gate.values()) else 'OUTSIDE_TOLERANCE') if gate else 'NOT_EVALUATED'
        full_criteria = (matrix.get('status') == 'SATISFIED'
                         and all(nested(v, 'products', kind, 'status') == 'SATISFIED' for kind in OPERATIONS)
                         and nested(v, 'adjoint', 'status') == 'SATISFIED'
                         and nested(v, 'centering', 'status') == 'SATISFIED'
                         and triplet.get('status') == 'SATISFIED'
                         and spectral.get('singular_status') == 'SATISFIED'
                         and spectral.get('angle_status') == 'SATISFIED'
                         and gate_status == 'SATISFIED')
        acc = dict(**common, solver=pipe.get('solver'), solver_convergence=perf['solver_convergence'],
                   overall_status=v.get('status', 'NOT_EVALUATED'),
                   all_frozen_observed_criteria_satisfied=full_criteria,
                   matrix_absolute_error=matrix.get('absolute_error'), reference_norm=matrix.get('reference_norm'),
                   matrix_relative_error=matrix.get('relative_error'), matrix_status=matrix.get('status', 'NOT_EVALUATED'),
                   matrix_relative_status=matrix.get('relative_status'), product_errors=v.get('products'),
                   saved_products_scope=v.get('saved_timed_products_scope', 'NOT_EVALUATED'),
                   adjoint_absolute_error=nested(v, 'adjoint', 'absolute_error'),
                   adjoint_scaled_error=nested(v, 'adjoint', 'relative_error'),
                   adjoint_status=nested(v, 'adjoint', 'status') or 'NOT_EVALUATED',
                   centering_absolute_error=nested(v, 'centering', 'absolute_error'),
                   centering_scaled_error=nested(v, 'centering', 'relative_error'),
                   centering_status=nested(v, 'centering', 'status') or 'NOT_EVALUATED',
                   Av_residual_absolute=triplet.get('Av_residual_absolute'),
                   ATu_residual_absolute=triplet.get('ATu_residual_absolute'),
                   triplet_relative_residual=triplet.get('relative_residual'),
                   triplet_status=triplet.get('status', 'NOT_EVALUATED'), triplets_20_and_21=v.get('triplets'),
                   left_orthogonality_error=triplet.get('left_orthogonality_error'),
                   right_orthogonality_error=triplet.get('right_orthogonality_error'),
                   singular_relative_error=spectral.get('singular_relative_error'),
                   singular_status=spectral.get('singular_status', 'NOT_EVALUATED'),
                   left_angle_radians=spectral.get('left_angle_radians'),
                   right_angle_radians=spectral.get('right_angle_radians'),
                   subspace_status=spectral.get('status', 'NOT_EVALUATED'),
                   angle_status=spectral.get('angle_status', 'NOT_EVALUATED'),
                   gap_20_21=v.get('gap_20_21', pipe.get('gap_20_21')),
                   reference_gap_20_21=spectral.get('reference_gap_20_21'),
                   reference_triplet_gate_status=gate_status, reference_triplet_gate=gate,
                   singular_values=v.get('singular_values'), analytic_status=perf['analytic_status'],
                   floating_validation_at_construction=perf['floating_validation_at_construction'],
                   floating_point_certificate=False,
                   verification_json=None if verification_path is None else small_path(verification_path),
                   verification_process_seconds=None if verification_receipt is None else verification_receipt['elapsed_seconds'],
                   verification_peak_rss_bytes=None if verification_receipt is None else verification_receipt['peak_rss_bytes'],
                   native_matrix_proof=v.get('native_matrix_proof'), R_margin_roundtrip=v.get('R_margin_roundtrip'))
        for kind in OPERATIONS:
            item = nested(v, 'products', kind) or {}
            for key in ('absolute_error', 'reference_norm', 'relative_error', 'status'):
                acc[kind + '_' + key] = item.get(key, 'NOT_EVALUATED' if key == 'status' else None)
        accuracy.append(acc)
    headers = ('dataset', 'source', 'target', 'data_kind', 'method', 'repetition', 'N', 'G', 'nnz', 'U_d', 'U_d_over_N')
    rows_csv(destinations[0], accuracy, headers)
    rows_csv(destinations[1], performance, headers)
    rows_csv(destinations[2], diversity, headers)
    summary = []
    for name in sorted(inputs):
        for method in sorted({job['method'] for job in manifest['schedule'] if job['dataset'] == name}):
            rows = [row for row in performance if row['dataset'] == name and row['method'] == method]
            checked = [row for row in accuracy if row['dataset'] == name and row['method'] == method]
            item = dict(dataset=name, method=method, repetitions_planned=3, repetitions_completed=len(rows),
                        repetitions_full_frozen_criteria_satisfied=sum(row['all_frozen_observed_criteria_satisfied'] for row in checked),
                        pipeline_labels=[row['pipeline_label'] for row in rows])
            if rows:
                durations = [row['construction_pca_seconds'] for row in rows]
                if any(value is None for value in durations):
                    raise ValueError('Missing completed pipeline cost: ' + name + '/' + method)
                item.update(construction_pca_individual_seconds=durations,
                            construction_pca_median_seconds=statistics.median(durations),
                            construction_pca_min_seconds=min(durations),
                            construction_pca_max_seconds=max(durations),
                            construction_pca_range_seconds=max(durations) - min(durations),
                            process_individual_seconds=[row['full_process_seconds'] for row in rows],
                            peak_rss_max_bytes=max(row['peak_process_rss_bytes'] for row in rows),
                            operator_storage_individual_bytes=[row['operator_storage_bytes'] for row in rows],
                            matrix_relative_error_individual=[row['matrix_relative_error'] for row in checked],
                            triplet_relative_residual_individual=[row['triplet_relative_residual'] for row in checked])
                for kind in OPERATIONS:
                    values = [row[kind + '_seconds_per_call'] for row in rows]
                    item[kind + '_seconds_per_call_individual'] = values
                    item[kind + '_seconds_per_call_median'] = statistics.median(values)
            summary.append(item)
    result = dict(created_utc=datetime.now(timezone.utc).isoformat(),
                  completed_real_pipelines=len(performance), accuracy_rows=len(accuracy),
                  depth_rows=len(diversity), noncompleted_scheduled_jobs=omitted,
                  summary=summary, no_historical_or_synthetic_rows_merged=True,
                  no_acceleration_ratios_computed=True,
                  summary_scope='Within this real campaign only; native solver/runtime differences remain.',
                  source_artifacts_sha256=source_artifacts)
    destinations[3].write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    receipt = dict(status='COMPLETED_TABLE_CONSOLIDATION_ONLY', completed_utc=datetime.now(timezone.utc).isoformat(),
                   elapsed_seconds=time.perf_counter() - started,
                   numerical_constructors_run=0, PCA_runs=0, verification_runs=0,
                   completed_pipeline_rows_only=True, nonexecution_count=len(omitted),
                   code_sha256=sha256(Path(__file__)), source_artifacts_sha256=source_artifacts,
                   outputs_sha256={path.name: sha256(path) for path in destinations[:4]})
    destinations[4].write_text(json.dumps(receipt, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    print(json.dumps({key: result[key] for key in ('completed_real_pipelines', 'accuracy_rows', 'depth_rows')}))


if __name__ == '__main__':
    main()

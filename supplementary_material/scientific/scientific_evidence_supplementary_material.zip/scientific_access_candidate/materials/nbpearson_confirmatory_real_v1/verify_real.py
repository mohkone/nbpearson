"""Verify saved real outputs, independently streamed binary64 reference, no SVD.
CLI: verify_real.py INPUT OUTPUT RUN [REFERENCE_RUN|-] [R_MATRIX_PROOF|-]
"""
import hashlib,json,math,sys,time
from pathlib import Path
import numpy as np
from scipy.linalg import subspace_angles
from worker import (NB_METHODS,approximation_rows,construct,initialize,load,memory,
                    phase,prepare_output,raw_blocks,save,scanpy_preflight)
RTOL=1e-6
TRIPLET_RTOL=1e-8
ZERO_ATOL=1e-12

def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def check(absolute,norm,rtol=RTOL):
    absolute,norm=float(absolute),float(norm)
    assert math.isfinite(absolute) and math.isfinite(norm)
    relative=absolute/norm if norm else None
    passed=relative<=rtol if norm else absolute<=ZERO_ATOL
    return dict(absolute_error=absolute,reference_norm=norm,relative_error=relative,
                relative_status='DEFINED' if norm else 'UNDEFINED_ZERO_REFERENCE',
                threshold=rtol if norm else ZERO_ATOL,
                threshold_contract='relative' if norm else 'named_zero_reference_absolute',
                status='SATISFIED' if passed else 'OUTSIDE_TOLERANCE')

def compare(actual,expected):
    actual,expected=np.asarray(actual),np.asarray(expected)
    assert actual.shape==expected.shape
    assert np.isfinite(actual).all() and np.isfinite(expected).all()
    return check(np.linalg.norm(actual-expected),np.linalg.norm(expected))

def stable_mean(x,d,p):
    total=np.zeros(x.shape[1]);comp=np.zeros_like(total)
    for _,_,raw in raw_blocks(x,d,p):
        term=np.array([math.fsum(map(float,raw[:,j])) for j in range(x.shape[1])])/x.shape[0]
        increment=term-comp;updated=total+increment
        comp=(updated-total)-increment;total=updated
    return total

def read_solution(directory,n,g):
    directory=Path(directory);info=json.loads((directory/'pipeline.json').read_text())
    assert info['status']=='COMPLETED'
    native=not (directory/'solution.npz').is_file()
    if native:
        s=np.loadtxt(directory/'singular_values.tsv').reshape(-1)
        u=np.loadtxt(directory/'u_observations.tsv',ndmin=2)
        vt=np.loadtxt(directory/'v_genes.tsv',ndmin=2).T
        files=['singular_values.tsv','u_observations.tsv','v_genes.tsv']
    else:
        with np.load(directory/'solution.npz',allow_pickle=False) as f:
            u,s,vt=(np.array(f[k]) for k in ('u','s','vt'))
        files=['solution.npz']
    assert u.shape==(n,21) and s.shape==(21,) and vt.shape==(21,g)
    assert all(np.isfinite(a).all() for a in (u,s,vt))
    assert (s>=0).all() and (s[:-1]>=s[1:]).all()
    assert (info['N'],info['G'])==(n,g)
    return info,u,s,vt,native,{k:sha256(directory/k) for k in files}

def read_products(directory,native,n,g):
    shapes={'matvec':(n,),'rmatvec':(g,),'matmat8':(n,8),'rmatmat8':(g,8)}
    if native:
        actual={k:np.loadtxt(directory/('product_'+k+'.tsv')).reshape(shape) for k,shape in shapes.items()}
        files=['product_'+k+'.tsv' for k in shapes]
    else:
        with np.load(directory/'product_outputs.npz',allow_pickle=False) as f:
            assert set(f.files)==set(shapes)
            actual={k:np.array(f[k]) for k in shapes}
        files=['product_outputs.npz']
    for k,shape in shapes.items():assert actual[k].shape==shape and np.isfinite(actual[k]).all()
    return actual,{k:sha256(directory/k) for k in files}

def triplets(u,s,vt,av,atu):
    result={}
    for k in (20,21):
        left=float(np.linalg.norm(av[:,:k]-u[:,:k]*s[:k]))
        right=float(np.linalg.norm(atu[:,:k]-vt[:k].T*s[:k]))
        item=check(max(left,right),np.linalg.norm(s[:k]),TRIPLET_RTOL)
        result[str(k)]=dict(Av_residual_absolute=left,ATu_residual_absolute=right,
            singular_values_norm=item['reference_norm'],relative_residual=item['relative_error'],
            status=item['status'],residual_check=item,
            left_orthogonality_error=float(np.linalg.norm(u[:,:k].T@u[:,:k]-np.eye(k))),
            right_orthogonality_error=float(np.linalg.norm(vt[:k]@vt[:k].T-np.eye(k))))
    return result

def main():
    started=time.perf_counter()
    assert 4<=len(sys.argv)<=6
    input_dir,output_dir,run_dir=map(Path,sys.argv[1:4])
    reference_dir=Path(sys.argv[4]) if len(sys.argv)>=5 and sys.argv[4]!='-' else None
    proof=Path(sys.argv[5]) if len(sys.argv)>=6 and sys.argv[5]!='-' else None
    if proof is not None and proof.is_dir():proof=proof/'verification_matrix.json'
    output=prepare_output(output_dir);phase(output,'verification_loading')
    x,d,p,q,loading=load(input_dir);n,g=x.shape
    info,u,s,vt,native,solution_hashes=read_solution(run_dir,n,g)
    method='BPCells_'+('TRUE' if info['slow'] else 'FALSE') if native else info['method']
    measured,product_hashes=read_products(run_dir,native,n,g)
    inputs={k:sha256(input_dir/k) for k in ('counts.npz','parameters.npz','probes.npz')}
    if (input_dir/'input.json').exists():
        meta=json.loads((input_dir/'input.json').read_text())
        for key,value in inputs.items():
            if key in meta.get('sha256',{}):assert meta['sha256'][key]==value
    margin_roundtrip=None
    if native:
        roundtrip=np.fromfile(run_dir/'roundtrip_margins.bin',dtype='<f8')
        assert np.array_equal(roundtrip,np.r_[d,p])
        margin_roundtrip=dict(status='BITWISE_EQUAL_BINARY64',sha256=sha256(run_dir/'roundtrip_margins.bin'))
    op=None;construction=0.;native_matrix=None;op_meta={}
    if method in NB_METHODS or method=='scanpy':
        imports=initialize(method)
        if method=='scanpy':
            admission=scanpy_preflight(x,imports);save(output/'preflight.json',admission)
            if admission['status']!='ADMITTED':
                save(output/'verification.json',dict(status='NOT_EVALUATED_VERIFIER_MEMORY_PREFLIGHT',method=method,memory_preflight=admission))
                phase(output,'not_evaluated_memory_preflight');return
        op,op_meta,construction=construct(method,x,d,p)
    else:
        imports=dict(python=sys.version.split()[0],rss_after_imports=memory())
        if native and proof is not None:
            native_matrix=json.loads(proof.read_text())
            assert (native_matrix['N'],native_matrix['G'])==(n,g)
            assert bool(native_matrix['slow'])==bool(info['slow'])
        elif method!='direct' and not native:raise ValueError(method)
    reference=None
    if reference_dir is not None:
        ri,ru,rs,rvt,rnative,rhashes=read_solution(reference_dir,n,g)
        assert not rnative and ri['method']=='direct'
        reference=(ru,rs,rvt)
    phase(output,'verification_direct_blocks')
    mean=stable_mean(x,d,p)
    joined_v=np.column_stack((q['v'],q['V']));joined_w=np.column_stack((q['w'],q['W']))
    forward=np.empty((n,9));reverse=np.zeros((g,9))
    av=np.empty_like(u);atu=np.zeros_like(vt.T)
    if reference is not None:rav=np.empty_like(reference[0]);ratu=np.zeros_like(reference[2].T)
    norms=[];errors=[];column_sums=np.zeros(g)
    for a,b,raw in raw_blocks(x,d,p):
        truth=raw-mean;norms.append(float(np.sum(truth*truth)))
        if op is not None:
            candidate=approximation_rows(op,method,a,b)
            errors.append(float(np.sum((candidate-truth)**2)));column_sums+=candidate.sum(0)
        forward[a:b]=truth@joined_v;reverse+=truth.T@joined_w[a:b]
        av[a:b]=truth@vt.T;atu+=truth.T@u[a:b]
        if reference is not None:
            rav[a:b]=truth@reference[2].T;ratu+=truth.T@reference[0][a:b]
    norm=math.sqrt(math.fsum(norms))
    expected=dict(matvec=forward[:,0],rmatvec=reverse[:,0],matmat8=forward[:,1:],rmatmat8=reverse[:,1:])
    products={key:compare(measured[key],value) for key,value in expected.items()}
    adjoint=check(abs(float(q['w']@measured['matvec']-q['v']@measured['rmatvec'])),norm)
    matrix=dict(status='NOT_EVALUATED_NO_NATIVE_MATRIX_PROOF');center=dict(matrix)
    if op is not None:
        matrix=check(math.sqrt(math.fsum(errors)),norm)
        center=check(np.linalg.norm(column_sums),norm*math.sqrt(n))
    elif native_matrix is not None:
        matrix=check(native_matrix['matrix_absolute_error'],native_matrix['reference_norm'])
        matrix['native_reference_norm_minus_python_reference_norm']=native_matrix['reference_norm']-norm
        center=check(native_matrix['center_absolute_error'],native_matrix['reference_norm']*math.sqrt(n))
    elif method=='direct':
        matrix=dict(status='NOT_APPLICABLE_REFERENCE_IS_DIRECT_FORMULA');center=dict(matrix)
    candidate_triplets=triplets(u,s,vt,av,atu)
    spectral=dict(status='NOT_EVALUATED_NO_COMPLETED_GATED_REFERENCE');reference_gate=None
    if reference is not None:
        reference_gate=triplets(*reference,rav,ratu)
        if all(v['status']=='SATISFIED' for v in reference_gate.values()):
            ru,rs,rvt=reference;gap=float(rs[19]-rs[20])
            singular_relative=None if np.any(rs[:20]==0) else float(np.max(abs(s[:20]-rs[:20])/abs(rs[:20])))
            singular_status=('UNDEFINED_ZERO_REFERENCE_SINGULAR_VALUE' if singular_relative is None else
                             'SATISFIED' if singular_relative<=RTOL else 'OUTSIDE_TOLERANCE')
            matrix_abs=matrix.get('absolute_error')
            residual=max(candidate_triplets['20']['Av_residual_absolute'],candidate_triplets['20']['ATu_residual_absolute'])
            interpretable=matrix_abs is not None and gap>2*matrix_abs+residual
            spectral=dict(status='EVALUATED_WITH_GAP' if interpretable else 'NOT_INTERPRETABLE_GAP',
                reference_gap_20_21=gap,singular_relative_error=singular_relative,singular_status=singular_status,
                gap_rule='gap>2*matrix_absolute_error+max(candidate retained-triplet absolute residuals)',
                reference_solution_sha256=rhashes)
            if interpretable:
                left=float(subspace_angles(u[:,:20],ru[:,:20]).max())
                right=float(subspace_angles(vt[:20].T,rvt[:20].T).max())
                spectral.update(left_angle_radians=left,right_angle_radians=right,
                    angle_status='SATISFIED' if max(left,right)<=RTOL else 'OUTSIDE_TOLERANCE')
        else:spectral['status']='NOT_EVALUATED_REFERENCE_TRIPLET_GATE_FAILED'
    numerical_ok=matrix['status']=='SATISFIED' and all(e['status']=='SATISFIED' for e in products.values()) and adjoint['status']=='SATISFIED' and center['status']=='SATISFIED'
    final_ok=numerical_ok and candidate_triplets['20']['status']=='SATISFIED'
    if reference is not None:
        final_ok=final_ok and spectral.get('singular_status')=='SATISFIED' and spectral.get('angle_status')=='SATISFIED'
    status='SATISFIED_ALL_OBSERVED_CRITERIA' if final_ok else 'PARTIAL_OR_OUTSIDE_CRITERIA'
    if final_ok and reference is None and method!='direct':
        status='SATISFIED_MATRIX_PRODUCTS_TRIPLETS_REFERENCE_COMPARISON_NOT_EVALUATED'
    if method=='direct':
        status='REFERENCE_TRIPLETS_SATISFIED' if all(t['status']=='SATISFIED' for t in candidate_triplets.values()) else 'REFERENCE_TRIPLETS_OUTSIDE_TOLERANCE'
    result=dict(status=status,method=method,matrix=matrix,products=products,adjoint=adjoint,centering=center,
        triplets=candidate_triplets,reference_triplet_gate=reference_gate,spectral=spectral,
        solver_convergence=info.get('solver_status',info['status']),
        gap_20_21=float(s[19]-s[20]),singular_values=s.tolist(),
        matrix_status=matrix['status'],triplet_status=candidate_triplets['20']['status'],
        floating_point_certificate=False,input_sha256=inputs,saved_product_sha256=product_hashes,
        saved_solution_sha256=solution_hashes,R_margin_roundtrip=margin_roundtrip,
        native_matrix_proof=None if proof is None else dict(path=str(proof),sha256=sha256(proof)),
        saved_timed_products_scope='Last output of each fixed ten-call lot; not all individual calls',
        reference_scope='Independent direct binary64 formula, 256-row blocks; fsum/compensated mean and two-pass norm',
        metadata=op_meta,loading_seconds=loading,verification_construction_seconds=construction,
        verification_seconds=time.perf_counter()-started,rss_at_end=memory(),**imports)
    save(output/'verification.json',result);phase(output,'done')
    print(json.dumps({k:result[k] for k in ('status','method','matrix_status','triplet_status','verification_seconds')}))

if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        output=Path(sys.argv[2]) if len(sys.argv)>2 else None
        if output is not None and output.is_dir():
            phase_file=output/'phase.txt'
            save(output/'error.json',dict(status='VERIFICATION_FAILED',exception_type=type(exc).__name__,
                message=str(exc),failed_phase=phase_file.read_text().strip() if phase_file.exists() else 'setup',
                diagnostics=getattr(exc,'diagnostics',None),rss_at_failure=memory()))
        raise

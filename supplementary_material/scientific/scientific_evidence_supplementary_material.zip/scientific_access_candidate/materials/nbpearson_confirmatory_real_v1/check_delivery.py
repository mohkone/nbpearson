"""Bounded documentary checks only; no array, operator, PCA or benchmark imports."""
import csv
import hashlib
import json
from pathlib import Path
import re
import zipfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    preserved = json.loads((ROOT / "preservation_before.json").read_text())
    for name, original in preserved.items():
        file = PROJECT / name
        assert file.stat().st_size == original["size_bytes"], name
        assert digest(file) == original["sha256"], name
    m = json.loads((ROOT / "REAL_DATA_EXECUTION_MANIFEST.json").read_text())
    for name, expected in m["harness_frozen_sha256"].items():
        file = ROOT / name
        if name == "REAL_DATA_PROTOCOL_REFERENCE.md":
            file = ROOT / m["post_campaign_documentary_clarification"]["pre_run_snapshot"]
        assert digest(file) == expected, name
    for name in ("CONSOLIDATION_INPUT_MANIFEST.json", "CONSOLIDATION_INPUT_LEDGER.json"):
        assert (ROOT / name).is_file()
    consolidation = json.loads((ROOT / "consolidation_receipt.json").read_text())
    summary = json.loads((ROOT / "real_completed_summary.json").read_text())
    # Evolving source registers have byte-identical snapshots at consolidation.
    for name, snapshot in (("REAL_DATA_EXECUTION_MANIFEST.json", "CONSOLIDATION_INPUT_MANIFEST.json"),
                           ("ledger.json", "CONSOLIDATION_INPUT_LEDGER.json")):
        assert summary["source_artifacts_sha256"][name] == digest(ROOT / snapshot)
    required = ["REAL_DATA_PROTOCOL_REFERENCE.md", "REAL_DATA_PREPARATION.json", "REAL_DATA_EXECUTION_MANIFEST.json",
                "real_accuracy_results.csv", "real_performance_results.csv", "real_depth_diversity.csv",
                "REAL_DATA_CONFIRMATORY_REPORT.md", "FINAL_SCIENTIFIC_DECISION.md"]
    assert all((ROOT / name).is_file() for name in required)
    tables = {}
    for name in required[3:6]:
        with (ROOT / name).open(newline="") as handle:
            rows = list(csv.DictReader(handle))
        assert len(rows) == 66
        assert len({row["pipeline_label"] for row in rows}) == 66
        assert all(row["data_kind"] == "independent_real_target" for row in rows)
        tables[name] = rows
    a = tables["real_accuracy_results.csv"]
    assert sum(row["all_frozen_observed_criteria_satisfied"] == "True" for row in a) == 54
    assert all(row["matrix_status"] == "SATISFIED" for row in a)
    assert all(row["triplet_status"] == "OUTSIDE_TOLERANCE" for row in a if row["method"] == "BPCells_FALSE")
    assert len(m["executions"]) + len(m["nonexecutions"]) == 72
    assert sum(row["pipeline_status"] == "NOT_RUN_DENSE_MEMORY_PREFLIGHT" for row in m["executions"]) == 2
    assert len(m["nonexecutions"]) == 4
    preparation = json.loads((ROOT / "REAL_DATA_PREPARATION.json").read_text())
    input_hash_count = 0
    for data in preparation["inputs"]:
        directory = ROOT / "inputs_r2" / data["name"]
        for name, expected in data["sha256"].items():
            assert digest(directory / name) == expected, (data["name"], name)
            input_hash_count += 1
    wheel = PROJECT / "nb_pca_package_dev1/dist/nbpearson-0.1.0.dev1-py3-none-any.whl"
    installed_checked = []
    with zipfile.ZipFile(wheel) as archive:
        for name in archive.namelist():
            if name.startswith("nbpearson/") and name.endswith(".py"):
                assert (Path(m["installed_package"]) / name).read_bytes() == archive.read(name)
                installed_checked.append(name)
    links = []
    for name in ("REAL_DATA_PROTOCOL_REFERENCE.md", "REAL_DATA_CONFIRMATORY_REPORT.md", "FINAL_SCIENTIFIC_DECISION.md"):
        for target in re.findall(r"\]\(([^)]+)\)", (ROOT / name).read_text()):
            if target.startswith(("http://", "https://")):
                continue
            assert (ROOT / target.split("#", 1)[0]).exists(), (name, target)
            links.append({"document": name, "target": target})
    report = dict(completed_utc=datetime.now(timezone.utc).isoformat(), status="PASS",
                  protected_existing_files_unchanged=len(preserved),
                  frozen_numerical_harness_unchanged=True, original_protocol_and_A1_unchanged=True,
                  prepared_input_artifact_hashes_checked=input_hash_count,
                  wheel_installed_source_files_identical=installed_checked,
                  completed_pipeline_rows=66, all_criteria_satisfied_rows=54,
                  native_fast_precision_failures_preserved=12,
                  Scanpy_preflight_refusals=2, remaining_Scanpy_repetitions_not_executed=4,
                  local_markdown_links=links, no_new_scientific_execution=True,
                  report_budget_token_finalization_pending=True)
    path = ROOT / "DELIVERY_CHECKS.json"
    assert not path.exists()
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in ("status", "protected_existing_files_unchanged", "prepared_input_artifact_hashes_checked")}))


if __name__ == "__main__":
    main()

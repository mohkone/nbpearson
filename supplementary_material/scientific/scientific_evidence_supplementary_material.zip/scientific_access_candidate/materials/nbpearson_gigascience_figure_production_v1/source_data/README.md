# Local saved source inputs

These are unchanged copies of eight scalar CSVs and three descriptive documents needed by the figure scripts/source maps. Relative project paths are retained beneath this directory so the adapted scripts can run without biological count matrices or the old experiment runtimes.

The V3 manuscript, V3 technical supplement and dev1 README are **legacy descriptive sources**, not the new author-review manuscript or current release instructions. They can contain chronologically stale statements and historical terminology. The active GigaScience draft, captions, evidence-strata note and historical row-unit correction supersede those presentation statements; no scientific table was silently corrected.

CSV fields are kept exactly, including original paths and embedded receipt references. Such local references require an approved public-path mapping before a deposit. This is an author-review source package, not a declaration that every historical input is publicly accessible or redistributable. No count matrix or private participant dataset is included.

# Technical Supplement — nbpearson, author manuscript V3

This supplement documents the unchanged `nbpearson 0.1.0.dev1` implementation and separates its historical development evidence from the later real-data confirmatory evaluation. It is an editorial synthesis of saved definitions, tables and receipts. No operator, reference, residual, product, PCA or benchmark was recomputed for V3. Bibliographic keys refer to the previously examined [working bibliography](../nbpearson_manuscript_v2_1/references.bib); no new literature search was performed. This documentary review is not an independent biological replication or an assessment by an independent human researcher.

## Notation and evidence conventions

| Symbol | Meaning and dimensions |
|---|---|
| \(N,G\) | Observations and genes in one frozen count universe |
| \(X,n_i,p_j\) | Counts \(N\times G\), positive depths, positive gene proportions |
| \(T,A\) | Clipped residuals and column-centred target \(A=HT\), both \(N\times G\) |
| \(U_d,d_u,m_u\) | Number of exactly distinct binary64 depths, values and multiplicities; \(\sum_um_u=N\) |
| \(P\) | Conceptual observation-to-depth incidence, \(N\times U_d\); only group indices are stored |
| \(r,m=r-1\) | Interpolation nodes and maximum polynomial degree; unrelated to retained PCA components |
| \(\Omega,W_N,W_d,F\) | Cardinal basis, centred left factors \(N\times r\) or \(U_d\times r\), and right factor \(G\times r\) |
| \(C,C^\star,\bar c\) | Sparse correction, its stable full-column shift, and gene means |
| \(K_c\) | Anchored, multiplicity-centred background table, \(U_d\times G\), without interpolation |
| \(U_k,V_k,\Sigma_k\) | Left/right singular vectors and singular values, distinct from \(U_d\) and \(F\) |
| \(L,\Delta_r\) | Exact-arithmetic contrast lower bound and analytic interpolation-error upper bound |

A/B/C denote `interpolated`, `interpolated_grouped` and `exact_grouped`. PBMC-S/PBMC-L and Mouse-S/Mouse-L denote the small/larger confirmatory targets; their exact dataset identifiers are listed in S6. Table maxima and medians below are documentary aggregations of saved scalar records, not new scientific calculations. An em dash means not applicable or not exposed, never an assumed zero.

<a id="s1"></a>
## S1. Fixed statistical target and support-preserving clipping

### S1.1. Counts and margins

For real, finite, nonnegative integer counts in observations × genes orientation, the target is

\[
\mu_{ij}=n_ip_j,\qquad R_{ij}=\frac{X_{ij}-\mu_{ij}}{\sqrt{\mu_{ij}+\mu_{ij}^2/\theta}},\qquad
T=\operatorname{clip}(R,-c,c),\qquad A=HT,\quad H=I-\mathbf1\mathbf1^\top/N.
\]

Clipping precedes gene centring; no gene standard-deviation scaling is added. The supported dispersion is a scalar, finite \(\theta>0\). The clipped fast path requires \(c\ge\sqrt\theta\). The unclipped mode (`clip=None`) is distinct; an internal infinite clipping threshold does not permit infinite dispersion. Gene-wise dispersions, batches, covariates, Poisson substitution and scaled-NB substitution are outside this API.

The automatic margin contract computes, once per construction on a private canonical binary64 CSR copy,

\[
n_i=\sum_jX_{ij},\quad t_j=\sum_iX_{ij},\quad M=\sum_jt_j,\quad p_j=t_j/M.
\]

The total is obtained from column totals in the implementation's floating-point order; these sums are not represented as exact integer arithmetic. The product-of-margins analytic solution belongs to the multiplicative Poisson model described in [Lause2021Pearson, equations 1–4]. It is not asserted to be a general exact maximum-likelihood fit of the NB model. nbpearson evaluates the NB transformation at fixed parameters without fitting an additional statistical model.

`FixedMargins` instead accepts supplied binary64 depths and proportions, validates them, and binds them to canonical counts through a fingerprint and nonempty source description. They are not replaced by recomputed margins. Exact-arithmetic arguments here treat those binary values as fixed real inputs. A high-precision oracle for this contract must use exact binary conversion, such as `Decimal.from_float`, rather than a shortened decimal string. An exact-count-derived margin contract is a separate oracle target.

### S1.2. Sparse correction

Define

\[
S_{ij}=\frac{X_{ij}}{\sqrt{\mu_{ij}+\mu_{ij}^2/\theta}},\qquad
B_{ij}=b(n_i,p_j)=-\sqrt\theta\,[1+\theta/(n_ip_j)]^{-1/2}.
\]

Then \(R=S+B\). At a zero count, \(-\sqrt\theta<B_{ij}<0\), so \(c\ge\sqrt\theta\) leaves all zero-count residuals unclipped. On the nonzero count support only,

\[
D_{ij}=\operatorname{clip}(R_{ij},-c,c)-R_{ij},\qquad C=S+D,
\]

and \(D=0\) elsewhere. Thus \(T=C+B\) without expanding the count support. The correction is evaluated from the direct residual formula, not from an interpolated background. If \(c<\sqrt\theta\), zero-count residuals can require clipping and this support-preserving path is explicitly refused; corrections at zeros are never silently omitted.

### S1.3. Centred products

The sparse contribution is evaluated as \(Cv-\mathbf1(\bar c^\top v)\) and \(C^\top w-\bar c(\mathbf1^\top w)\), without materialising \(HC\). With a centred grouped left factor, the complete products are

\[
\widehat Av=HCv+P[W_d(F^\top v)],\qquad
\widehat A^\top w=C^\top Hw+F[W_d^\top(P^\top w)].
\]

\(P^\top\) sums weights within a depth group; it does not average them. Matrix products with width \(q\) follow the same identities. Outputs of shape \(N\times q\) or \(G\times q\) are product results and are included in resource considerations, not caches of the residual matrix. Observations with the same depth retain different sparse corrections and their original PCA weights.

<a id="s2"></a>
## S2. Interpolation, factor sharing and analytic node selection

### S2.1. Logarithmic interval and cardinal factors

Let \(n_0=\min_i n_i\), \(s=\log(n_{\max}/n_0)>0\), \(a=\log n_0+s/2\), \(h=s/2\), and \(z=(\log n-a)/h\). The implementation uses `log1p((n_max-n0)/n0)` for the span and

\[
z_i=2\log1p((n_i-n_0)/n_0)/s-1,
\]

rather than subtracting nearly equal logarithms. The Chebyshev–Lobatto nodes, in their stored order, are

\[
z_\ell=\cos\frac{\pi\ell}{r-1},\qquad
n_\ell=n_0\exp\{s(z_\ell+1)/2\},\quad \ell=0,\ldots,r-1.
\]

For \(r\ge2\), the polynomial degree is at most \(m=r-1\). Barycentric weights are \(\omega_\ell=(-1)^\ell\gamma_\ell\), with \(\gamma_0=\gamma_{r-1}=1/2\) and all other \(\gamma_\ell=1\). The cardinal polynomials satisfy

\[
\lambda_\ell(z)=\frac{\omega_\ell/(z-z_\ell)}{\sum_\nu\omega_\nu/(z-z_\nu)},\qquad
\lambda_\ell(z_a)=\mathbf1_{\ell=a}.
\]

These are established interpolation formulas [BerrutTrefethen2004, sections 4–5, equations 4.2 and 5.4]. SciPy's `BarycentricInterpolator` receives the explicit nodes, weights and an identity matrix to evaluate the basis [SciPyBarycentricDoc]. It is not a new interpolator or an independent node selector.

Set \(\Omega_{i\ell}=\lambda_\ell(z_i)\) and \(F_{j\ell}=b(n_\ell,p_j)-b(n_0,p_j)\). A stores \(W_N=H\Omega\) and \(F\), of sizes \(N\times r\) and \(G\times r\). In floating-point construction the basis is first translated by its row at the minimum depth and then centred; the translation is mathematically annihilated by \(H\).

For exactly distinct sorted depths \(d_u\), B constructs the left basis directly at the \(U_d\) depths, not by making and deduplicating an \(N\times r\) array. With multiplicities \(m_u\),

\[
W_{d,u\ell}=\lambda_\ell(z(d_u))-\frac1N\sum_v m_v\lambda_\ell(z(d_v)),\qquad PW_d=W_N
\]

in exact arithmetic. B shares the same polynomial, right factor, nodes, correction, target and original \(N\) as A. It creates neither an \(N\times r\) factor nor a \(U_d\times G\) table. Equality of real-valued operators does not imply bitwise equality of floating products or singular vectors.

C evaluates anchored background rows at the exactly distinct depths and caches their multiplicity-centred table \(K_c\). “Exact” means without interpolation error; evaluation, sums, products and SVD remain floating-point. If \(U_d=N\), its table becomes \(N\times G\). No tolerance, binning, rounding or near-depth merging is used. When all depths are exactly equal, a constant path returns a centred zero background with one node and no division by \(h\); \(HC\) can remain nonzero. Nearly equal unequal binary64 depths retain a nonzero interval.

### S2.2. The interpolation bound

For \(h>0\), write

\[
f_j(z)=-\sqrt\theta[1+(\theta/p_j)\exp(-a-hz)]^{-1/2},\quad
\beta=\frac\pi{2h},\quad\rho=\beta+\sqrt{1+\beta^2}.
\]

On the Bernstein ellipse \(E_\rho\), its imaginary semiaxis is \(\beta\), so \(|\operatorname{Im}(a+hz)|\le\pi/2\). Consequently the real part of the bracket is at least one. The principal inverse square root is analytic in a neighbourhood of the compact ellipse and \(|f_j|\le\sqrt\theta\). This is an ellipse analyticity argument, not an assumption that the function is entire.

The classical interpolation bound for degree \(m\) on \(m+1\) Lobatto nodes is

\[
\|f_j-I_rf_j\|_\infty\le\frac{4\sqrt\theta}{\rho-1}\rho^{-m}.
\]

The versions previously consulted are [Trefethen2019ChebfunGuide, section 4.5, theorem 3] and [Trefethen2010Draft, February 2010, theorem 8.2, printed page 43/PDF page 22]. That theorem number is not transferred to the printed 2013 book. Metadata for the 2019 extended edition were verified, but its full chapter 8 was not consulted. These source distinctions remain in the bibliography.

The Chebyshev coefficient bound \(|a_\nu|\le2\sqrt\theta\rho^{-\nu}\), exact reproduction through degree \(m\), and bounded Lobatto aliasing give this tail estimate. Applying it to the \(N\times G\) background yields

\[
\|\widehat A_r-A\|_F\le\Delta_r,\qquad
\Delta_r=\frac{4\sqrt{\theta NG}}{\rho-1}\rho^{-(r-1)}.
\]

The shared sparse correction cancels from the interpolation difference; orthogonal centring contracts the Frobenius norm. Anchoring does not change the bound because interpolation reproduces constants: \(I_r(b-b_0)=I_rb-b_0\). Full-column shifts in S3 are also removed by centring. These are local applications to the NB background, not a formula claimed to have been published verbatim in the classical sources or a new approximation theorem.

Sharing factors does not replace \(N\) by \(U_d\) in this bound. If \(E\) is an error on distinct-depth rows, then \(\|PE\|_F^2=\sum_um_u\|E_{u,:}\|_2^2\). An unweighted error over \(U_d\) rows is not the original problem's error.

### S2.3. Deterministic contrast norm and decision rule

For \(q=\min(n_{\rm norm\_pairs},\lfloor N/2\rfloor)\), use exactly the adjacent disjoint pairs \((0,1),(2,3),\ldots,(2q-2,2q-1)\) in the frozen observation order. The corresponding contrast matrix \(Q\) has rows \((e_{2\ell}-e_{2\ell+1})^\top/\sqrt2\). Its rows are orthonormal and \(Q\mathbf1=0\), hence \(QH=Q\), giving

\[
L=\|QT\|_F=\|QHT\|_F
=\left[\frac12\sum_{\ell=0}^{q-1}\|T_{2\ell,:}-T_{2\ell+1,:}\|_2^2\right]^{1/2}
\le\|HT\|_F.
\]

No biological independence is required for this deterministic inequality. Up to 16 pairs are used; no search for favourable pairs follows observation of errors. Only the selected rows, evaluated directly and clipped before differencing, are needed. The recorded implementation uses blocks of at most 128 genes for these contrasts.

For \(L>0\), the exact-arithmetic criterion \(\Delta_r\le\texttt{matrix_rtol}\,L\) implies the requested relative interpolation bound. It does not certify the actual implementation's complete floating-point error. The code tries increasing \(r\ge2\) and retains the first admissible node count, not a claimed optimum. It compares logarithms, using \(\log\rho=\operatorname{asinh}(\pi/s)\) and

\[
\log\Delta_r=\log4+\tfrac12(\log\theta+\log N+\log G)-\log(\rho-1)-(r-1)\log\rho.
\]

Contrast norms are scaled and accumulated logarithmically. An exponentiated diagnostic may underflow even when its logarithm remains finite; that differs from all contrasts being zero (`log_L=-inf`). No epsilon is added to a relative denominator. In particular, **the floating-point diagnostic L is not a certified lower bound**: historical fixtures demonstrated that its bound relation need not hold for the exact target.

| Condition | Preserved behaviour |
|---|---|
| Equal depths | Constant-background path; no inference that the complete centred matrix is zero |
| L zero/unusable for nonconstant depths | `insufficient_norm_bound` / `SelectionError`; no false relative success |
| Node ceiling reached | `node_limit` / `SelectionError`; tolerance unchanged |
| Representation memory refused | `ResourceLimitError`, including selection-stage cost; no silent fallback |
| Unsupported input/domain or numerical range | Explicit error; no silent axis exclusion or target change |
| Almost-zero centred target | Relative ill-conditioning retained; small norm is not declared zero |

### S2.4. Separate error layers

The analytic bound concerns \(\widehat A_r-A\) in exact arithmetic. Production rounding and floating reference errors remain separate, as illustrated by

\[
\|\widehat A_r^{fl}-A_{ref}^{fl}\|_F\le
\|\widehat A_r^{fl}-\widehat A_r\|_F+\|\widehat A_r-A\|_F+\|A-A_{ref}^{fl}\|_F.
\]

This identity-based decomposition does not estimate all its terms. The numerical SVD adds solver error; retaining \(k\) components adds truncation. Convergence is not proof of operator fidelity, a small matrix error is not proof that an individual axis is identified, and the retained singular values alone do not give total explained variance. Reference gaps remain necessary for subspace interpretation.

<a id="s3"></a>
## S3. Stabilised arithmetic and sensitive fixtures

### S3.1. Anchored background and dense columns

Choose \(n_0=\min n\) deterministically. Since \(H\) removes any constant by gene, replacing \(B\) by \(\widetilde B_{ij}=b(n_i,p_j)-b(n_0,p_j)\) preserves the centred target. With \(\delta=(n-n_0)/n_0\), \(\alpha=\theta/(n_0p)\) and \(\eta=\alpha\delta/(1+\alpha+\delta)=\delta\theta/(\theta+np)\), the saved stability note gives

\[
b(n,p)-b(n_0,p)=b(n_0,p)\frac{\eta}{\sqrt{1+\eta}+1}.
\]

The implementation scales \(\theta/(\theta+np)\), chooses a range-appropriate evaluation of \(b(n_0,p)\), and uses `expm1` at nodes. This avoids subtracting already rounded close backgrounds. Translated bases are centred with `math.fsum`, with multiplicities in B. Rationalisation is classical [GoldbergOracleReprint, Cancellation]; that source does not publish this particular NB identity or certify the entire calculation.

For a fully nonzero column, the sparse support already covers every observation. The stable shifted correction is \(C^\star=\operatorname{clip}(R)-\widetilde B=C+b_0\), formed without increasing support. Other columns retain \(C\). The added gene constant disappears under \(H\). On these full columns, `stable_residual` uses a compensated product and subtraction for \(X-np\); its denominator remains binary64. Dekker splitting uses \(2^{27}+1\). TwoSum, splitting and product error transformations are established techniques [OgitaRumpOishi2005, section 3, algorithms 3.1–3.3]; their range assumptions and the code's explicit checks are not a whole-operator certification.

The correction, means and factor/table centring remain coherent in all four products. C forms its table by bounded blocks, centres with multiplicity-weighted compensated accumulation and caches it only after admission. It does not store a dense incidence \(P\) or an expanded \(K_c[g,:]\). Grouped transpose products use sums (`bincount` for vectors and `add.at` for blocks), not averages.

### S3.2. What near-null tests establish

The development record distinguishes exact-count margins from fixed binary64 margins, 80- and 160-digit Decimal oracles, direct residuals, sparse-plus-exact-background decomposition, clipping, interpolation and centring. Agreement between those two Decimal precisions was empirical oracle stability, not interval certification. `longdouble` was not assumed to be more precise without platform evidence. No high-precision whole-dataset evaluation is claimed.

For the historical comparative sensitive fixture, the saved direct-reference norm is \(2\times10^{-11}\). The summary records zero matrix error for A/B/C/Scanpy on that specific fixture; BPCells fast/slow record relative errors approximately \(8.87351\times10^{-5}\) and \(8.88179\times10^{-5}\). These are observed errors with their fixture contract, not universal rankings or evidence that the target was exactly zero. Sources: `Q-*` in [rev3 comparison_summary.csv](../nbpearson_paper_evidence_rev3/comparison_summary.csv), with individual `PY-C006`, `PY-C012`, `PY-C018`, `PY-C024` and `Q-BP-qualification_r1-sensitive-*` in [comparison_runs.csv](../nbpearson_paper_evidence_rev3/comparison_runs.csv).

The package-maintenance record preserves the F1 admission regression for a compressed 100000×2 matrix with two depths and the F2 complex-operand regression. Zeroing a process baseline in the isolated estimator test was not allowed as a production memory policy. Source/API tests and wheel-installation tests were separate: rev3 `PKG-DEV1` records 17/17 source tests and 13 passes plus four historical skips among 17 discovered outside-source tests. None was rerun for this manuscript. This evidence does not erase earlier quasi-null failures or the floating-L counterexamples; see the unchanged [correction note](../nb_pca_package_dev1/validation/CORRECTIONS.md), [validation manifest](../nb_pca_package_dev1/validation/manifest.json) and [V2.1 supplement](../nbpearson_manuscript_v2_1/SUPPLEMENT_TECHNIQUE.md#s3).

For an exactly zero target, relative error is undefined and zero-space directions are not identified. The confirmatory protocol names an absolute \(10^{-12}\) criterion for this special case; it is not an epsilon-modified relative test. L=0 does not establish a zero target. The successful real-data tests do not resolve arbitrary cancellation between correction and background near \(X\approx\mu\).

<a id="s4"></a>
## S4. Public interface, allocation boundaries and diagnostics

`build_operator(X, representation=..., theta=..., clip=..., matrix_rtol=..., max_nodes=..., memory_budget_bytes=..., margins=..., n_norm_pairs=...)` constructs a real `scipy.sparse.linalg.LinearOperator`, not a PCA solver. The representation must be explicit; there is no `auto`, dispatcher, performance-based selection or fallback. `clip=None` is unclipped; `clip='sqrt_n'` is accepted only in the supported clipped regime. For C, interpolation tolerance/node arguments are omitted or `None` because they are not applicable.

The supported SciPy CSR matrix/array is privately canonicalised: negative values are checked before duplicate summation; structural validation, binary64 conversion, duplicate summation, explicit-zero elimination and index sorting do not mutate user input. Non-real/nonfinite or noninteger count entries are refused. All four operator products accept real numeric operands only and reject complex dtypes, including complex arrays with a zero imaginary part, before arithmetic. This is an explicit contract rather than a conversion warning followed by a wrong answer.

Fixed margins validate dimensions, finiteness, positivity and proportions. The probability-sum check is not an artificial error denominator. Exact binary equality alone defines groups. At totals outside binary64's integer-distinguishing range, the integer-collision warning remains relevant; grouping is not presented as preserving hypothetical exact integer differences lost before construction.

Resource admission is an estimate, separate from external process monitoring. It includes the available process high-water baseline, sparse validation copies, correction/factor construction, basis intermediates and aggregation buffers. B's selection-stage model uses \(U_d r\) for its representation cost while retaining \(N\) in its analytic criterion and row pairs. C refuses a table that does not fit; the direct streamed evaluation control is not an implicit replacement. The API does not promise a universal RSS limit for every caller-supplied block width or SVD workspace.

Counts, correction, background factors/table, index/multiplicity arrays, product outputs, solver vectors, allocator state and runtime baselines are different storage terms. The array-byte diagnostic is not a peak-RAM result. `requested_representation` and `constructed_representation` are identical, while `floating_validation=NOT_EVALUATED`, `floating_point_certificate=False` and `L_certified_lower_bound=False` remain constructor diagnostics unless external evidence is separately supplied. Errors retain resource/selection diagnostics. See [README dev1](../nb_pca_package_dev1/README.md) and [software notices](../nb_pca_package_dev1/THIRD_PARTY_NOTICES.md).

<a id="s5"></a>
## S5. Evidence strata and historical comparability

### S5.1. Historical installed-package comparisons in rev3

The authoritative historical sources are [comparison_summary.csv](../nbpearson_paper_evidence_rev3/comparison_summary.csv) and [comparison_runs.csv](../nbpearson_paper_evidence_rev3/comparison_runs.csv), with `source_ids_json` and `field_sources_json` linking scalars to archived receipts. This is evidence about the installed dev1 wheel, not substituted prototype timings. The development inputs were PBMC3k-derived 2700×2000, a 2000×1775 spatial subset and 46769×2000 from the same spatial source. The two spatial sizes are not separate cohorts; spatial barcodes are not independent cells. These inputs were already exposed to development.

The PBMC selection receipt documents 2700 initial local H5AD rows and the first 2000 positive genes sorted by (name, original index), no zero-margin removal after selection, and 16104 null features not retained upstream. It does not authenticate acquisition of the local H5AD or reconstruct older exclusions. The official PBMC3k notice and GEO GSM8594567/GSE280315/GSE280318 with the associated spatial study document public resources, not local byte identity or automatic redistribution rights. The spatial study's biological results are not results of nbpearson [Tenx2016PBMC3k; GEO2025GSM8594567; FariaDeOliveira2025VisiumHD].

The historical Python and R campaigns remain separate. Their solvers/start vectors, fixed-product scopes, warming and RSS boundaries differed:

| Historical feature | Python campaign | R/BPCells completion |
|---|---|---|
| Solver | SciPy ARPACK; native sklearn ARPACK for Scanpy | Native Spectra; not the same initialisation |
| Fixed-product batches | One per configuration | Three per configuration |
| Finitude check | Outside product timer | Included in timed calls; unmeasured cost not subtracted |
| Ordering | Pipeline and product scopes as archived | Products precede PCA and alter warming |
| Pipeline RSS | Imports/load/construction/SVD/export; verifier separate | Includes fixed products, SVD and direct verification |
| Orthogonality/diagnostic scope | 20 retained vectors | 21 calculated vectors |
| Adjoint/centring gates | Normalised final gates | Reported, not the same final gates |

Consequently historical native costs are not pooled as a single randomised, same-solver experiment. BPCells fast's historical precision failures, missing-runtime states, preflights, adapter amendments and auxiliary failed processes remain in rev3. `NOT_RUN_DENSE_MEMORY_PREFLIGHT` is not an observed OOM. The documentary process-seconds provenance correction changed source references, not values, and comparison_summary.csv remained identical; see [DOCUMENTARY_AMENDMENT.md](../nbpearson_paper_evidence_rev3/DOCUMENTARY_AMENDMENT.md) and [INTEGRATION_CHECKS.json](../nbpearson_paper_evidence_rev3/INTEGRATION_CHECKS.json). Missing annexes from a larger historical review are not represented as delivered proofs.

### S5.2. The separately labelled synthetic experiment

The original [confirmatory protocol](../nbpearson_confirmatory_v1/CONFIRMATORY_PROTOCOL.md) prescribed three computational loads with \(N=2048,G=512\), 40 positive counts per row and requested depth diversities 16/256/2048. The saved 27 pipelines and their references qualified the compression mechanism, not independent biological evidence. At \(U_d=N\), grouped interpolation lost its storage advantage; product-cost benefits were not uniform and transposed blocks were unfavourable. The original [CONDITIONAL decision](../nbpearson_confirmatory_v1/SCIENTIFIC_DECISION.md) reflected the then-unresolved real-data holds. It is preserved, not rewritten as a prior GO. No synthetic pipeline, qualification or result was rerun for this review.

<a id="s6"></a>
## S6. Real-data confirmatory design, admission and measurement

### S6.1. Two approved sources and four fixed universes

The approved source SHA-256 values are PBMC `42a789ff3f92f0e117d1ff4ffcb2fa8edee87dd2a03d83a81502709344a38bf0` and Mouse `895365af6c20b7a1dd80604ef19f1f963fc3b3c7738ba1589d49cf64651f62fe`. The source HDF5 matrices are features × observations CSC, 36601×11996 (Cell Ranger 6.1.0) and 33696×9684 (Cell Ranger 8.0.0), respectively. The molecule-info file is excluded. Technical count/schema validation and hash preservation are separate from external authentication.

Documentary amendment A1 was approved by investigator Mohamed Kone on 2026-11-14 UTC for those two hash-pinned files. The declaration attests manual acquisition from the frozen 10x resources and no intentional content modification; it is not proof of absence of every transformation or independently authenticated origin. Exact transfer dates, durations, redirections, HTTP details and attempt counts remain unattested; Mouse's exact file URL remains absent and its absence was explicitly accepted. Initial DATA HOLD decisions and the original protocol are preserved. Admission is `ADMITTED_UNDER_DOCUMENTARY_AMENDMENT`, not retroactive full compliance with the original transfer requirements. See the [approval receipt](../nbpearson_data_recovery_v1/provenance_resolution_v1/approval_a1_v1/APPROVAL_RECEIPT.json) and [decision](../nbpearson_data_recovery_v1/provenance_resolution_v1/approval_a1_v1/FINAL_DATA_ADMISSION_DECISION.md). A local hash fixes bytes; it does not authenticate a supplier or establish data-use rights.

Observations are ordered by SHA-256 of UTF-8 `NBPEARSON-CONFIRMATORY-V1|` followed by the exact barcode, ties by exact ID. The small target takes the first min(1000, available) observations and first 1000 positive Gene Expression genes sorted by unique stable ID. The larger target takes min(10000, available) observations and 2000 positive genes by the same rule. Positivity is established on each target's own selected observations. Only subsequent zero margins are removed, their indices retained, with no replacement. Each target's own CSR binary64 margins are fixed once and shared by every arm; there is no variance-based selection, HVG, log transform, new fit or change of gene universe between arms.

| Target | N | G | nnz | Sparsity | U_d | U_d/N | Nodes r | Clipped entries |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| PBMC-S | 1000 | 1000 | 164880 | 0.83512 | 567 | 0.567000000 | 48 | 71 |
| PBMC-L | 9999 | 2000 | 3159138 | 0.842027302730273 | 2354 | 0.235423542 | 57 | 66 |
| Mouse-S | 1000 | 1000 | 122789 | 0.877211 | 418 | 0.418000000 | 34 | 66 |
| Mouse-L | 9684 | 2000 | 2228468 | 0.8849407269723255 | 1391 | 0.143638992 | 40 | 78 |

PBMC-S/PBMC-L correspond to `pbmc_10k_common_small`/`pbmc_10k_larger`; Mouse-S/Mouse-L to `mouse_brain_nextgem_10k_common_small`/`mouse_brain_nextgem_10k_larger`. Only PBMC-L loses a row after selection: selected position 7232/source index 817 (zero-based), without replacement. No selected gene is removed. Two nested targets from a resource do not create additional donors or cohorts. Axes, indices, exclusions, input/margin hashes and probe files are indexed by [REAL_DATA_PREPARATION.json](../nbpearson_confirmatory_real_v1/REAL_DATA_PREPARATION.json).

### S6.2. Frozen arms, solvers and thresholds

The six arms are A/B/C, official Scanpy and native BPCells `slow=FALSE`/`TRUE`. Every real target uses \(\theta=100,c=\sqrt N\), clipping before centring, no standardisation; A/B use matrix_rtol=1e-6, max_nodes=128 and 16 first disjoint adjacent pairs on \(N\). Twenty components are retained and 21 triplets requested.

| Arm | Saved solver contract |
|---|---|
| nbpearson and direct reference | SciPy ARPACK, k=21, ncv=64, tol=1e-10, maxiter=10000; Gaussian v0 seed6619 |
| Scanpy official | Pearson-residual PCA, float64, theta/clip explicit, mask_var=None, zero_center=True; sklearn ARPACK, random_state6619, native tol=0; ncv/maxiter not exposed |
| BPCells 0.3.1 | Spectra, k=nu=nv=21, ncv=64, tol=1e-10, maxitr=10000; set.seed(6619), native initialisation not asserted equal to Python |

For genes × observations BPCells receives `gene_beta=p` on the linear scale, frozen `cell_read_counts=n`, constant `gene_theta`, `columns_are_cells=TRUE`, `min_var=0` and explicit symmetric clip_range. Gene centring is native multiplication by a constant vector followed by `add_rows`, not reliance on `svds` centre/scale options. No SCTransform fit is added to its cost. Native and exported margin roundtrips were checked against the frozen binary64 inputs. Versioned interface evidence outranks current web documentation.

The direct binary64 reference evaluates at most 256 observation rows per block, accumulates the mean stably, then uses a second centred pass for squared norms. It does not use `sum(T**2)-N*mean(T)**2`. Four fresh direct reference PCAs converged and their saved 20/21 triplets passed an independent residual gate before use as a spectral comparison. The direct reference is not a real-arithmetic oracle. The official Scanpy candidate materialises its residuals only on admitted small targets; its dense candidate is not substituted for the streamed direct reference.

Matrix and four-product relative errors must be ≤1e-6. For retained \(k=20\),

\[
\varepsilon_{\rm triplet}=\frac{\max(\|AV_k-U_k\Sigma_k\|_F,\|A^\top U_k-V_k\Sigma_k\|_F)}{\|s_k\|_2}\le10^{-8}.
\]

The denominator is retained singular-value norm, not total matrix norm. Saved outputs also contain the 21-triplet check and left/right orthogonality. Singular relative errors must be ≤1e-6. Angles must be ≤1e-6 rad only if the reference gap20/21 exceeds twice the matrix absolute error plus the maximum retained-triplet absolute residual. Otherwise the status is NOT_INTERPRETABLE_GAP, not PASS. A missing converged gated reference is NOT_EVALUATED. Adjoint and centring thresholds are separately normalised at 1e-6. Exactly zero references have undefined relative error and the separately named absolute criterion 1e-12, without denominator epsilon.

### S6.3. Cost, RSS and qualification boundaries

There are three fresh-process repetitions per admitted configuration, with a real-only schedule shuffled using Python `random.Random(71306)` before its first pipeline. No historical median or synthetic observation is used as a contemporary repetition. No pipeline warmup is performed. After PCA, each full fixed-product operation uses one warmup and ten timed calls; probes are normalised Gaussians seed71305, vectors and width-eight blocks. Finitude checks lie outside timing in both runtimes in this campaign, unlike the historical R comparison. Python uses perf_counter, R proc.time with coarser resolution. The last output of each ten-call lot is saved and verified, not every intermediate output.

Input loading, construction, selection, PCA, products, sorting/export, complete process and verification remain distinct. Python measures a global construction+PCA interval; R sums its construction and native SVD sub-times. The work includes required validation/copies/centred-background construction until triplets are materialised. Sort/export are outside the primary pipeline. A lazy-object constructor alone is not a completed cost. Runtime and solver differences prevent attribution of every timing gap to the operator alone. Counts of calls and processed columns are preserved; Spectra nops is not converted to SciPy directional calls, and total pipeline time is not divided by calls to infer product cost.

The observed limit is 512 MiB (536870912 bytes), one numerical thread and 300 seconds for the entire child process. The external watchdog samples main-PID VmRSS/VmHWM every 50 ms from launch through imports/load/construction/PCA/products/export/exit; it neither sums descendants nor proves an instantaneous bound between samples. Numerical verification is a separate fresh process under the same controls. Estimated admission, runtime baseline, permanent arrays and peak RSS are different quantities. The frozen preflights are

\[
\mathrm{Scanpy}:\quad b+6(8NG)+3\,\mathrm{CSRbytes}+64\,\mathrm{MiB},
\]
\[
\mathrm R:\quad b+4\,\mathrm{CSRbytes}+6(8\cdot256G)+64\,\mathrm{MiB}+4[8(N+G)64],
\]

with \(b\) the baseline after imports. API admission remains active. A stopped arm is not automatically retried; remaining repetitions are explicit non-executions.

Saved environments record Python 3.12.3, NumPy 2.5.4, SciPy 1.18.1 and Scanpy 1.12.5; R 4.5.3, BPCells 0.3.1, Matrix 1.7.6 and jsonlite 2.0.0. The wheel SHA-256 is `6334eb9758d004ba7171b8c430f4b1df9d659ac2327ff152db26905b282238e7`; its five installed sources matched, with imports outside src. The real-run manifest records an Intel Core i5-12500H, Linux 7.0.0-42-generic x86_64 and MemTotal 16087840 kB observed before these real runs. This does not identify historical intersession hardware or retrospectively control power, frequency and competing load.

<a id="s7"></a>
## S7. Detailed confirmatory scalar tables

These tables use completed rows only, keyed by dataset/method/repetition in [real_accuracy_results.csv](../nbpearson_confirmatory_real_v1/real_accuracy_results.csv), [real_performance_results.csv](../nbpearson_confirmatory_real_v1/real_performance_results.csv) and [real_depth_diversity.csv](../nbpearson_confirmatory_real_v1/real_depth_diversity.csv). Each displayed configuration has three completed process repetitions. The two larger Scanpy configurations have no PCA result and are listed separately in S8, not assigned zero or infinite cost. All 66 completed PCAs converged. Fifty-four satisfy all final criteria: 36 nbpearson, six Scanpy and 12 BPCells slow. The 12 BPCells fast results remain visible despite failed final criteria.

### S7.1. Matrix fidelity

Reference norms are medians, absolute/relative errors are maxima across the saved repetitions. “All final” also requires product, adjoint, centring, triplet, singular and interpretable-angle gates, rather than matrix agreement alone.

| Target/arm | Matrix abs max | Reference norm median | Matrix rel max | All final |
| --- | --- | --- | --- | --- |
| PBMC-S/A | 2.47026407e-13 | 1149.50446 | 2.14898171e-16 | 3/3 |
| PBMC-S/B | 2.46911814e-13 | 1149.50446 | 2.14798482e-16 | 3/3 |
| PBMC-S/C | 1.80403779e-13 | 1149.50446 | 1.56940477e-16 | 3/3 |
| PBMC-S/Scanpy | 1.13999559e-13 | 1149.50446 | 9.91727846e-17 | 3/3 |
| PBMC-S/BP-fast | 0.000500527041 | 1149.50446 | 4.35428531e-07 | 0/3 |
| PBMC-S/BP-slow | 7.38265687e-13 | 1149.50446 | 6.42246907e-16 | 3/3 |
| PBMC-L/A | 1.09507961e-12 | 5294.19939 | 2.06845178e-16 | 3/3 |
| PBMC-L/B | 1.09506142e-12 | 5294.19939 | 2.06841741e-16 | 3/3 |
| PBMC-L/C | 7.42150412e-13 | 5294.19939 | 1.40181802e-16 | 3/3 |
| PBMC-L/BP-fast | 0.00175278264 | 5294.19939 | 3.31076053e-07 | 0/3 |
| PBMC-L/BP-slow | 1.36137124e-11 | 5294.19939 | 2.5714393e-15 | 3/3 |
| Mouse-S/A | 1.82814908e-13 | 1197.79315 | 1.52626443e-16 | 3/3 |
| Mouse-S/B | 1.82873704e-13 | 1197.79315 | 1.5267553e-16 | 3/3 |
| Mouse-S/C | 1.61839759e-13 | 1197.79315 | 1.35114948e-16 | 3/3 |
| Mouse-S/Scanpy | 1.08385225e-13 | 1197.79315 | 9.04874308e-17 | 3/3 |
| Mouse-S/BP-fast | 0.000607596892 | 1197.79315 | 5.07263621e-07 | 0/3 |
| Mouse-S/BP-slow | 5.30420507e-13 | 1197.79315 | 4.42831474e-16 | 3/3 |
| Mouse-L/A | 7.58771538e-13 | 5422.19039 | 1.39938195e-16 | 3/3 |
| Mouse-L/B | 7.60416426e-13 | 5422.19039 | 1.40241558e-16 | 3/3 |
| Mouse-L/C | 6.83719781e-13 | 5422.19039 | 1.26096601e-16 | 3/3 |
| Mouse-L/BP-fast | 0.00208995693 | 5422.19039 | 3.85445139e-07 | 0/3 |
| Mouse-L/BP-slow | 1.18186739e-11 | 5422.19039 | 2.17968626e-15 | 3/3 |

### S7.2. Four saved products

Maximum relative errors across repetitions for each operation. In R the eight native matrix checks (four targets × two modes) are reused across their three repetitions; these are not 24 independent matrix validations. The timed products and triplets saved by all 24 R pipelines are checked individually against the direct target. All displayed products pass 1e-6, including BPCells fast.

| Target/arm | matvec rel max | rmatvec rel max | matmat8 rel max | rmatmat8 rel max |
| --- | --- | --- | --- | --- |
| PBMC-S/A | 7.1726145e-16 | 8.16486699e-16 | 8.43133182e-16 | 1.18950751e-15 |
| PBMC-S/B | 7.18406304e-16 | 9.92584107e-16 | 8.42831653e-16 | 1.10759193e-15 |
| PBMC-S/C | 6.83096677e-16 | 8.10847966e-16 | 8.1196177e-16 | 1.09318338e-15 |
| PBMC-S/Scanpy | 7.44594125e-16 | 8.4815129e-16 | 7.67595403e-16 | 7.4659951e-16 |
| PBMC-S/BP-fast | 4.00428065e-07 | 3.90952824e-07 | 4.31945461e-07 | 4.11179688e-07 |
| PBMC-S/BP-slow | 1.74464305e-15 | 2.48343289e-15 | 1.78792085e-15 | 2.38199247e-15 |
| PBMC-L/A | 8.90143056e-16 | 1.50415834e-15 | 9.67793523e-16 | 2.33309638e-15 |
| PBMC-L/B | 8.9014044e-16 | 1.50648318e-15 | 9.67794097e-16 | 2.44872043e-15 |
| PBMC-L/C | 8.31637824e-16 | 1.52257851e-15 | 9.18516791e-16 | 2.39848229e-15 |
| PBMC-L/BP-fast | 3.13010159e-07 | 3.35422626e-07 | 3.27397729e-07 | 3.24271463e-07 |
| PBMC-L/BP-slow | 1.79240617e-15 | 5.84215916e-15 | 2.7284535e-15 | 6.07336982e-15 |
| Mouse-S/A | 6.91648687e-16 | 7.12260083e-16 | 6.97274974e-16 | 9.19608718e-16 |
| Mouse-S/B | 6.91554619e-16 | 7.11784906e-16 | 6.97396836e-16 | 8.95434307e-16 |
| Mouse-S/C | 6.72586024e-16 | 7.0401779e-16 | 6.80897137e-16 | 9.13938604e-16 |
| Mouse-S/Scanpy | 7.64684933e-16 | 7.65053934e-16 | 7.58201515e-16 | 8.01528189e-16 |
| Mouse-S/BP-fast | 5.49035947e-07 | 5.95586463e-07 | 5.12461629e-07 | 5.49287739e-07 |
| Mouse-S/BP-slow | 1.80887325e-15 | 2.38217794e-15 | 1.69162398e-15 | 2.34003471e-15 |
| Mouse-L/A | 7.91970439e-16 | 1.4571761e-15 | 8.0758105e-16 | 2.03115034e-15 |
| Mouse-L/B | 7.91566423e-16 | 1.26744215e-15 | 8.08501651e-16 | 2.02957495e-15 |
| Mouse-L/C | 7.78555389e-16 | 1.27129674e-15 | 7.95696879e-16 | 2.02200767e-15 |
| Mouse-L/BP-fast | 3.64796194e-07 | 3.62799596e-07 | 3.76677452e-07 | 3.84769765e-07 |
| Mouse-L/BP-slow | 3.4459883e-15 | 5.14069507e-15 | 2.52987702e-15 | 5.59836681e-15 |

### S7.3. Triplets, singular values, angles and gaps

All errors/angles are maxima; the reference gap is a median of identical saved target values. Angles are radians. All four target gaps pass the protocol's interpretability rule; all four direct references pass their 20/21-triplet gates. BPCells fast passes singular-value criteria but all 12 retained-triplet residuals exceed 1e-8; nine angle comparisons exceed 1e-6, while Mouse-L's three repetitions pass the angle gate.

| Target/arm | Triplet residual max | Singular rel max | Left angle max | Right angle max | Reference gap20/21 |
| --- | --- | --- | --- | --- | --- |
| PBMC-S/A | 4.63474761e-15 | 2.30217024e-15 | 4.81565195e-14 | 4.91686289e-14 | 0.769860572 |
| PBMC-S/B | 1.45061904e-15 | 1.47717295e-15 | 5.00508967e-14 | 5.12971302e-14 | 0.769860572 |
| PBMC-S/C | 1.80831961e-15 | 1.85843696e-15 | 2.19286713e-14 | 2.16501292e-14 | 0.769860572 |
| PBMC-S/Scanpy | 1.98954312e-15 | 2.51119402e-15 | 6.02122126e-14 | 6.06163666e-14 | 0.769860572 |
| PBMC-S/BP-fast | 2.48538636e-07 | 2.11125592e-07 | 2.50810997e-06 | 2.52145968e-06 | 0.769860572 |
| PBMC-S/BP-slow | 5.7367014e-15 | 8.97536661e-15 | 5.78723253e-14 | 5.84225475e-14 | 0.769860572 |
| PBMC-L/A | 3.5246593e-15 | 1.78895706e-15 | 1.57082771e-14 | 1.73371915e-14 | 1.99649059 |
| PBMC-L/B | 5.31727327e-15 | 1.87385417e-15 | 1.40017742e-14 | 1.56015983e-14 | 1.99649059 |
| PBMC-L/C | 5.90510844e-15 | 1.87385417e-15 | 1.45116122e-14 | 1.62449988e-14 | 1.99649059 |
| PBMC-L/BP-fast | 1.51166617e-07 | 7.63989108e-08 | 1.09225025e-06 | 8.65507526e-07 | 1.99649059 |
| PBMC-L/BP-slow | 9.97210154e-15 | 7.91894487e-15 | 5.20874509e-14 | 5.30094708e-14 | 1.99649059 |
| Mouse-S/A | 2.44521766e-15 | 1.67404217e-15 | 3.95072875e-14 | 3.93220139e-14 | 0.708903 |
| Mouse-S/B | 1.97725727e-15 | 2.45993083e-15 | 2.85984281e-14 | 2.9190491e-14 | 0.708903 |
| Mouse-S/C | 2.54787169e-15 | 1.67404217e-15 | 1.88018099e-14 | 1.94226138e-14 | 0.708903 |
| Mouse-S/Scanpy | 2.25685714e-15 | 2.03682461e-15 | 1.87877612e-14 | 1.89567455e-14 | 0.708903 |
| Mouse-S/BP-fast | 3.72809703e-07 | 1.90870391e-07 | 2.0833275e-06 | 2.12195128e-06 | 0.708903 |
| Mouse-S/BP-slow | 1.3105789e-14 | 1.01920482e-14 | 1.75052612e-13 | 1.98365204e-13 | 0.708903 |
| Mouse-L/A | 2.47395979e-15 | 2.0415773e-15 | 8.77796175e-14 | 8.71647191e-14 | 1.74102325 |
| Mouse-L/B | 2.95405239e-15 | 2.17965871e-15 | 5.2255796e-14 | 5.19218308e-14 | 1.74102325 |
| Mouse-L/C | 2.41676379e-15 | 2.95133733e-15 | 1.50426478e-14 | 1.53807959e-14 | 1.74102325 |
| Mouse-L/BP-fast | 1.426711e-07 | 1.13464015e-07 | 8.67399233e-07 | 8.89549923e-07 | 1.74102325 |
| Mouse-L/BP-slow | 5.05125179e-13 | 6.99287821e-15 | 5.78543228e-12 | 7.92210645e-12 | 1.74102325 |

Adjoint/centring and left/right orthogonality values, including 20 and 21 vector sets, remain in each accuracy row and its verification.json rather than being silently substituted by convergence. There is no native-model residual replacing a target residual in this table.

### S7.4. Loading, construction, PCA, complete process and observed RSS

Loading/construction/PCA/process columns are medians in seconds; pipeline is median [minimum,maximum]. The pipeline column is aggregated from each repetition's actual total, not from summed medians. RSS is the maximum observed complete-process peak across three repetitions, in bytes. BP-fast costs are precision–cost observations outside the final equal-precision set. Python/R clock, solver, initialisation and baseline differences apply directly to this table; verification runs are separate. Verification durations and their own RSS are preserved by accuracy rows and receipts.

| Target/arm | Load median s | Construct median s | PCA median s | Construct+PCA median [min,max] s | Process median s | Peak RSS max bytes |
| --- | --- | --- | --- | --- | --- | --- |
| PBMC-S/A | 0.00842840999 | 0.032644335 | 0.075396281 | 0.109008 [0.103105,0.109954] | 0.554222533 | 95031296 |
| PBMC-S/B | 0.00780715101 | 0.030763602 | 0.072914881 | 0.104087 [0.102695,0.108437] | 0.504021301 | 95236096 |
| PBMC-S/C | 0.00808915304 | 0.052816812 | 0.113804887 | 0.167724 [0.154273,0.178803] | 0.605963559 | 101535744 |
| PBMC-S/Scanpy | 0.007400417 | 0.022650564 | 0.174965744 | 0.197671 [0.197619,0.240007] | 2.01373381 | 320061440 |
| PBMC-S/BP-fast | 0.051 | 0.029 | 0.194 | 0.223000 [0.220000,0.239000] | 1.66183052 | 272891904 |
| PBMC-S/BP-slow | 0.051 | 0.031 | 0.973 | 1.004000 [1.001000,1.009000] | 2.56729554 | 273489920 |
| PBMC-L/A | 0.093423641 | 0.445607789 | 0.531863771 | 0.973818 [0.967567,1.032645] | 1.76177967 | 238424064 |
| PBMC-L/B | 0.095822662 | 0.416976349 | 0.519614693 | 0.976686 [0.913775,1.008432] | 1.76279991 | 239841280 |
| PBMC-L/C | 0.092339986 | 0.473461201 | 0.843259666 | 1.328785 [1.281662,1.353993] | 2.21625398 | 256839680 |
| PBMC-L/BP-fast | 1.135 | 0.215 | 2.848 | 3.066000 [3.060000,3.087000] | 8.35922837 | 439640064 |
| PBMC-L/BP-slow | 1.148 | 0.279 | 13.88 | 14.166000 [14.130000,14.199000] | 21.8390086 | 439701504 |
| Mouse-S/A | 0.00648151396 | 0.023164859 | 0.044500973 | 0.068751 [0.065361,0.070597] | 0.503918789 | 92307456 |
| Mouse-S/B | 0.00659324101 | 0.024987214 | 0.046040884 | 0.072075 [0.069559,0.073028] | 0.50399251 | 92549120 |
| Mouse-S/C | 0.00655014097 | 0.040156105 | 0.057678859 | 0.098933 [0.097062,0.104905] | 0.504054641 | 98316288 |
| Mouse-S/Scanpy | 0.00601264299 | 0.021847481 | 0.164139742 | 0.185306 [0.179849,0.191452] | 1.96385386 | 318529536 |
| Mouse-S/BP-fast | 0.04 | 0.027 | 0.131 | 0.158000 [0.153000,0.167000] | 1.56109659 | 266657792 |
| Mouse-S/BP-slow | 0.042 | 0.032 | 0.764 | 0.794000 [0.762000,0.802000] | 2.3156553 | 266645504 |
| Mouse-L/A | 0.070213596 | 0.329771628 | 0.407918353 | 0.746582 [0.710380,0.759311] | 1.40958361 | 194842624 |
| Mouse-L/B | 0.068654621 | 0.309357928 | 0.467803898 | 0.774988 [0.678611,0.777795] | 1.41103717 | 195235840 |
| Mouse-L/C | 0.068494197 | 0.332911958 | 0.548460085 | 0.882104 [0.859039,1.028137] | 1.61214176 | 208265216 |
| Mouse-L/BP-fast | 0.793 | 0.206 | 1.712 | 1.915000 [1.906000,1.926000] | 6.59583501 | 387485696 |
| Mouse-L/BP-slow | 0.827 | 0.248 | 9.335 | 9.583000 [9.568000,9.605000] | 16.7470637 | 387461120 |

### S7.5. Permanent representation arrays

Bytes from saved diagnostics, invariant across the three repetitions of a displayed configuration. Correction C and its mean, factors/table and metadata are included in operator totals; the table's metadata column sums group indices, multiplicity/depth arrays and mean-base/background arrays where applicable. The input CSR, margins, probes, temporary arrays and solver workspace are separate in the depth/performance CSV. An exposed native R wrapper size is not a C++ storage estimate and is not filled in as a zero. All confirmatory full-column counts are zero, but their historical stabilisation remains part of the implementation.

| Target/arm | C bytes | Left bytes | Right bytes | Table bytes | Group/mean metadata bytes | Operator total bytes |
| --- | --- | --- | --- | --- | --- | --- |
| PBMC-S/A | 1982564 | 384000 | 384000 | — | 0 | 2758564 |
| PBMC-S/B | 1982564 | 217728 | 384000 | — | 17456 | 2609748 |
| PBMC-S/C | 1982564 | — | — | 4536000 | 25072 | 6551636 |
| PBMC-L/A | 37949656 | 4559544 | 912000 | — | 0 | 43437200 |
| PBMC-L/B | 37949656 | 1073424 | 912000 | — | 118112 | 40069192 |
| PBMC-L/C | 37949656 | — | — | 37664000 | 133656 | 75763312 |
| Mouse-S/A | 1477472 | 272000 | 272000 | — | 0 | 2029472 |
| Mouse-S/B | 1477472 | 113696 | 272000 | — | 14960 | 1886128 |
| Mouse-S/C | 1477472 | — | — | 3344000 | 22688 | 4852160 |
| Mouse-L/A | 26780356 | 3098880 | 640000 | — | 0 | 30535236 |
| Mouse-L/B | 26780356 | 445120 | 640000 | — | 100048 | 27981524 |
| Mouse-L/C | 26780356 | — | — | 22256000 | 115728 | 49168084 |

A/B share the same node counts and mathematical interpolant. B's lower permanent total on all four repeated-depth targets does not yield a uniform RSS reduction: its observed process peak is slightly higher here. C uses more permanent bytes in these targets; this does not show it is always inferior, particularly when only a few distinct depths occur. No dispatcher or retrospective U_d/N threshold follows from these observations.

### S7.6. Full fixed-product costs

Milliseconds per call: median across the three saved ten-call lot means. These are complete products, including sparse correction and centring. Each lot has ten calls and width eight where applicable; the individual times stay in products.csv. R's coarser clock and distinct runtime apply. No speed ratio or cross-session ranking is computed.

| Target/arm | matvec ms | rmatvec ms | matmat8 ms | rmatmat8 ms |
| --- | --- | --- | --- | --- |
| PBMC-S/A | 0.142093 | 0.192018 | 0.539353 | 0.580857 |
| PBMC-S/B | 0.138011 | 0.186394 | 0.504185 | 0.595355 |
| PBMC-S/C | 0.232702 | 0.290007 | 0.943912 | 1.034387 |
| PBMC-S/Scanpy | 0.165758 | 0.172535 | 0.830998 | 0.819417 |
| PBMC-S/BP-fast | 4.300000 | 4.100000 | 5.900000 | 12.300000 |
| PBMC-S/BP-slow | 8.000000 | 8.000000 | 9.100000 | 12.800000 |
| PBMC-L/A | 2.620106 | 2.757760 | 9.592489 | 8.956448 |
| PBMC-L/B | 3.193539 | 3.259041 | 9.677510 | 9.651429 |
| PBMC-L/C | 4.603704 | 4.563167 | 15.002712 | 14.884161 |
| PBMC-L/BP-fast | 39.700000 | 35.000000 | 58.000000 | 126.800000 |
| PBMC-L/BP-slow | 95.300000 | 89.100000 | 113.300000 | 186.500000 |
| Mouse-S/A | 0.112780 | 0.156521 | 0.403530 | 0.441769 |
| Mouse-S/B | 0.117949 | 0.160112 | 0.415260 | 0.515599 |
| Mouse-S/C | 0.177776 | 0.212422 | 0.693629 | 0.775274 |
| Mouse-S/Scanpy | 0.165369 | 0.174258 | 0.830099 | 0.836574 |
| Mouse-S/BP-fast | 4.000000 | 3.800000 | 5.400000 | 10.200000 |
| Mouse-S/BP-slow | 7.900000 | 7.800000 | 9.200000 | 12.400000 |
| Mouse-L/A | 1.859837 | 1.945625 | 6.609130 | 6.174183 |
| Mouse-L/B | 1.819672 | 1.885750 | 6.852014 | 7.023905 |
| Mouse-L/C | 2.691642 | 2.844981 | 9.845262 | 9.913772 |
| Mouse-L/BP-fast | 32.300000 | 28.500000 | 51.400000 | 125.200000 |
| Mouse-L/BP-slow | 86.300000 | 87.700000 | 102.800000 | 180.200000 |

B's transposed block is more costly than A's on all four targets. B also has a higher construction+PCA median on three of four targets; only PBMC-S has a lower median. Its lower factor storage is therefore a representation benefit, not evidence of uniform product/pipeline acceleration.

### S7.7. Solver work counters

A/B/C saved counts below are identical across repetitions within each configuration. “matrix calls/columns” preserves a block call as one call processing 21 columns, not 21 vector calls. Scanpy's native solver counts are not exposed. R reports nops/niter/nconv in its pipeline records and those metrics are not forced to match these directions.

| Target/arm | matvec calls | rmatvec calls | matmat calls/columns | rmatmat calls/columns |
| --- | --- | --- | --- | --- |
| PBMC-S/A | 185 | 185 | 1/21 | 0/0 |
| PBMC-S/B | 185 | 185 | 1/21 | 0/0 |
| PBMC-S/C | 186 | 186 | 1/21 | 0/0 |
| PBMC-L/A | 94 | 94 | 1/21 | 0/0 |
| PBMC-L/B | 94 | 94 | 1/21 | 0/0 |
| PBMC-L/C | 94 | 94 | 1/21 | 0/0 |
| Mouse-S/A | 126 | 126 | 1/21 | 0/0 |
| Mouse-S/B | 126 | 126 | 1/21 | 0/0 |
| Mouse-S/C | 126 | 126 | 1/21 | 0/0 |
| Mouse-L/A | 95 | 95 | 1/21 | 0/0 |
| Mouse-L/B | 95 | 95 | 1/21 | 0/0 |
| Mouse-L/C | 95 | 95 | 1/21 | 0/0 |

<a id="s8"></a>
## S8. Non-executions, amendments, budget and evidence index

### S8.1. Six planned Scanpy non-executions

PBMC-L and Mouse-L each have a first-repetition preflight process that ends normally with pipeline status NOT_RUN_DENSE_MEMORY_PREFLIGHT. Their other two planned repetitions are NOT_EXECUTED_PREVIOUS_ARM_STOP. Therefore six planned PCAs are absent, consisting of **two observed conservative refusals and four launches not made**, not six OOMs or timeouts. The estimates were 1411136392 bytes (PBMC-L, import baseline 270274560) and 1347515468 bytes (Mouse-L, import baseline 270401536), against 536870912. A refusal under this policy does not establish that Scanpy cannot process these matrices under any other resource policy. No completion duration is fabricated for an absent PCA.

### S8.2. Preserved failures and corrections

| Stage | Original event and retained evidence | Bounded correction and interpretation |
|---|---|---|
| First real preparation | `runs/real_preparation/receipt.json`: export one-thread assertion fails after an optional Matrix Market pool appears | Preload existing extension before threadpool_limits(1); new script/input directory; original partial files retained; corrected PBMC-S counts/margins/axes/probes match the first completed target |
| First native real qualification | `runs/pbmc_10k_common_small_BPCells_FALSE_matrix/receipt.json`: unsupported R.version `simple.list` JSON class in setup | `unclass(R.version)` changes metadata serialisation only; new R script/proof labels; before any real PCA |
| Pre-run controls | Missing historical full-run preflights, saved-output coverage, reference-triplet gating and centre-unit interface | Implemented in separate real harness before measurement; no core, selection or numerical-threshold change |
| Report writer | `runs/real_report_writing/receipt.json`: absent median for an unexecuted summary group | r2 displays preflight without a time; completed CSVs unchanged |
| Documentary clarification | Initial wording overstated lack of dense candidate arrays | Preserved pre-run reference plus explicit Scanpy-small exception; direct oracle remains streamed |

The [preparation amendment](../nbpearson_confirmatory_real_v1/PREPARATION_HARNESS_AMENDMENT.json), [native amendment](../nbpearson_confirmatory_real_v1/NATIVE_HARNESS_AMENDMENT.json), script hashes and failed receipts preserve the chronology. Corrections do not turn failed processes into successful repetitions or describe the campaign as pristine, error-free preregistration. The original synthetic qualification amendments and historical BPCells min_var/centring/serialization failures are likewise retained; none is a new PCA result in V3.

### S8.3. Budget accounting and preservation

The final saved cumulative numeric duration is **532.2440518923686 s = 50.19525759114185 s inherited + 482.04879430122674 s new**, below 1800 s, with 165 new guarded child receipts. The scope includes preparation, qualification, failures, references, pipelines, numerical verification, consolidation, report writing and documentary-delivery checks. No time/RSS stop was triggered; maximum observed child RSS was 439701504 bytes. Documentary source qualification, historic acquisition/installation and this editorial review are not new algorithm timings. No cumulative budget was reset.

The source protocol, A1 receipts, dev1 wheel/core, rev3, V2.1 and raw sources remain unchanged. The completed manifest records preservation and artifact hashes. Consolidation input snapshots retain byte-identical versions of the evolving manifest/ledger read by the consolidator; later closure entries do not erase that provenance. The current manuscript review reads those saved scalar tables without invoking their numerical scripts.

| Evidence category | Authoritative local pieces and precise lookup |
|---|---|
| Original protocol and initial decision | [CONFIRMATORY_PROTOCOL.md](../nbpearson_confirmatory_v1/CONFIRMATORY_PROTOCOL.md); [SCIENTIFIC_DECISION.md](../nbpearson_confirmatory_v1/SCIENTIFIC_DECISION.md), initial CONDITIONAL status |
| Real design and schedule | [REAL_DATA_PROTOCOL_REFERENCE.md](../nbpearson_confirmatory_real_v1/REAL_DATA_PROTOCOL_REFERENCE.md); [REAL_DATA_EXECUTION_MANIFEST.json](../nbpearson_confirmatory_real_v1/REAL_DATA_EXECUTION_MANIFEST.json): schedule, executions, nonexecutions, gated_references, result_counts, final_budget |
| A1 admission | [APPROVAL_RECEIPT.json](../nbpearson_data_recovery_v1/provenance_resolution_v1/approval_a1_v1/APPROVAL_RECEIPT.json): investigator, decision_date_utc, amendment, sources and conformity_review |
| Target axes, margins and exclusions | [REAL_DATA_PREPARATION.json](../nbpearson_confirmatory_real_v1/REAL_DATA_PREPARATION.json), inputs[*]; corresponding input.json and selection_indices.json; no biological matrix opened for this supplement |
| Continuous accuracy and spectral gates | [real_accuracy_results.csv](../nbpearson_confirmatory_real_v1/real_accuracy_results.csv), dataset/method/repetition; verification_json and native_matrix_proof identify source pieces |
| Cost, products, solver work and resources | [real_performance_results.csv](../nbpearson_confirmatory_real_v1/real_performance_results.csv), same keys; pipeline_path and products_individual_csv identify saved outputs |
| Representation storage | [real_depth_diversity.csv](../nbpearson_confirmatory_real_v1/real_depth_diversity.csv), same keys; C/left/right/table/group/multiplicity/mean columns |
| Process accounting | [ledger.json](../nbpearson_confirmatory_real_v1/ledger.json); [BUDGET_CARRY_FORWARD.json](../nbpearson_confirmatory_real_v1/BUDGET_CARRY_FORWARD.json); receipt events preserve detections/signals/exits |
| Saved-output/documentary delivery checks | [DELIVERY_CHECKS.json](../nbpearson_confirmatory_real_v1/DELIVERY_CHECKS.json); [CONSOLIDATION_INPUT_MANIFEST.json](../nbpearson_confirmatory_real_v1/CONSOLIDATION_INPUT_MANIFEST.json) and CONSOLIDATION_INPUT_LEDGER.json |
| Historical results and numerical definitions | [V2.1 supplement](../nbpearson_manuscript_v2_1/SUPPLEMENT_TECHNIQUE.md), preserved S1–S8; [rev3 summary](../nbpearson_paper_evidence_rev3/comparison_summary.csv), S-/P-/Q-/D-/CTX-/PKG-* IDs and source links |

No absent annex, rounded terminal journal or present-day host inspection substitutes for these pieces. The reference/evidence map accompanying V3 distinguishes publications, versioned author drafts, documentation, software citations, local observations and investigator declarations. This supplement does not establish new rights to redistribute datasets, a public release or final approval by all authors.

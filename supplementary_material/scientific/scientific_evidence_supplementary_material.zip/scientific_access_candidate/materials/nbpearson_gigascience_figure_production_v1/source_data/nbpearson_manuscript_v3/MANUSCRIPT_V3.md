# nbpearson: explicit structured representations for principal component analysis of fixed negative-binomial Pearson residuals

**Mohamed Kone¹, Chao Hou¹, Gaoussou Haidara¹, ShuLin Wang¹***  
¹ School of Computer Science and Engineering, Hunan University, Changsha, China.  
*Corresponding author: ShuLin Wang; <CONTACT_EMAIL_OMITTED>.

*English author manuscript V3. Journal-neutral working draft. Author order, affiliation, contributions and declarations are investigator-supplied; approval of this newly prepared version by all authors is pending.*

## Abstract

**Background.** Pearson residual transformations of sparse counts generally have a dense background. Efficient principal component analysis therefore depends on how the transformed matrix is represented, as well as on the eigensolver. Existing software, including Scanpy and BPCells, already supports relevant residual and PCA workflows.

**Implementation.** nbpearson is a Python library for a fixed standard negative-binomial transformation followed by optional supported clipping and gene-wise centering. It exposes three manually selected representations: interpolated background, the same interpolant with left-factor coefficients shared across exactly repeated depths, and a cached background evaluated without interpolation at distinct depths. It separates an analytic interpolation-selection criterion from floating-point validation and external solver accuracy.

**Results.** The unchanged installed version 0.1.0.dev1 was evaluated on four predetermined targets from two 10x resources, up to 9,999 × 2,000 and 9,684 × 2,000 observations × genes. All 36 nbpearson pipelines satisfied the frozen matrix, product and PCA criteria; their maximum relative matrix error against a streamed binary64 reference was 2.15×10⁻¹⁶. Grouping reduced permanent operator storage from 43,437,200 to 40,069,192 bytes on the larger PBMC target and from 30,535,236 to 27,981,524 bytes on the larger mouse target. Timing and whole-process RSS benefits were not uniform. Of 72 planned pipelines, 66 completed: 54 met every final criterion. BPCells fast met matrix/product thresholds but exceeded the stricter triplet-residual threshold; large Scanpy targets were conservatively refused before PCA.

**Conclusions.** The evidence supports an explicit representation and diagnostic interface for this numerical target. Different runtimes, solvers and initialization, partial acquisition provenance accepted under a documented amendment, and limited dataset diversity constrain generalization. No new normalization, first implicit NB-PCA method or end-to-end floating-point certificate is claimed.

**Keywords:** sparse count matrices; negative-binomial Pearson residuals; implicit linear operators; interpolation; principal component analysis; numerical software.

## 1. Introduction

A zero count need not have a zero Pearson residual. Consequently, transforming a sparse count matrix can produce an essentially dense matrix even before dimensionality reduction. Storing every transformed entry is one implementation choice; exposing consistent matrix and transpose products to an iterative solver permits other storage representations.

Analytic Pearson residuals provide a statistical context for such transformations [Lause2021Pearson]. Scanpy offers an official Pearson-residual PCA workflow, and BPCells already provides implicit negative-binomial residual operations and native singular-value computation [Wolf2018Scanpy; ScanpyPearsonPCADoc; ParksAbdi2025BPCells031; BPCellsPearsonDoc031; BPCellsSvdsDoc031]. Implicit computation is therefore not, by itself, a priority claim for nbpearson.

The contribution considered here is a small Python software implementation of three explicit representations of the same fixed transformation, with coherent products, stability precautions, resource-admission estimates and diagnostics. Two representations share one interpolation polynomial; the compressed form evaluates its left factor only at exactly repeated depths. The third evaluates the background without interpolation at those depths. None changes observation weights or aggregates observations.

The paper distinguishes software capability from empirical support. Interpolation, separable factors, exact grouping, barycentric formulas and implicit centering are established techniques. The relevant question is whether their implemented representations preserve the stated numerical target and provide useful, visible resource trade-offs. Historical development evidence, a separately labelled synthetic mechanism experiment, and a later evaluation on two resources not used to develop the frozen core are reported separately. The manuscript revision itself introduces no numerical experiment.

## 2. Mathematical target and representations

### 2.1. Fixed transformation and margins

Let \(X\in\mathbb R^{N\times G}\) contain nonnegative integer counts, oriented observations × genes. For positive depths \(n_i\), positive gene proportions \(p_j\), and a finite scalar dispersion \(\theta>0\), define
\[
\mu_{ij}=n_i p_j,\qquad
R_{ij}=\frac{X_{ij}-\mu_{ij}}{\sqrt{\mu_{ij}+\mu_{ij}^{2}/\theta}},
\qquad
T=\operatorname{clip}(R,-c,c),\qquad
A=HT,\quad H=I-\frac{\mathbf1\mathbf1^\top}{N}.
\]
Clipping precedes column centering. Genes are not subsequently standardized by their standard deviations. The supported clipped path requires \(c\ge\sqrt\theta\). A distinct unclipped mode sets \(T=R\). Infinite dispersion, gene-specific dispersion, batch effects and zero margins are outside the principal constructor's domain.

In automatic-margin mode, counts are canonicalized on a private binary64 CSR copy and margins are calculated once per construction in the implemented order:
\[
n_i=\sum_jX_{ij},\quad t_j=\sum_iX_{ij},\quad M=\sum_jt_j,\quad p_j=t_j/M.
\]
These are floating-point sums, not asserted exact integer sums. In the separate FixedMargins contract, supplied binary64 values, validated and bound to the canonical counts by a fingerprint, are used without recalculation. Their gene/observation universe must remain unchanged. The evaluations freeze margins separately for every target and supply the same values to its comparison arms.

The product-of-margins mean is the analytic solution of a multiplicative Poisson mean model, not a general exact maximum-likelihood fit of a negative-binomial model [Lause2021Pearson, equations 1–4]. nbpearson computes the NB residual transformation at fixed parameters; it performs no additional statistical fitting. This distinction separates the statistical choice of means from the numerical approximation studied below.

### 2.2. Sparse correction and dense background

Write \(R=S+B\), where
\[
S_{ij}=\frac{X_{ij}}{\sqrt{\mu_{ij}+\mu_{ij}^2/\theta}},
\qquad
B_{ij}=b(n_i,p_j)=-\sqrt{\theta}\left(1+\frac{\theta}{n_i p_j}\right)^{-1/2}.
\]
On the nonzero count support, calculate
\(D_{ij}=\operatorname{clip}(R_{ij},-c,c)-R_{ij}\)
from the residual formula, independently of the interpolated background; elsewhere set \(D_{ij}=0\). At a zero count, \(R_{ij}\in(-\sqrt\theta,0)\). Thus, in the supported clipping regime, no omitted zero-count correction is needed. With \(C=S+D\), the target is \(H(C+B)\).

The stabilized implementation anchors the background at \(n_0=\min_i n_i\), replacing it by \(b(n_i,p_j)-b(n_0,p_j)\), a gene-wise constant shift annihilated by H. It uses rationalized background differences, stable coordinates and compensated operations where implemented. Fully populated columns receive a separate constant-shift reformulation that preserves their support. These precautions address identified cancellation sources without claiming to eliminate all cancellation between sparse correction and background. The exact formulas and historical near-null counterexamples are retained in Supplement S3 [GoldbergOracleReprint; OgitaRumpOishi2005].

### 2.3. Interpolation and depth grouping

For nonidentical depths, let \(a=(\log n_{\min}+\log n_{\max})/2\), \(h=(\log n_{\max}-\log n_{\min})/2>0\), and \(z_i=(\log n_i-a)/h\). Use r Chebyshev–Lobatto nodes
\[
z_\ell=\cos\!\left(\frac{\pi\ell}{r-1}\right),\quad \ell=0,\ldots,r-1,\qquad
n_\ell=\exp(a+h z_\ell).
\]
The polynomial degree is at most \(r-1\); r is distinct from the retained PCA dimension. The barycentric weights alternate in sign and have half weight at both endpoints. SciPy's BarycentricInterpolator receives these explicit nodes and weights [BerrutTrefethen2004; SciPyBarycentricDoc].

Let \(\lambda_\ell\) be the cardinal basis, \(\Omega_{i\ell}=\lambda_\ell(z_i)\), \(F_{j\ell}=b(n_\ell,p_j)-b(n_0,p_j)\), and \(W_N=H\Omega\). Translation before centering changes floating-point evaluation order but not this exact definition. F is G×r and the uncompressed left factor is N×r.

Let \(U_d\) be the number of exactly distinct binary64 depths, \(d_u\) their values, \(m_u\) their multiplicities, and P the implicit N×\(U_d\) incidence. Define the directly constructed group basis \(W_d\in\mathbb R^{U_d\times r}\), centered with weights \(m_u/N\); then \(PW_d=W_N\) in exact arithmetic. The compressed path never constructs W_N and then deduplicates it, nor an \(U_d\times G\) background table. It retains every observation's sparse correction.

**Table 1. Explicit representation choices.**

| API representation | Conceptual centered operator | Stored background |
|---|---|---|
| interpolated (A) | \(HC+W_NF^\top\) | N×r and G×r |
| interpolated_grouped (B) | \(HC+PW_dF^\top\) | \(U_d\)×r, G×r, group indices and multiplicities |
| exact_grouped (C) | \(HC+PK_c\) | \(U_d\)×G plus group information |

\(K_c\) contains anchored background rows centered with their multiplicities. “Exact” means no interpolation error, not exact floating-point arithmetic. Its table becomes N×G when \(U_d=N\). Counts, C, means, construction temporaries, product buffers and solver workspace are additional storage.

For B, the conceptual products are
\[
\widehat A v=HCv+P[W_d(F^\top v)],\qquad
\widehat A^\top w=C^\top Hw+F[W_d^\top(P^\top w)].
\]
The rightmost w may equivalently be replaced by Hw in the background term because the weighted-centered factors annihilate constants. \(P^\top\) sums within groups; it does not average. The block products follow the same identities. If depths are exactly equal, the centered background is zero, but HC can remain nonzero. Nearly equal depths are not binned.

### 2.4. Analytic selection is not floating-point certification

For h>0, let \(\beta=\pi/(2h)\) and \(\rho=\beta+\sqrt{1+\beta^2}\). Analyticity and the bound \(\sqrt\theta\) in the chosen Bernstein ellipse give the exact-arithmetic interpolation bound
\[
\|\widehat A_r-A\|_F\le\Delta_r,\qquad
\Delta_r=\frac{4\sqrt{\theta NG}}{\rho-1}\rho^{-(r-1)}.
\]
The sparse correction is common to both matrices; orthogonal centering does not increase this error. The classical bound is attributed to the consulted Chebfun Guide §4.5, Theorem 3, and the February 2010 author draft, Theorem 8.2—not transferred to a different printed edition [Trefethen2019ChebfunGuide; Trefethen2010Draft]. The NB ellipse application and following norm contrast are local applications of established tools.

For the first q disjoint adjacent pairs in the frozen observation order,
\[
L=\left[\frac12\sum_{\ell=0}^{q-1}
\|T_{2\ell,:}-T_{2\ell+1,:}\|_2^2\right]^{1/2}\le\|A\|_F.
\]
The pair-contrast rows are orthonormal and annihilate constants, so this inequality is deterministic; biological independence is not required. When L>0, the criterion \(\Delta_r\le\text{matrix_rtol}\,L\) controls relative interpolation error in exact arithmetic. Grouping does not replace N by \(U_d\) in the bound.

The implementation evaluates the criterion logarithmically and selects the first admissible r within the declared node and estimated-memory limits, not an optimal rank. The computed floating-point L is not a certified lower bound; this selection does not certify rounding, products or centering. An unusable L, node ceiling or failed resource admission produces an explicit refusal, without a denominator epsilon or fallback. L=0 does not imply A=0. Interpolation error, floating-point evaluation, SVD solution error and PCA truncation remain separate (Supplement S2).

## 3. Software implementation

The evaluated software is the unchanged installed nbpearson 0.1.0.dev1, CPU/binary64, depending on NumPy, SciPy and the Python standard library. It constructs a real scipy.sparse.linalg.LinearOperator with matvec, rmatvec, matmat and rmatmat; it does not implement a PCA solver [Virtanen2020SciPy; SciPyLinearOperatorDoc; SciPySvdsDoc].

Representation selection is explicit and mandatory. There is no dispatcher, learned \(U_d/N\) threshold, internal timing-based selection or silent conversion to another representation. Inputs and zero margins are rejected according to the documented contract; optional external preprocessing must retain axis mappings. CSR canonicalization does not mutate user counts. The four products reject complex operands consistently. FixedMargins provides traceable reuse of historical parameters. Diagnostics distinguish representation, margin/clipping contract, nodes/degree, analytic status, array storage and estimated resource admission. Construction retains floating_validation=NOT_EVALUATED; external validation outcomes are recorded separately.

The memory budget is an admission estimate, not a universal RSS guarantee or an internal watchdog. In particular, product widths and external solver work can exceed modeled assumptions. An inadmissible exact-grouped table is refused rather than silently replaced by streamed direct evaluation. Supplement S4 describes these boundaries and the saved autonomous-package/near-null tests; no new package build or installation was performed for V3.

## 4. Evaluation design and evidence strata

### 4.1. Development and historical software evaluation

The historical rev3 evidence comprises installed-package Python and later native R campaigns, separate from the prototypes. Their development inputs were PBMC3k (2700×2000) and two sizes from the same spatial source (2000×1775 and 46769×2000); the spatial barcodes are not assumed independent cells. The GEO record GSM8594567 belongs to GSE280315/GSE280318 and identifies 8-µm spatial bins and the associated study [GEO2025GSM8594567; FariaDeOliveira2025VisiumHD]. These notices do not authenticate the local bytes or import that study's biological conclusions.

The saved rev3 tables report 30 completed Python pipelines with their recorded criteria satisfied, and a distinct 18-pipeline BPCells campaign with nine final-criterion passes in slow mode. Their differing sessions, initialization, warm-up, RSS and product timing scopes are retained, not retrospectively harmonized. Prototype results are background development evidence, not additional evaluated runs of the installed package.

The separately labelled frozen synthetic mechanism experiment completed 27 pipelines at \(U_d=16,256,2048\), with N=2048, G=512 and 40 nonzero counts per row. It examined representation behavior as depth diversity increased, including loss of storage advantage at \(U_d=N\). These are computational loads, not biological simulations or independent biological evidence. Neither these pipelines nor historical real datasets were rerun for the later real campaign or this manuscript revision.

### 4.2. Later real-data targets and acquisition amendment

The later evaluation used two prespecified 10x resources: Human PBMC 10k Chromium X, Cell Ranger 6.1.0, and Adult Mouse Brain Nuclei NextGEM 10k, Cell Ranger 8.0.0. The raw HDF5 matrices had 36601×11996 and 33696×9684 features×observations, respectively. The molecule_info file was excluded.

They were acquired manually and admitted under documentary amendment A1, explicitly approved by Mohamed Kone on 14 November 2026 UTC. Local integrity/schema/integer-count checks succeeded. Dates, durations, redirections and HTTP receipts were not retained; the exact Mouse transfer URL remains unknown and its absence was explicitly accepted. The investigator declared no intentional content modification, a statement that is not independent authentication of external origin. A1 changed documentary eligibility only; numerical criteria, methods, parameters and the original protocol remain unchanged.

Observation order was SHA-256 of the UTF-8 prefix NBPEARSON-CONFIRMATORY-V1| followed by the exact barcode, ties by exact identifier. Each resource supplied a small target of its first 1000 ordered observations and 1000 positive Gene Expression features, and a larger target of its first min(10000, available) observations and 2000 such features, ordered by stable feature ID. Positivity was assessed on each target's observations. Only zero margins after selection were removed; excluded indices were retained, without replacement. One zero row was removed from the larger PBMC target; no selected columns or other rows were removed.

**Table 2. Later real targets.** C1–C4 are shorthand for the dataset keys in the evidence map. Sparsity, axis mappings, complete hashes and exclusions are in the saved preparation record. Counts and binary64 margins are common to all arms within a target.

| Target | N | G | nnz | \(U_d\) | \(U_d/N\) | Nodes A/B | Clipped entries |
|---|---:|---:|---:|---:|---:|---:|---:|
| C1: PBMC small | 1000 | 1000 | 164880 | 567 | 0.567000 | 48 | 71 |
| C2: PBMC large | 9999 | 2000 | 3159138 | 2354 | 0.235424 | 57 | 66 |
| C3: Mouse small | 1000 | 1000 | 122789 | 418 | 0.418000 | 34 | 66 |
| C4: Mouse large | 9684 | 2000 | 2228468 | 1391 | 0.143639 | 40 | 78 |

These are four nested targets from two resources not used for development of the frozen numerical core. They are not four independent cohorts and do not establish generalization across donors. The primary settings were \(\theta=100\), \(c=\sqrt N\), matrix_rtol=10⁻⁶, max_nodes=128 and the first 16 disjoint adjacent pairs. Margins were calculated once on each final target, frozen, and passed unchanged. Scanpy's recalculated margins agreed; R parameter exports round-tripped bitwise.

### 4.3. Native comparators and accuracy criteria

All six arms were retained: the three nbpearson representations, official Scanpy Pearson-residual PCA, and BPCells slow=FALSE/TRUE. Scanpy received float64 counts, explicit theta/clip, mask_var=None, no HVG selection or gene standardization. In genes×observations orientation, BPCells received linear gene_beta=p, cell_read_counts=n, constant gene_theta, columns_are_cells=TRUE, min_var=0 and symmetric clip_range. Centering was applied explicitly through native operations after clipping, without relying on ignored center/scale options of its SVD. No SCTransform parameter fit was added.

SciPy ARPACK requested 21 triplets, retaining 20, with ncv=64, tol=10⁻¹⁰, maxiter=10000 and Gaussian v0 seed6619. Scanpy used its official sklearn/ARPACK path, tol=0 and native initialization; ncv/maxiter were not exposed. BPCells used native Spectra, k=nu=nv=21, ncv=64, tol=10⁻¹⁰, maxitr=10000 and set.seed(6619). These are native pipelines, not a same-solver or identical-start comparison.

The independent direct reference used 256-row binary64 residual blocks, stable mean accumulation and a two-pass centered norm. No whole-matrix dense oracle was built. The small admitted official Scanpy candidate itself materialized dense residuals. Each target had a fresh direct ARPACK reference whose 20/21 triplets were independently gated.

Frozen thresholds were relative matrix and four-product error ≤10⁻⁶; aggregated triplet residual ≤10⁻⁸; singular-value relative error ≤10⁻⁶; and maximal subspace angles ≤10⁻⁶ rad when the gap criterion permitted interpretation. Both \(Av-\sigma u\) and \(A^\top u-\sigma v\) were checked against the target. The gap criterion was \(s_{20}-s_{21}>2e_{\rm matrix,abs}+\max(e_{Av},e_{A^\top u})\). Adjoint and centering diagnostics were separately normalized. Exactly zero references have undefined relative error and a named absolute criterion of 10⁻¹², with no denominator epsilon. Orthogonality was reported separately.

Eight native R matrix checks—four targets × two modes—were reused for their three corresponding pipeline repetitions. Saved products and triplets were checked individually for every completed pipeline. Only the last output array of each ten-call product lot was saved; all individual durations were retained. Direct binary64 and agreement of small Decimal 80/160-digit oracles are not interval certificates.

### 4.4. Timing, memory and bounded execution

Three fresh processes were planned per arm/target: 72 pipelines in a real-only order shuffled once with random.Random(71306) before its first run. No pipeline warm-up was performed. Fixed products followed PCA, using normalized Gaussian probes seed71305, one warm-up and ten calls for each direction and width-eight block. Finitude checks were outside both Python and R timers. Products ran inside their native runtime without restarting R for each multiplication.

Loading, construction, PCA, products, export, whole-process elapsed time and verification were separated. Construction included validation, count copying/fingerprinting, fixed-margin binding, grouping, node selection, factors/background and centering as applicable. Python recorded a construction+PCA interval; R summed construction and SVD sub-times. R proc.time has coarser resolution than Python perf_counter. Installation and acquisition were not benchmark costs.

The process watchdog sampled main-PID VmRSS/VmHWM every 50 ms from launch through exit for both runtimes, including imports, loading, products and export; verification was separate. This is a matched nominal boundary, not equality of runtime baselines or an instantaneous bound on unseen allocations. Descendant RSS was not summed. Each process had one numerical thread, a 512-MiB RSS cap and 300-s whole-process wall limit, additionally bounded by the remaining 1800-s cumulative allowance.

The saved cumulative total was 532.2440518923686 s, comprising 50.19525759114185 s already counted and 482.04879430122674 s of new guarded work, including preserved failures and report/documentary checks. No time or RSS stop occurred. Host metadata observed before this real campaign reports an Intel Core i5-12500H, Linux and 16087840 kB MemTotal; competing workload, power and frequency were not fully controlled. This observation does not establish hardware or conditions for the earlier campaigns.

## 5. Results

### 5.1. Execution accounting and numerical fidelity

Of 72 planned pipelines, 66 PCAs completed: 36 nbpearson, six Scanpy and 24 BPCells. Two larger Scanpy configurations were refused by the frozen conservative memory preflight; the remaining four repetitions were not launched. These are six non-executions, not six software failures or OOMs, and have no completed PCA times.

All 36 nbpearson pipelines met every observed frozen criterion. All six completed Scanpy and 12 BPCells slow=TRUE pipelines also passed. All 12 BPCells fast pipelines converged and passed matrix, product and singular-value thresholds, but exceeded the triplet-residual threshold. Nine also exceeded the angle threshold; the three larger-Mouse angles passed. Convergence alone would therefore have misclassified final fidelity.

**Table 3. Maximum observed errors by method over completed later real runs.** Matrix/product/singular/angle thresholds are 10⁻⁶; the triplet threshold is 10⁻⁸. Angles are radians. All evaluated gaps were interpretable and all direct references passed their triplet gates. Absolute errors, norms, 20/21-triplet diagnostics and continuous failures remain in the saved tables and Supplement S7.

| Method | PCA runs | Matrix relative | Four-product relative max | Retained-triplet relative residual | Singular relative | Angle max | All final criteria |
|---|---:|---:|---:|---:|---:|---:|---:|
| interpolated | 12 | 2.15e-16 | 2.33e-15 | 4.63e-15 | 2.3e-15 | 8.78e-14 | 12/12 |
| interpolated_grouped | 12 | 2.15e-16 | 2.45e-15 | 5.32e-15 | 2.46e-15 | 5.23e-14 | 12/12 |
| exact_grouped | 12 | 1.57e-16 | 2.4e-15 | 5.91e-15 | 2.95e-15 | 2.19e-14 | 12/12 |
| scanpy | 6 | 9.92e-17 | 8.48e-16 | 2.26e-15 | 2.51e-15 | 6.06e-14 | 6/6 |
| BPCells_FALSE | 12 | 5.07e-07 | 5.96e-07 | 3.73e-07 | 2.11e-07 | 2.52e-06 | 0/12 |
| BPCells_TRUE | 12 | 2.57e-15 | 6.07e-15 | 5.05e-13 | 1.02e-14 | 7.92e-12 | 12/12 |

Observed matrix errors near machine precision describe agreement with a floating reference on these inputs, not universal precision. The real campaign did not retest the historical almost-zero counterexamples; those limitations remain.

### 5.2. Construction and PCA costs

**Table 4. Construction+PCA, seconds, median [minimum, maximum], three completed processes per admitted cell.** BPCells fast (*) is shown as a precision–cost observation and is excluded from final-precision-matched ranking. This table belongs only to the later real session. Different runtimes, solvers, initializations and timer definitions remain relevant; differences are not attributed solely to the operator. RSS is not inferred from this table.

| Target | A | B | C | Scanpy | BPCells fast* | BPCells slow |
|---|---|---|---|---|---|---|
| C1: PBMC small | 0.109008 [0.103105, 0.109954] | 0.104087 [0.102695, 0.108437] | 0.167724 [0.154273, 0.178803] | 0.197671 [0.197619, 0.240007] | 0.223000 [0.220000, 0.239000] | 1.004000 [1.001000, 1.009000] |
| C2: PBMC large | 0.973818 [0.967567, 1.032645] | 0.976686 [0.913775, 1.008432] | 1.328785 [1.281662, 1.353993] | Preflight refusal | 3.066000 [3.060000, 3.087000] | 14.166000 [14.130000, 14.199000] |
| C3: Mouse small | 0.068751 [0.065361, 0.070597] | 0.072075 [0.069559, 0.073028] | 0.098933 [0.097062, 0.104905] | 0.185306 [0.179849, 0.191452] | 0.158000 [0.153000, 0.167000] | 0.794000 [0.762000, 0.802000] |
| C4: Mouse large | 0.746582 [0.710380, 0.759311] | 0.774988 [0.678611, 0.777795] | 0.882104 [0.859039, 1.028137] | Preflight refusal | 1.915000 [1.906000, 1.926000] | 9.583000 [9.568000, 9.605000] |

A and B had the same exposed solver product-call counts for each target, but B did not have a uniformly smaller pipeline median: it was lower only for the small PBMC target. The complete cost of node selection was included in both. The exact-grouped control remained viable; it was neither suppressed nor replaced by a different implementation to favor interpolation.

Scanpy large-target preflight estimates were 1411136392 bytes for PBMC and 1347515468 bytes for Mouse, against 536870912 bytes. Their respective measured post-import baselines were 270274560 and 270401536 bytes. These conservative estimates are not observed OOMs and do not imply that Scanpy cannot handle these inputs under another resource policy. No speed ratio is calculated using a missing completion time.

### 5.3. Permanent storage, RSS and fixed products

**Table 5. Permanent operator-array storage, bytes, later real campaign.** These totals include correction/means/factors/group information as applicable. They exclude the common input counts, temporary copies, product outputs and external solver workspace. The savings are direct differences of the saved array-byte totals, not estimates of peak-RAM gain.

| Target | A bytes | B bytes | A−B bytes | C bytes |
|---|---:|---:|---:|---:|
| C1: PBMC small | 2758564 | 2609748 | 148816 | 6551636 |
| C2: PBMC large | 43437200 | 40069192 | 3368008 | 75763312 |
| C3: Mouse small | 2029472 | 1886128 | 143344 | 4852160 |
| C4: Mouse large | 30535236 | 27981524 | 2553712 | 49168084 |

The grouped interpolant reduced permanent storage on all four targets. On larger targets, the sparse correction occupied 37949656 bytes for PBMC and 26780356 for Mouse, limiting the relative importance of left-factor compression. The complete per-array breakdown, input storage and exact-table sizes remain in Supplement S7 and the source CSV.

Lower array storage did not produce lower observed process RSS here. For example, maximum RSS over the three large-PBMC repetitions was 238424064 bytes for A and 239841280 for B; for large Mouse it was 194842624 and 195235840 bytes. These are whole-process maxima with different allocator histories, not a causal estimate of an isolated factor. BPCells native C++ storage was not exposed; wrapper object size was not substituted for total storage. The largest observed new child-process RSS was 439701504 bytes, below the operational cap.

Fixed-product costs also varied. B's width-eight transposed product was more expensive than A's on all four targets. On large PBMC, the median mean-per-call values were 8.956448 ms for A and 9.651429 ms for B; on large Mouse they were 6.174183 and 7.023905 ms. The four complete product types, all individual timings and work counts are preserved. Pipeline time was not divided by solver calls to pretend to isolate product cost.

### 5.4. Relationship to historical results and retained incidents

Historical rev3 results remain a development stratum. For example, the spatial 46769×2000 grouped-interpolant median was 0.519945659 s in its Python campaign, whereas the small spatial Scanpy median was 0.580848553 s in that campaign. Their different matrices do not define a speed comparison, and neither value is pooled with the later real measurements. The historical fast BPCells mode exceeded the matrix threshold on the small spatial target (1.292697178×10⁻⁶), unlike its matrix-threshold passes in the later real campaign. Continuous errors, rather than a single overall label, are therefore necessary.

Historical Python and R campaigns had different RSS/product/warm-up scopes: R fixed products included finitude checks inside the timed region and preceded PCA, and R RSS could include verification; Python had another timing boundary. The later real protocol moved finitude outside both product timers, products after PCA, and verification to separate processes. These improvements do not retroactively make the old sessions comparable.

Before the first later real PCA, two harness incidents were preserved: a lazily registered Matrix Market thread pool stopped preparation, and R-version metadata failed JSON serialization. Separate revisions corrected execution control and metadata conversion; no numerical core, count-selection rule or threshold changed. A later report-writer error concerning zero-completion summary rows was corrected without changing measurements. Original scripts, partial outputs, failure receipts, amendments and their charged times remain available. A post-campaign wording clarification distinguishes streamed direct oracles from the small dense Scanpy candidate. These records preclude describing execution as an error-free preregistration.

## 6. Discussion

The supported contribution is a reproducible software interface for explicit representations of a fixed NB transformation, with separate resource, analytic-selection and observed-precision diagnostics. The later real results support fidelity of the unchanged installed core across the two new resources and document storage compression at repeated depths. They also show that compression alone does not establish cheaper products, a faster pipeline or lower RSS.

The comparison does not establish the first implicit negative-binomial PCA. BPCells is a direct existing implicit comparator, and its slow mode passed the final real criteria. Scanpy's admitted official path also passed. nbpearson's additional value lies in an accessible Python operator API, an explicit choice between three representations, direct control of interpolation selection, and a transparent distinction between the mathematical bound, floating-point behavior and downstream solver accuracy. The evaluation supports these capabilities; it does not prove their combination globally novel or absent from all other software.

The analytic bound can be conservative and its floating realization is not a full certificate. It does not validate the computation of margins, cancellation in the correction, interpolation evaluation, products or SVD. Small centered matrices can have large relative error despite small absolute error, and L=0 does not justify declaring A=0. Decimal agreement at two precisions does not supply interval bounds. Subspace interpretation depends on spectral separation; agreement of an isolated axis near repeated singular values is not required or established.

Evaluation limitations are material. Two count resources and nested targets do not establish inter-donor or universal biological generalization. Technical process repetitions are not independent biological replicates. Original acquisition histories remain partly undocumented under A1, and a local hash does not authenticate a provider. The historical and later campaigns have different measurement controls. The later session used randomized ordering and a nominally shared process-RSS boundary but still has runtime baselines, solver/start and timer-resolution differences; three repetitions cannot establish universal rankings or small timing effects. Conservative refusals leave large Scanpy performance unknown under the stated admission policy.

No clustering, cell-type accuracy, biomarker, clinical inference or downstream biological benefit was evaluated. MIT selection for original code does not resolve dataset rights or third-party licence terms. The result warrants a bounded software manuscript, not a publication guarantee or a claim that all scientific questions are closed.

## 7. Availability and declarations

### 7.1. Software and evidence availability

The evaluated local artifact is nbpearson 0.1.0.dev1; the preserved wheel SHA-256 is 6334eb9758d004ba7171b8c430f4b1df9d659ac2327ff152db26905b282238e7. Installed source files matched that wheel in saved checks. The investigator selected the MIT licence for original code and designated [https://github.com/mohkone/nbpearson](https://github.com/mohkone/nbpearson) as the repository. This revision does not verify its visibility, contents or a versioned release and does not claim a public release, archival identifier or DOI. Copyright-holder attribution and completion of release licensing remain open.

Evidence paths, identifiers, limitations and prior bibliographic verification are mapped in [REFERENCE_AND_EVIDENCE_MAP.md](REFERENCE_AND_EVIDENCE_MAP.md). The author files refer to local saved evidence; they are not a self-contained public data deposit. No research matrix or runtime has been redistributed here. Dataset-specific access/reuse rights, local-to-external acquisition chains and any appropriate ethics statement require the responsible investigators' confirmation. Public availability, an article licence or software licence is not used to infer rights over local count files.

### 7.2. Author contributions, funding and conflicts

The following roles are reproduced from the investigator's supplied author declaration, not inferred from names or independently verified: **Mohamed Kone:** Conceptualization; Methodology; Software; Formal analysis; Investigation; Data curation; Visualization; Writing – Original Draft. **Chao Hou:** Validation; Writing – Review & Editing. **Gaoussou Haidara:** Data curation; Validation; Writing – Review & Editing. **ShuLin Wang:** Supervision; Methodology; Writing – Review & Editing.

The investigator declares that the research received no funding and that the authors have no conflicts of interest. These statements are investigator declarations, not an independent audit of author finances or conflicts.

Author order, common affiliation and corresponding-author contact follow the investigator's declaration. A prior statement of collective approval applied to an earlier manuscript; **approval of this newly generated V3 by every author remains pending**. The extent of direct human verification by each author must also be documented before submission. Ethics, consent or a documented non-applicability determination has not been supplied and is not invented.

### 7.3. Declaration of generative AI and AI-assisted technologies

The following disclosure was supplied by the investigator during preparation of V3:

> OpenAI ChatGPT and OpenAI Codex were used during the development, evaluation, documentation, and manuscript preparation of this study. The exact model versions used throughout the project were not consistently recorded.
>
> ChatGPT assisted with research planning, methodological discussion, interpretation and critical assessment of computational results, targeted literature and bibliographic review, and drafting and editing manuscript text.
>
> Codex assisted with the development and revision of Python and R scripts, automated testing, experimental workflow execution, dataset and provenance verification, benchmarking, preparation of results tables, technical documentation, and manuscript drafting and revision.
>
> The research objectives, methodological decisions, dataset selection, publication strategy, and author declarations were directed by the investigators. The lead investigator manually acquired the confirmatory datasets, supplied provenance information, and explicitly approved the documented acquisition-provenance amendment.
>
> Computational outputs were assessed through recorded software tests, numerical-reference comparisons, predefined accuracy criteria, file-integrity checks, and preserved execution records. These automated checks do not constitute independent human replication.
>
> The extent of direct human verification of the code, results, references, and final manuscript by each author remains to be documented before submission.
>
> The human authors retain responsibility for the scientific conclusions, accuracy, originality, and final submitted content.

No independent human-replication claim is attached to the present documentary review. This editorial task read saved records only and did not rerun numerical experiments.

## 8. References

The keys below refer to the already documented bibliography retained in [V2.1 references.bib](../nbpearson_manuscript_v2_1/references.bib). No new literature search was performed for V3. Article, author draft, software and API-documentation evidence are distinguished; saved installed signatures, not current web pages, establish experimental interfaces. The full inherited-key map and unresolved bibliographic limits are in the evidence map.

- **Lause2021Pearson.** Lause J, Berens P, Kobak D. Analytic Pearson residuals for normalization of single-cell RNA-seq UMI data. *Genome Biology*. 2021;22:258. [doi:10.1186/s13059-021-02451-7](https://doi.org/10.1186/s13059-021-02451-7).
- **BerrutTrefethen2004.** Berrut JP, Trefethen LN. Barycentric Lagrange Interpolation. *SIAM Review*. 2004;46(3):501–517. [doi:10.1137/S0036144502417715](https://doi.org/10.1137/S0036144502417715).
- **Trefethen2010Draft.** Trefethen LN. *Approximation Theory and Approximation Practice*. February 2010 author draft, Oxford archive; Theorem 8.2, printed p.43/PDF p.22. [Consulted draft](https://people.maths.ox.ac.uk/~trefethen/trefethen_sample.pdf). The theorem number is version-specific.
- **Trefethen2019ChebfunGuide.** Trefethen LN. Chebfun Guide, Chapter 4: Chebfun and Approximation Theory. Revision displayed May 2019; §4.5, Theorem 3. [Guide](https://www.chebfun.org/docs/guide/guide04.html).
- **GoldbergOracleReprint.** Goldberg D. What Every Computer Scientist Should Know About Floating-Point Arithmetic. Edited reprint in Oracle Numerical Computation Guide, Appendix D; Cancellation section. [Reprint](https://docs.oracle.com/cd/E19957-01/806-3568/ncg_goldberg.html). This web edition's date and the original DOI were not established in the inherited review.
- **OgitaRumpOishi2005.** Ogita T, Rump SM, Oishi S. Accurate Sum and Dot Product. *SIAM Journal on Scientific Computing*. 2005;26(6):1955–1988. [doi:10.1137/030601818](https://doi.org/10.1137/030601818).
- **Virtanen2020SciPy.** Virtanen P, Gommers R, Oliphant TE, et al.; SciPy 1.0 Contributors. SciPy 1.0: Fundamental Algorithms for Scientific Computing in Python. *Nature Methods*. 2020;17:261–272. [doi:10.1038/s41592-019-0686-2](https://doi.org/10.1038/s41592-019-0686-2).
- **Wolf2018Scanpy.** Wolf FA, Angerer P, Theis FJ. SCANPY: large-scale single-cell gene expression data analysis. *Genome Biology*. 2018;19:15. [doi:10.1186/s13059-017-1382-0](https://doi.org/10.1186/s13059-017-1382-0). The later Pearson-PCA interface requires its own documentation.
- **ParksAbdi2025BPCells031.** Parks B, Abdi I. BPCells: Single Cell Counts Matrices to PCA. R package version 0.3.1; software citation recommended by its authors, 2025. [Citation page](https://bnprks.github.io/BPCells/authors.html). No unestablished paper or DOI is assigned.
- **SciPyBarycentricDoc; SciPyLinearOperatorDoc; SciPySvdsDoc.** SciPy community. Official API documentation for [BarycentricInterpolator](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.BarycentricInterpolator.html), [LinearOperator](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.LinearOperator.html) and [svds](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.svds.html). Inherited consultation: 13 November 2026, documentation 1.18.0; distinct from installed SciPy 1.18.1.
- **ScanpyPearsonPCADoc.** Scanpy development team. [normalize_pearson_residuals_pca documentation](https://scanpy.readthedocs.io/en/stable/generated/scanpy.experimental.pp.normalize_pearson_residuals_pca.html). Inherited initial consultation was reported; a later complete reread was unavailable during documentary review. Installed Scanpy 1.12.5 signatures are saved separately.
- **BPCellsPearsonDoc031; BPCellsSvdsDoc031.** BPCells authors. Version 0.3.1 documentation for [sctransform_pearson](https://bnprks.github.io/BPCells/reference/sctransform_pearson.html) and [svds](https://bnprks.github.io/BPCells/reference/svds.html). Inherited consultation: 13 November 2026; native execution receipts establish the installed functions.
- **GEO2025GSM8594567.** NCBI Gene Expression Omnibus. [GSM8594567: P1 Human Colon Cancer](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM8594567). Official sample record, 2025; links GSE280315/GSE280318.
- **FariaDeOliveira2025VisiumHD.** Faria de Oliveira M, Romero JP, Chung M, et al. High-definition spatial transcriptomic profiling of immune cell populations in colorectal cancer. *Nature Genetics*. 2025;57(6):1512–1523. [doi:10.1038/s41588-025-02193-3](https://doi.org/10.1038/s41588-025-02193-3). Cited for the historical source, not as replicated biological evidence.

The two later 10x resource pages and their saved qualification/admission records are listed as data-provenance evidence in the map: [Human PBMC 10k Chromium X](https://www.10xgenomics.com/datasets/10k-human-pbmcs-3-ht-v3-1-chromium-x-3-1-high) and [Mouse Brain NextGEM 10k](https://www.10xgenomics.com/datasets/10k-Mouse-Brain-CNIK-3p-nextgem). No new access, licence verification or provider authentication was performed for this manuscript.

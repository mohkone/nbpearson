# nbpearson — correctif interne 0.1.0.dev1

Petit paquet CPU/binary64 de trois représentations explicites des résidus NB
standards centrés. Le nom `nbpearson` est provisoire et local ; sa disponibilité
sur PyPI n'a pas été vérifiée. Aucun droit de redistribution publique, affiliation,
validation tierce ou publication scientifique n'est annoncé.


Maintenance ciblée de F1/F2, dans un répertoire distinct. `../nb_pca_package/`
conserve intégralement la préversion dev0 et son wheel. Pas de nouveau cœur,
modèle, dispatcher, campagne comparative ou passage sur données de recherche.
Les corrections et leurs tests sont résumés dans `validation/CORRECTIONS.md`.
Environnement local utilisé sans modification : Python3.12.3, NumPy2.5.4,
SciPy1.18.1. L'environnement Python3.13.5/NumPy2.3.5/SciPy1.17.0 de la revue
est un environnement distinct, non reproduit artificiellement ici.

## Cible et choix manuel

`A = H clip((X - mu)/sqrt(mu + mu**2/theta), -c, c)`, avec
`mu[i,j] = depth[i] * proportion[j]` et centrage par colonne **après** clipping.
Un seul theta scalaire fini >0 ; pas de lots, dispersion par gène, Poisson ou
scaled-NB, pas d'adaptateur AnnData. Les trois choix sont obligatoirement manuels :

| représentation | fond conservé | précision |
|---|---|---|
| `interpolated` | gauche N×r, droite G×r | interpolant SciPy stabilisé v5 |
| `interpolated_grouped` | gauche U×r, droite G×r, index N | même interpolant v9, profondeurs binary64 exactement égales |
| `exact_grouped` | table U×G, index N | sans erreur d'interpolation, calcul toujours flottant |

Ni arrondi des profondeurs, ni agrégation des comptes ou changement des poids
des observations. Le centrage des facteurs groupés utilise les multiplicités ;
les transposés **somment** les poids des groupes. Ancrage rationalisé v5 et
correction des colonnes entièrement présentes sont conservés. Une profondeur
unique annule le fond centré, pas nécessairement l'opérateur entier.

## API fixée

```python
from nbpearson import build_operator

result = build_operator(
    X,                                  # scipy.sparse CSR, comptes entiers
    representation="interpolated_grouped",  # obligatoire ; aucun "auto"
    theta=100.0,
    clip="sqrt_n",                      # ou seuil fini >= sqrt(theta), ou None
    matrix_rtol=1e-6,
    max_nodes=128,
    memory_budget_bytes=512 * 2**20,
)
A, info = result.operator, result.diagnostics
```

`A` est un `scipy.sparse.linalg.LinearOperator`, dtype float64, avec matvec,
rmatvec, matmat et rmatmat. Aucun solveur ou choix de représentation interne. **Les opérandes des quatre
produits doivent être numériques réels**. Tout dtype complexe (même à partie
imaginaire nulle) est refusé par `TypeError`, avant le calcul, pour les trois
représentations : matvec, rmatvec, matmat, rmatmat, ainsi que les transposés.
Aucune extraction implicite de partie réelle et aucun avertissement suivi
d'un résultat tronqué. Les comptes restent réels comme en dev0.
Pour `exact_grouped`, **omettre** `matrix_rtol` et `max_nodes`, ou les passer à
`None` ; une valeur non applicable est refusée. Pour les interpolants, leurs
valeurs `None` se résolvent à 1e-6 et 128. `n_norm_pairs=16` permet au plus les
16 paires adjacentes disjointes historiques ; s'applique seulement à la sélection.

`clip=None` est le mode NB historique sans plafonnement. `clip="sqrt_n"` peut
être hors domaine si N < theta : dans ce cas le constructeur refuse, sans changer
c. Un seuil explicite inférieur à sqrt(theta), theta infini ou un tableau de
theta est refusé. Aucune correction de comptes n'est effectuée en place.

## Entrées et marges

CSR SciPy matrice ou array 2D uniquement, dimensions >=2, données réelles finies,
non négatives et exactement entières dans leur dtype. Pas de tolérance cachée
pour accepter des données normalisées. Les doublons sont sommés et indices
triés sur une copie privée, zéros stockés retirés ; l'entrée est conservée.
Les données négatives sont refusées **avant** sommation de doublons.

Par défaut, les marges sont calculées une seule fois depuis la CSR canonique,
en binary64 : ce n'est pas un contrat de sommes entières exactes. Les marges
nulles sont refusées, sans supprimer silencieusement un axe. Pour les enlever
extérieurement, conserver explicitement indices et identifiants de lignes/gènes,
puis calculer les marges sur l'univers final commun à tous les bras.

Les marges historiques peuvent être fournies comme paramètres binary64 fixes :

```python
from nbpearson import FixedMargins, counts_fingerprint
fixed = FixedMargins(depths=n64, proportions=p64,
                     counts_fingerprint=counts_fingerprint(X),
                     source="identifiant du manifeste et de l'univers gelés")
result = build_operator(X, representation="exact_grouped", margins=fixed)
```

Leur empreinte est liée aux comptes canoniques. Formes, finitude, positivité et
somme des proportions sont vérifiées (8 epsilon binary64 pour la seule somme
des probabilités). Elles ne sont pas recalculées ni assimilées à des marges
exactes depuis les entiers. Les diagnostics conservent contrat, source et
empreintes ; une alerte signale le risque de confusion des totaux au-delà de 2⁵³.

## Sélection, ressources et diagnostics

Le sélecteur reçoit maintenant le coût d'admission de la représentation
demandée : `interpolated_grouped` n'est plus refusé pour un facteur N×r qu'il
ne construit pas. Le modèle comprimé, en octets, est :

```text
baseline_high_water + 3*csr_bytes
+ 8*(4*U*r + 16*G*r + 3*r*r + 4*N + 4*U + 3*N*21 + 6*256*G)
+ 64*2**20
```

`csr_bytes` est la taille réelle des trois buffers de la CSR canonique. Les
coefficients couvrent copies CSR/CSC, évaluation de la base U×r, transitoires du
facteur droit rationalisé G×r et masques, identité/bases SciPy r×r, indices et
buffers, blocs de construction et réserve historique du solveur. Ce coût n'est
pas limité au stockage permanent. La même fonction sert à la sélection et à
l'admission finale, sans fallback. L'ancien modèle N×r reste applicable au bras
non groupé ; le budget n'est pas assoupli et le niveau processus n'est pas
neutralisé en production.

Pour le cas de régression 100000×2, U=2, r=14 et baseline=0, cette formule donne
125542700 octets, sous128 Mio. Cette baseline nulle sert **uniquement au test
unitaire d'arithmétique d'estimation**, jamais à une mesure de RSS ni à l'API
de production. Les tests publics séparés utilisent le vrai niveau processus.

Le sélecteur historique emploie N observations, jamais U groupes non pondérés,
les mêmes nœuds Lobatto et une règle logarithmique `Delta_r <= matrix_rtol * L`.
Le résultat est une **borne analytique en arithmétique exacte**. Son L flottant
n'est pas certifié minorant ; les erreurs d'arrondi ne sont pas encadrées.
Les diagnostics disent `floating_validation="NOT_EVALUATED"` tant qu'aucune
comparaison externe n'a été exécutée. Une SVD convergée ne modifie pas ce statut.

`SelectionError.diagnostics` conserve `node_limit`, `insufficient_norm_bound`
ou autre statut d'échec. L=0 ne prouve pas A=0 ; aucune division par epsilon.
Si les profondeurs sont exactement égales, le sélecteur peut choisir un nœud,
même si L=0 ; la correction reste calculée. `ResourceLimitError` indique une
admission estimée refusée **avant** construction de la grande table/facteurs.
Il n'y a aucun fallback vers un autre opérateur, y compris le contrôle direct
historique qui reste un outil d'évaluation hors API.

Le budget (au plus 512 Mio dans cette préversion) inclut un niveau processus
high-water quand disponible, copies CSR/CSC, facteurs, blocs et réserve solveur
historique 64 Mio/21 triplets. C'est une estimation conservatrice, pas une garantie
de RSS, ni un contrat pour toutes les largeurs de blocs choisies ensuite par
l'appelant. Le watchdog appartient au harnais externe. Les diagnostics listent
stockage réel des tableaux et ressources estimées ; aucun octet biologique
individuel n'est affiché par défaut.

Quasi-nullité et annulations persistent comme limites générales : une norme
petite n'est pas zéro et les directions SVD d'un espace nul ne sont pas identifiées.
Les sous-espaces doivent être interprétés avec leurs écarts spectraux.

## Exemple et vérification locale

`examples/minimal_counts.py` crée uniquement des comptes synthétiques et appelle
`svds` : 21 triplets, 20 composantes retenues, ncv64, tol1e-10, maxiter10000,
initialisation seed6619. Les triplets sont explicitement triés. `matrix_rtol`,
tolérance SVD et nombre de composantes sont distincts ; aucune variance expliquée
totale n'est déduite de la seule somme des composantes retenues.

Le noyau nécessite seulement Python, NumPy et SciPy. Environnement réellement
testé : voir `validation/manifest.json` et `validation/CORRECTIONS.md`.
La suite comprend aussi les régressions fournies F1/F2 et un oracle Decimal
autonome80/160 sur de minuscules fixtures presque nulles et à L=0.
`python -m unittest discover -s tests -v` lance toute la suite ; sans archives,
les quatre tests historiques sont explicitement ignorés et comptés séparément.
Les tests optionnels de fidélité lisent les archives, mais **le wheel n'en dépend
ni à l'import ni à l'exécution**. Ils ne sont pas installés comme dépendance.
`tests/test_api.py` fonctionne sans archives. Depuis une installation locale :
`python examples/minimal_counts.py` ;
`python -m unittest discover -s tests -p test_api.py -v`.
Le harnais de validation consigne les commandes complètes hors ligne, les
chemins d'import installés et les limites CPU/mémoire ; aucune publication.

## Résultats historiques : portée distincte

Les trois contrôles PBMC cités par le rapport dev0 ne sont pas réexécutés pour
ce correctif ciblé. Leurs résultats restent attribués à dev0, sans nouvelle
mesure PBMC/spatiale ni nouvelle certification de dev1 sur données réelles.

Les trois chemins visent la même quantité dans leur domaine, avec coûts
différents. La grille v10 rapportait 51 ACP achevées, un arrêt pour budget et
deux répétitions non exécutées, ainsi que 18 contrôles numériques satisfaits.
Ce sont les résultats de ce protocole, **pas une certification du paquet extrait**.
Les médianes v10 favorisaient B contre A aux U répétés et A lorsque U=N, sans
règle universelle ni dispatcher. Les produits transposés par blocs de B restaient
plus coûteux dans cette grille. Aucune fusion de médianes entre sessions.

La colonne historique C contient cinq chemins groupés exacts en cache et un
contrôle `direct_streamed_UeqN` à U=N/G8000, pas une même implémentation partout.
Sources à consulter dans le dépôt de développement :
[résultats v10](../nb_pca_dev/v10/RESULTS.md),
[manifeste v10](../nb_pca_dev/v10/manifest.json),
[résultats v9](../nb_pca_dev/v9/RESULTS.md).
Ces liens sont documentaires, jamais des imports nécessaires au wheel.
Le reçu du bras v10 censuré donne 300,352 s de durée de processus observée pour
un seuil de construction+ACP de 300 s. Les événements intermédiaires ne sont pas
horodatés séparément : **ACTUAL_STOP_DELAY_UNRESOLVED**. La ligne communiquée
327,6387 s ne permet pas de reconstruire une latence d'arrêt depuis les seuls
reçus conservés. Aucun arrêt exactement à 300 s n'est affirmé, aucun bras rejoué.

## Provenance, droits et références

`validation/SOURCE_MAP.json` attribue chaque fonction extraite aux fichiers
historiques et à leurs empreintes, en distinguant réorganisation et modification
des contrats d'entrée/ressources. `THIRD_PARTY_NOTICES.md` conserve la portée
interne et les décisions de diffusion à confirmer. Pas de licence publique
inventée, de nouveauté théorique ou de publication acquise.

Références officielles de mise en œuvre, distinctes des mesures locales :
[LinearOperator](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.LinearOperator.html),
[svds](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.svds.html),
[PyPA packaging](https://packaging.python.org/en/latest/tutorials/packaging-projects/),
[src layout](https://packaging.python.org/en/latest/discussions/src-layout-vs-flat-layout/).

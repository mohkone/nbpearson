# Bounded figure-production changelog

16 November 2026. This directory contains separate production candidates addressing Q1–Q7 from the preceding figure QA. The original figures, plotting scripts/data, manuscripts, scientific tables, numerical modules and execution evidence remain read-only. The software reference remains **nbpearson 0.1.0.dev1**, commit **`c0f41107f888d69713c8e22e488bf1e7386f8c4d`**. The investigator's reported four-author project approval is accepted; no human approval of these exact new graphics is asserted.

The current [GigaScience Instructions to Authors](https://academic.oup.com/gigascience/pages/instructions_to_authors) were checked on 16 November 2026. This operation applies the user's strict production targets: 170-mm width, every actual font run at least 7 pt including mathematical scripts, visible strokes 0.25–1 pt, and figure plus actual title/legend at most 225 mm. The policy record and independent actual-PDF verification are linked from [TYPOGRAPHY_AND_STROKE_VERIFICATION.md](TYPOGRAPHY_AND_STROKE_VERIFICATION.md).

## Source copies and change boundary

`source_scripts/` retains exact copies of the five original plotting scripts and shared style. `source_data/` retains their exact saved scalar/documentary inputs; `pinned_plot_data/` retains original exports/maps. The 30 pinned copies have source and copy hashes in [PINNED_COPY_MANIFEST.json](verification/PINNED_COPY_MANIFEST.json) and an independent identity check. No biological count matrix was needed or copied.

All five plotting scripts in `scripts/` remain byte-identical to their originals. The copied `plot_style.py` changes only the output destination and delegates saving to the new [production_style.py](scripts/production_style.py). That hook operates on already constructed plotting artists. It changes fonts, formatting, strokes, overall title visibility and layout; it never imports nbpearson or evaluates a residual/product/PCA. [Script diffs](verification/SCRIPT_CORRECTION_DIFFS.patch) record the exact modifications and new hook.

## Q1–Q7 resolutions

| Finding | Production transformation | Preserved meaning and verification |
| --- | --- | --- |
| Q1: F1 small mathematical scripts | Existing F1 text containing mathematical sub/superscripts uses at least 10.2-pt base type; MathText's 0.7 script scale gives actual 7.14-pt scripts. All A/B/C background-detail blocks use the same 10.2-pt base size. B metadata and C's all-distinct statement wrap across additional lines | Every equation, word, branch, group reduction and arrow relationship is retained. Whitespace-only comparison and unchanged graph-building code establish identity; final visual inspection checks box clearance |
| Q2: F3 log exponents | Replace the mathematical logarithmic major-tick formatter by full-size compact scientific strings such as `1e-16`, at least 7.2 pt | Exact tick numbers, limits, nine logarithmic axes, points and criteria unchanged |
| Q3: S2 log exponents | Same tick typography on a/c/d; b remains linear | No reference norm or residual direction/denominator changed |
| Q4: S3 log exponents | Same tick typography on c/d; other axes remain linear | All depth categories, adverse array totals, thresholds and saved technical marks unchanged |
| Q5: S5 log exponents | Same tick typography on matrix panels a/b | Historical Python/R separation, tick values, timing axes and categorical datasets unchanged |
| Q6: S5 whisker width | Clamp visible nonzero strokes to 0.25–0.9 pt, including saved timing whiskers previously drawn at 1 pt | Whisker endpoints and min–max interpretation unchanged. Exact 170-mm canvas avoids enlargement to 1.066 pt |
| Q7: all figures and legends | Fixed full-canvas PDF/SVG width of 170 mm without tight-bbox rescaling; compact uniform panel layout and unused title space; compose the actual unchanged title/legend separately | No selective panel/point enlargement, axis truncation, smoothing or omission. Every composed proof measures below 225 mm |

All visible base text is at least 7.2 pt. Existing colour, marker shape/size, opacity, point order, categorical offsets, method labels, panel titles, scientific annotations, threshold-line styles and numerical-axis limits/ticks are retained. The permitted stroke clamp also affects any existing 1-pt marker edges/legend proxies; no mark is removed. Zero-width invisible edges are not turned into new visible borders. PDFs are vector with embedded fonts; SVG text is outlined rather than dependent on a recipient's fonts.

Seven redundant overall graphic titles are hidden, leaving the actual original manuscript figure titles in the manuscript and the composed proof. F1 had no redundant overall title. Essential panel titles, target dimensions, method keys and numerical/repetition qualifications remain inside the graphics. The actual current legends are unchanged; Markdown bold/backtick delimiters are interpreted for proof typesetting rather than printed as characters. Alt text remains in the unchanged manuscript/supplement and is not part of the printed legend-height measurement.

## Layout changes

| Figure | Candidate canvas (mm) | Grid adjustment relative to original script | Actual title+legend proof height (mm) |
| --- | --- | --- | ---: |
| F1 | 170 × 165 | Original diagram coordinates retained; font growth and two detail wraps only | 212.392 |
| F2 | 170 × 163 | Grid top .88 → .91 after removing overall title | 216.742 |
| F3 | 170 × 177 | Top .91 → .95; bottom .20 → .205; vertical grid spacing .58 → .62 | 214.867 |
| S1 | 170 × 182 | Grid top .90 → .93 | 223.042 |
| S2 | 170 × 138 | Grid top .88 → .94 | 172.692 |
| S3 | 170 × 146 | Existing grid positions retained; overall title removed | 199.742 |
| S4 | 170 × 140 | Existing grid positions retained; overall title removed | 184.217 |
| S5 | 170 × 162 | Grid top .79 → .80; session subtitle/method legend retained | 222.092 |

Canvas resizing affects the whole existing grid, not selected methods or favorable observations. Axis numerical geometry and equal-panel arrangements are preserved. The artist audit compares the exact plotted numerical values and identities, rather than claiming pixel equality after intentional typography/layout changes.

## Execution, visual correction and retained failures

Rendering used the already available Python 3.12.3 / Matplotlib 3.11.2 / NumPy 2.5.4 / Pillow 13.0.0 environment, without an installation. Each rendering process was restricted to one available logical CPU, one numerical thread, 90 s CPU/wall limits and 2 GiB virtual address space. These are production-render limits, not scientific performance observations. Commands, versions and logs are in [the render receipt](verification/RENDER_EXECUTION_RECEIPT.json) and [environment record](verification/RENDER_ENVIRONMENT.json).

The first actual F1 view showed C's enlarged all-distinct text touching its box edges. That candidate, preview, style and finding are retained under `verification/production_pass_1/`. One bounded corrective render wrapped the same statement and equalized A/B/C detail sizes; [F1_FINAL_RENDER_RECEIPT.json](verification/F1_FINAL_RENDER_RECEIPT.json) records it. The final F1 was opened again and the scientific/technical checks repeated. No data or original caption changed.

The proof compositor's early tooling/serialization failures are retained in `verification/proof_production_attempts.json`; they are separate from the successful final proofs. Superseded F1 proof evidence is retained. Current proof creation metadata is fixed for deterministic output and is not asserted to be the execution date; actual execution dates are in receipts.

## Exact new artifacts

`figures_candidate/` contains eight separate PDFs and eight SVGs, without manuscript legends embedded into the graphic. `proofs/` contains the actual title/legend composites for inspection only. `previews/170mm/` and `previews/proofs/` contain deterministic inspection PNGs; the two before/after contact sheets are navigation only. The exact hashes and original→candidate mapping are in [CANDIDATE_FILE_MANIFEST.json](verification/CANDIDATE_FILE_MANIFEST.json); the complete new-tree manifest is separate.

No caption alternative, new scientific observation, software change, biological analysis, numerical rerun, external transmission, GitHub action, release/DOI or submission was performed. These candidates do not replace originals or constitute human scientific approval.

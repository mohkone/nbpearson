"""Render saved later-real storage/cost records only; no numerical experiment."""
import csv
import hashlib
import json
from pathlib import Path
from statistics import median

import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, ScalarFormatter

from plot_style import ROOT, OUT, COLORS, METHODS, MARKERS, TARGETS, TARGET_LABELS, setup, save

SUMMARY = "nbpearson_publication_revision_v1/CONFIRMATORY_RESULTS_FOR_MANUSCRIPT.csv"
PERF = "nbpearson_confirmatory_real_v1/real_performance_results.csv"
DEPTH = "nbpearson_confirmatory_real_v1/real_depth_diversity.csv"
SHORT = ["A", "B", "C", "Scanpy", "BP fast†", "BP slow"]
PRODUCTS = ["matvec", "rmatvec", "matmat8", "rmatmat8"]
PRODUCT_LABELS = ["Vector product", "Transposed vector", "Width-eight block", "Transposed width-eight"]
FIELDS = ["plot_part", "panel", "dataset", "method", "record_type", "repetition", "metric",
          "raw_value", "raw_unit", "display_value", "display_unit", "display_transform",
          "source_path", "source_sha256", "source_record_index", "source_key", "source_field"]


def rows(path):
    with (ROOT / path).open(newline="") as handle:
        return list(csv.DictReader(handle))


def main():
    setup()
    plt.rcParams.update({"xtick.labelsize": 7.2, "ytick.labelsize": 7.2, "legend.fontsize": 7.2})
    summary, performance, depth = rows(SUMMARY), rows(PERF), rows(DEPTH)
    hashes = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in [SUMMARY, PERF, DEPTH]}
    si = {(r["dataset"], r["method"]): (i + 1, r) for i, r in enumerate(summary)}
    pi = {(r["dataset"], r["method"], int(r["repetition"])): (i + 1, r) for i, r in enumerate(performance)}
    di = {(r["dataset"], r["method"], int(r["repetition"])): r for r in depth}
    assert len(summary) == 24 and len(pi) == len(di) == 66 and pi.keys() == di.keys()
    records = []

    def add(part, panel, dataset, method, role, rep, field, row, source, index, scale=1.0, unit="s", display_unit="s"):
        raw = row[field]
        value = float(raw) * scale if raw else None
        records.append(dict(zip(FIELDS, [part, panel, dataset, method, role, rep, field, raw, unit,
            "" if value is None else format(value, ".17g"), display_unit,
            "identity" if scale == 1 else ("bytes / 2**20" if scale == 1 / 2**20 else "seconds * 1000"),
            source, hashes[source], index, row.get("configuration_id", row.get("pipeline_label", "")), field])))
        return value

    # Documentary consistency checks compare saved scalars, not residuals/products/PCA.
    for (dataset, method), (_, s) in si.items():
        reps = json.loads(s["repetitions_individual_values_json"])
        assert len(reps) == int(s["completed_PCA_repetitions"])
        for rep in reps:
            _, p = pi[dataset, method, rep["repetition"]]
            assert float(p["construction_pca_seconds"]) == rep["construction_pca_seconds"]
            assert float(p["peak_process_rss_bytes"]) == rep["peak_RSS_bytes"]
            if s["operator_storage_bytes"]:
                assert int(float(p["operator_storage_bytes"])) == int(s["operator_storage_bytes"])
                assert int(float(di[dataset, method, rep["repetition"]]["operator_storage_bytes"])) == int(s["operator_storage_bytes"])
        if reps:
            values = [pi[dataset, method, i][1] for i in [1, 2, 3]]
            assert float(s["construction_pca_median_seconds"]) == median(float(p["construction_pca_seconds"]) for p in values)
            assert float(s["construction_pca_min_seconds"]) == min(float(p["construction_pca_seconds"]) for p in values)
            assert float(s["construction_pca_max_seconds"]) == max(float(p["construction_pca_seconds"]) for p in values)
            assert float(s["rss_after_import_median_bytes"]) == median(float(p["rss_after_import_bytes"]) for p in values)
            assert float(s["observed_process_peak_RSS_min_bytes"]) == min(float(p["peak_process_rss_bytes"]) for p in values)
            assert float(s["observed_process_peak_RSS_max_bytes"]) == max(float(p["peak_process_rss_bytes"]) for p in values)
            for product in PRODUCTS:
                assert float(s[product + "_seconds_per_call_median"]) == median(float(p[product + "_seconds_per_call"]) for p in values)

    def base(ax, first=False):
        ax.set_ylim(5.6, -0.6)
        ax.set_yticks(range(6), SHORT if first else [""] * 6)
        ax.grid(axis="x", color="#dddddd", linewidth=0.35, zorder=0)
        ax.tick_params(axis="y", length=0)

    fig, axes = plt.subplots(3, 4, figsize=(166 / 25.4, 166 / 25.4))
    fig.subplots_adjust(left=.16, right=.99, top=.88, bottom=.16, wspace=.21, hspace=.48)
    for col, dataset in enumerate(TARGETS):
        numeric_storage = [float(si[dataset, m][1]["operator_storage_bytes"]) / 2**20 for m in METHODS if si[dataset, m][1]["operator_storage_bytes"]]
        for row in range(3):
            ax = axes[row, col]; base(ax, col == 0)
            if row == 0:
                ax.set_title(TARGET_LABELS[col], pad=7, fontsize=8)
                ax.set_xlim(0, max(numeric_storage) * 1.12)
                ax.xaxis.set_major_locator(MaxNLocator(3))
                ax.set_xlabel("Operator arrays (MiB)", fontsize=7.5)
            elif row == 1:
                ax.set_xscale("log"); ax.set_xlim(.04, 22); ax.set_xticks([.1, 1, 10]); ax.xaxis.set_major_formatter(ScalarFormatter())
                ax.set_xlabel("Construction + PCA (s)", fontsize=7.5)
            else:
                ax.set_xlim(60, 445); ax.set_xticks([100, 250, 400]); ax.set_xlabel("Process peak (MiB)", fontsize=7.5)
        for y, method in enumerate(METHODS):
            source_index, s = si[dataset, method]; color, marker = COLORS[method], MARKERS[method]
            ax = axes[0, col]
            if s["operator_storage_bytes"]:
                value = add("figure2_costs", "storage", dataset, method, "configuration_total", "", "operator_storage_bytes", s, SUMMARY, source_index, 1 / 2**20, "bytes", "MiB")
                ax.scatter(value, y, s=30, marker=marker, color=color, edgecolors="white", linewidths=.4, zorder=3)
            else:
                label = "not exposed" if method.startswith("BPCells") else "preflight"
                ax.text(.97, y, label, transform=ax.get_yaxis_transform(), ha="right", va="center", fontsize=7.2, color="#555555")
                records.append(dict(zip(FIELDS, ["figure2_costs", "storage", dataset, method, "categorical_omission", "", "operator_storage_status", s["operator_storage_status"], "category", "", "category", "no numeric value", SUMMARY, hashes[SUMMARY], source_index, s["configuration_id"], "operator_storage_status"])))
            if not int(s["completed_PCA_repetitions"]):
                for row, panel in [(1, "pipeline"), (2, "RSS")]:
                    axes[row, col].text(.97, y, "preflight", transform=axes[row, col].get_yaxis_transform(), ha="right", va="center", fontsize=7.2, color="#555555")
                    records.append(dict(zip(FIELDS, ["figure2_costs", panel, dataset, method, "categorical_nonexecution", "", "execution_status", s["execution_status"], "category", "", "category", "no numeric value", SUMMARY, hashes[SUMMARY], source_index, s["configuration_id"], "execution_status"])))
                continue
            for rep in [1, 2, 3]:
                index, p = pi[dataset, method, rep]; offset = (rep - 2) * .12
                value = add("figure2_costs", "pipeline", dataset, method, "technical_repetition", rep, "construction_pca_seconds", p, PERF, index)
                axes[1, col].scatter(value, y + offset, s=12, marker=marker, color=color, alpha=.6, linewidths=.35, zorder=2)
                value = add("figure2_costs", "RSS", dataset, method, "technical_repetition", rep, "peak_process_rss_bytes", p, PERF, index, 1 / 2**20, "bytes", "MiB")
                axes[2, col].scatter(value, y + offset, s=12, marker=marker, color=color, alpha=.6, linewidths=.35, zorder=2)
            low, high = [add("figure2_costs", "pipeline", dataset, method, role, "", field, s, SUMMARY, source_index) for role, field in [("saved_min", "construction_pca_min_seconds"), ("saved_max", "construction_pca_max_seconds")]]
            med = add("figure2_costs", "pipeline", dataset, method, "saved_median", "", "construction_pca_median_seconds", s, SUMMARY, source_index)
            axes[1, col].plot([low, high], [y, y], color=color, linewidth=.7, zorder=1)
            axes[1, col].scatter(med, y, s=32, marker=marker, color=color, edgecolors="black", linewidths=.5, zorder=3)
            low, high = [add("figure2_costs", "RSS", dataset, method, role, "", field, s, SUMMARY, source_index, 1 / 2**20, "bytes", "MiB") for role, field in [("saved_min", "observed_process_peak_RSS_min_bytes"), ("saved_max", "observed_process_peak_RSS_max_bytes")]]
            baseline = add("figure2_costs", "RSS", dataset, method, "saved_import_baseline_median", "", "rss_after_import_median_bytes", s, SUMMARY, source_index, 1 / 2**20, "bytes", "MiB")
            axes[2, col].plot([low, high], [y, y], color=color, linewidth=.7, zorder=1)
            axes[2, col].scatter(high, y, s=32, marker=marker, color=color, edgecolors="black", linewidths=.5, zorder=3)
            axes[2, col].scatter(baseline, y, marker="x", s=22, color="black", linewidths=.7, zorder=4)
    for row, label in enumerate(["a  Permanent arrays", "b  Pipeline duration", "c  Whole-process RSS"]):
        pos = axes[row, 0].get_position()
        fig.text(.018, (pos.y0 + pos.y1) / 2, label, fontsize=8,
                 weight="bold", rotation=90, ha="center", va="center")
    fig.suptitle("B versus A: smaller arrays without uniform time/RSS gains", fontsize=10, y=.99)
    fig.text(.08, .085, "B saves 5.4–8.4% of complete A arrays. Small marks: three technical repetitions.", fontsize=7)
    fig.text(.08, .055, "Large marks: saved pipeline median or maximal RSS; ×: saved import-baseline median.", fontsize=7)
    fig.text(.08, .025, "† Fast BPCells exceeds the triplet criterion. Arrays exclude counts, temporaries, outputs and solver memory.", fontsize=7)
    save(fig, "figure2_costs")

    fig, axes = plt.subplots(4, 4, figsize=(166 / 25.4, 189 / 25.4))
    fig.subplots_adjust(left=.16, right=.99, top=.90, bottom=.13, wspace=.21, hspace=.55)
    for row, product in enumerate(PRODUCTS):
        for col, dataset in enumerate(TARGETS):
            ax = axes[row, col]; base(ax, col == 0); ax.set_xscale("log")
            if row == 0: ax.set_title(TARGET_LABELS[col], pad=7, fontsize=8)
            if col == 0:
                pos = ax.get_position()
                fig.text(.018, (pos.y0 + pos.y1) / 2,
                         chr(97 + row) + "  " + PRODUCT_LABELS[row], fontsize=8,
                         weight="bold", rotation=90, ha="center", va="center")
            values = []
            for y, method in enumerate(METHODS):
                index, s = si[dataset, method]
                if not int(s["completed_PCA_repetitions"]):
                    ax.text(.97, y, "preflight", transform=ax.get_yaxis_transform(), ha="right", va="center", fontsize=7.2, color="#555555")
                    records.append(dict(zip(FIELDS, ["figure2_products", product, dataset, method, "categorical_nonexecution", "", "execution_status", s["execution_status"], "category", "", "category", "no numeric value", SUMMARY, hashes[SUMMARY], index, s["configuration_id"], "execution_status"])))
                    continue
                for rep in [1, 2, 3]:
                    pi_index, p = pi[dataset, method, rep]
                    value = add("figure2_products", product, dataset, method, "technical_repetition", rep, product + "_seconds_per_call", p, PERF, pi_index, 1000, "s", "ms")
                    assert value > 0; values.append(value)
                    ax.scatter(value, y + (rep - 2) * .12, color=COLORS[method], marker=MARKERS[method], s=12, alpha=.6, linewidths=.35)
                value = add("figure2_products", product, dataset, method, "saved_median", "", product + "_seconds_per_call_median", s, SUMMARY, index, 1000, "s", "ms")
                ax.scatter(value, y, color=COLORS[method], marker=MARKERS[method], s=32, edgecolors="black", linewidths=.5, zorder=3)
            ax.set_xlim(min(values) / 1.4, max(values) * 1.5)
            ax.set_xlabel("Time per call (ms)", fontsize=7.5)
            ax.xaxis.set_major_locator(__import__('matplotlib').ticker.LogLocator(base=10, numticks=3))
            ax.xaxis.set_major_formatter(__import__('matplotlib').ticker.FuncFormatter(lambda x, _: f"{x:g}"))
            ax.xaxis.set_minor_formatter(__import__('matplotlib').ticker.NullFormatter())
    fig.suptitle("Complete fixed products in the later real campaign", fontsize=10, y=.99)
    fig.text(.08, .055, "Small marks: mean of ten timed calls; large marks: saved median of three process means.", fontsize=7)
    fig.text(.08, .025, "Direction-specific axes. † Fast BPCells is outside the stricter final PCA criterion.", fontsize=7)
    save(fig, "figure2_products")

    for part in ["figure2_costs", "figure2_products"]:
        with (OUT / "plot_data" / (part + ".csv")).open("w", newline="") as handle:
            writer = csv.DictWriter(handle, FIELDS); writer.writeheader(); writer.writerows(r for r in records if r["plot_part"] == part)
    audit = {"sources": [{"path": p, "sha256": h} for p, h in hashes.items()],
        "source_record_index_definition": "1-based CSV data-record index, excluding header",
        "exported_rows": len(records), "key": "dataset|method|repetition, or configuration_id for saved summaries",
        "display_conversions": ["bytes / 2**20 = MiB", "seconds * 1000 = ms"],
        "storage_annotation": "100*(A.operator_storage_bytes-B.operator_storage_bytes)/A.operator_storage_bytes; rounded endpoints 5.4–8.4%. Complete A permanent arrays are the denominator; inputs, temporaries, product outputs and solver memory are excluded.",
        "derived_scientific_quantities": [], "smoothing": False,
        "validation": "All 66 raw performance/depth keys match; saved scalar time/product medians, pipeline ranges and import medians checked against raw records. Saved summaries, not recomputed values, are plotted.",
        "repetition_display": "Deterministic vertical offsets -0.12, 0, +0.12 by repetition; numeric x values unchanged",
        "omissions": "Native BPCells arrays NOT_EXPOSED; Scanpy C2/C4 one preflight and two nonlaunches each, no numeric mark",
        "stratum": "Later real only; four nested targets from two sources; technical repetitions"}
    (OUT / "plot_data/figure2_source_map.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps({"figure2_export_rows": len(records), "source_consistency": "PASS", "rendered": ["figure2_costs", "figure2_products"]}))


if __name__ == "__main__":
    main()

"""Permitted figure-production changes only; reads no counts or scientific model."""
import importlib.util
import json
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib import ticker
from matplotlib.text import Text

BASE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("identity_snapshot", BASE / "verification/identity_snapshot.py")
identity = importlib.util.module_from_spec(spec)
spec.loader.exec_module(identity)

FIGURES = {
    "figure1_operator_architecture": ("F1", "Figure 1", 165),
    "figure2_costs": ("F2", "Figure 2", 163),
    "figure3_relative": ("F3", "Figure 3", 177),
    "figure2_products": ("S1", "Figure S1 supplementary material", 182),
    "figure3_absolute": ("S2", "Figure S2 supplementary material", 138),
    "figure4_overview": ("S3", "Figure S3 supplementary material", 146),
    "figure4_products": ("S4", "Figure S4 supplementary material", 140),
    "figureS1_historical_development": ("S5", "Figure S5 supplementary material", 162),
}


def scientific_tick(value, position):
    """Same numeric tick, one full-size text run instead of smaller math scripts."""
    return format(value, ".0e").replace("e-0", "e-").replace("e+0", "e+")


def clamp_stroke(value):
    # A zero-width invisible edge is left untouched. Visible nonzero strokes
    # have a safety margin below the 1-pt ceiling at the exact final width.
    return min(0.9, max(0.25, value)) if value else value


def format_figure(fig, stem):
    label, filename, height_mm = FIGURES[stem]
    changes = []
    identity.snapshot(fig, stem, BASE / "verification/identity_candidate_before")
    fig.set_size_inches(170 / 25.4, height_mm / 25.4, forward=True)
    changes.append({"kind": "fixed_canvas", "width_mm": 170, "height_mm": height_mm,
                    "crop": "none; bbox_inches=None"})
    if fig._suptitle is not None:
        changes.append({"kind": "remove_duplicate_overall_title", "text": fig._suptitle.get_text(),
                        "location_retained": "unchanged manuscript title/legend and composed proof"})
        fig._suptitle.set_visible(False)

    for ax in fig.axes:
        for axis in [ax.xaxis, ax.yaxis]:
            if isinstance(axis.get_major_formatter(), ticker.LogFormatterMathtext):
                axis.set_major_formatter(ticker.FuncFormatter(scientific_tick))
                changes.append({"kind": "log_tick_typography", "axis": axis.axis_name,
                                "meaning": "unchanged numeric ticks and logarithmic scale; full-size 1e notation"})
        for line in ax.lines + ax.get_xgridlines() + ax.get_ygridlines():
            line.set_linewidth(clamp_stroke(line.get_linewidth()))
            line.set_markeredgewidth(clamp_stroke(line.get_markeredgewidth()))
        for axis in [ax.xaxis, ax.yaxis]:
            for tick in axis.get_major_ticks() + axis.get_minor_ticks():
                for line in [tick.tick1line, tick.tick2line, tick.gridline]:
                    line.set_linewidth(clamp_stroke(line.get_linewidth()))
                    line.set_markeredgewidth(clamp_stroke(line.get_markeredgewidth()))
        for patch in list(ax.patches) + list(ax.spines.values()):
            patch.set_linewidth(clamp_stroke(patch.get_linewidth()))
        for collection in ax.collections:
            collection.set_linewidths([clamp_stroke(float(x)) for x in collection.get_linewidths()])
    for legend in fig.legends:
        for handle in legend.legend_handles:
            if hasattr(handle, "set_linewidth"):
                handle.set_linewidth(clamp_stroke(handle.get_linewidth()))
            if hasattr(handle, "set_markeredgewidth"):
                handle.set_markeredgewidth(clamp_stroke(handle.get_markeredgewidth()))

    for text in fig.findobj(Text):
        text.set_fontsize(max(7.2, text.get_fontsize()))
        if label == "F1" and "$" in text.get_text() and ("_" in text.get_text() or "^" in text.get_text()):
            # MathText scripts use a 0.7 scale; 10.2 * 0.7 = 7.14 pt.
            text.set_fontsize(max(10.2, text.get_fontsize()))
        if label == "F1" and text.get_text().startswith("Background:"):
            text.set_fontsize(10.2)
        if label == "F1" and "$U_d=N$ gives an $N$ × $G$ table" in text.get_text():
            text.set_text(text.get_text().replace("$U_d=N$ gives an $N$ × $G$ table", "$U_d=N$ gives an\n$N$ × $G$ table"))
            changes.append({"kind": "line_wrap_only", "region": "C all-distinct table limit", "words_unchanged": True})
        if label == "F1" and "+ group indices / multiplicities" in text.get_text():
            text.set_text(text.get_text().replace("+ group indices / multiplicities", "+ group indices\n/ multiplicities"))
            changes.append({"kind": "line_wrap_only", "region": "B detail group metadata", "words_unchanged": True})

    # Recover space occupied by the removed overall title. Axis limits and
    # equal panel dimensions within each grid are preserved.
    if label == "F2":
        fig.subplots_adjust(top=.91)
    elif label == "S1":
        fig.subplots_adjust(top=.93)
    elif label == "F3":
        fig.subplots_adjust(top=.95, bottom=.205, hspace=.62)
    elif label == "S2":
        fig.subplots_adjust(top=.94)
    elif label in ["S3", "S4"]:
        fig.subplots_adjust(top=.88)
    elif label == "S5":
        fig.subplots_adjust(top=.80)

    identity.snapshot(fig, stem, BASE / "verification/identity_candidate_after")
    (BASE / "verification/production_changes").mkdir(exist_ok=True)
    (BASE / "verification/production_changes" / (label + ".json")).write_text(
        json.dumps({"figure": label, "changes": changes,
                    "minimum_base_font_pt": 7.2, "F1_math_base_pt": 10.2,
                    "nonzero_stroke_range_pt": [0.25, 0.9],
                    "data_or_scale_change": False}, indent=2) + "\n")
    return label, filename


def save_production(fig, stem):
    label, filename = format_figure(fig, stem)
    plt.rcParams["svg.hashsalt"] = "nbpearson-figure-production-v1"
    out = BASE / "figures_candidate"
    out.mkdir(exist_ok=True)
    paths = []
    for ext in ["pdf", "svg"]:
        p = out / (filename + "." + ext)
        metadata = {"Creator": "Deterministic saved-value production correction", "CreationDate": None,
                    "ModDate": None} if ext == "pdf" else {"Date": None}
        fig.savefig(p, format=ext, bbox_inches=None, pad_inches=0,
                    facecolor="white", metadata=metadata)
        paths.append(str(p))
    plt.close(fig)
    return paths

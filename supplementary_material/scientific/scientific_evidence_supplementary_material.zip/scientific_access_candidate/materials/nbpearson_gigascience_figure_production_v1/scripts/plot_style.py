"""Shared static figure style; does not import nbpearson or a numerical solver."""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PACKAGE = Path(__file__).resolve().parents[1]
ROOT = PACKAGE / "source_data"
OUT = PACKAGE / "production_render"
(OUT / "plot_data").mkdir(parents=True, exist_ok=True)
COLORS = {"interpolated": "#0072B2", "interpolated_grouped": "#D55E00",
          "exact_grouped": "#009E73", "scanpy": "#555555",
          "BPCells_FALSE": "#CC79A7", "BPCells_TRUE": "#7A6612"}
METHODS = list(COLORS)
LABELS = {"interpolated": "A: interpolated", "interpolated_grouped": "B: grouped interpolant",
          "exact_grouped": "C: exact grouped", "scanpy": "Scanpy",
          "BPCells_FALSE": "BPCells fast", "BPCells_TRUE": "BPCells slow"}
MARKERS = dict(zip(METHODS, ["o", "s", "^", "D", "v", "P"]))
TARGETS = ["pbmc_10k_common_small", "pbmc_10k_larger",
           "mouse_brain_nextgem_10k_common_small", "mouse_brain_nextgem_10k_larger"]
TARGET_LABELS = ["C1 · PBMC small\n1,000 × 1,000", "C2 · PBMC large\n9,999 × 2,000",
                 "C3 · Mouse small\n1,000 × 1,000", "C4 · Mouse large\n9,684 × 2,000"]


def setup():
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8,
        "axes.titlesize": 9, "axes.labelsize": 8, "xtick.labelsize": 7,
        "ytick.labelsize": 7, "legend.fontsize": 7, "axes.spines.top": False,
        "axes.spines.right": False, "axes.linewidth": 0.6, "lines.linewidth": 1,
        "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "path",
        "savefig.facecolor": "white", "figure.facecolor": "white"})


def save(fig, stem):
    from production_style import save_production
    return save_production(fig, stem)

"""Plot saved confirmatory fidelity scalars; never calculate a numerical reference."""
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import LogFormatterMathtext

from plot_style import ROOT, OUT, COLORS, METHODS, TARGETS, setup, save

ACCURACY = ROOT / "nbpearson_confirmatory_real_v1/real_accuracy_results.csv"
SUMMARY = ROOT / "nbpearson_publication_revision_v1/CONFIRMATORY_RESULTS_FOR_MANUSCRIPT.csv"
ACCURACY_SHA = "272355f7c1bbb98d176d6557f5002ff851978b0f8cb80c3ca1228771a12429fa"
SUMMARY_SHA = "56c1883773c2ec5a8805f99510a1af4dcabbee87aa9d11eba972b986836745b0"
SHORT_LABELS = ["A interpolated", "B grouped", "C exact grouped", "Scanpy", "BPCells fast", "BPCells slow"]
TARGET_MARKERS = dict(zip(TARGETS, ["o", "s", "^", "D"]))
TARGET_NAMES = ["C1 PBMC small", "C2 PBMC large", "C3 Mouse small", "C4 Mouse large"]
OFFSETS = dict(zip(TARGETS, [-0.24, -0.08, 0.08, 0.24]))
RELATIVE = [
    ("matrix_relative_error", "a  Matrix", 1e-6),
    ("matvec_relative_error", "b  Forward vector", 1e-6),
    ("rmatvec_relative_error", "c  Transpose vector", 1e-6),
    ("matmat8_relative_error", "d  Forward block (8)", 1e-6),
    ("rmatmat8_relative_error", "e  Transpose block (8)", 1e-6),
    ("triplet_relative_residual", "f  Retained PCA triplets", 1e-8),
    ("singular_relative_error", "g  Singular values", 1e-6),
    ("left_angle_radians", "h  Left subspace angle", 1e-6),
    ("right_angle_radians", "i  Right subspace angle", 1e-6),
]
ABSOLUTE = [
    ("matrix_absolute_error", "a  Matrix absolute error", "log"),
    ("reference_norm", "b  Reference Frobenius norm", "linear"),
    ("Av_residual_absolute", "c  Forward triplet residual", "log"),
    ("ATu_residual_absolute", "d  Transpose triplet residual", "log"),
]
FIELDS = [x[0] for x in RELATIVE] + [x[0] for x in ABSOLUTE]
MATRIX_FIELDS = {"matrix_relative_error", "matrix_absolute_error"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def export_csv(path, rows):
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def prepare():
    assert sha(ACCURACY) == ACCURACY_SHA, "Frozen accuracy table changed"
    assert sha(SUMMARY) == SUMMARY_SHA, "Frozen publication summary changed"
    accuracy, summary = load(ACCURACY), load(SUMMARY)
    assert len(accuracy) == 66 and len(summary) == 24
    assert len({r["pipeline_label"] for r in accuracy}) == 66
    indexed = defaultdict(list)
    for line, row in enumerate(accuracy, 2):
        row["_line"] = line
        indexed[(row["dataset"], row["method"])].append(row)
        assert row["subspace_status"] == "EVALUATED_WITH_GAP"
        assert row["reference_triplet_gate_status"] == "SATISFIED"
        assert row["matrix_status"] == "SATISFIED"
        assert all(row[f"{p}_status"] == "SATISFIED" for p in ("matvec", "rmatvec", "matmat8", "rmatmat8"))
    max_fields = {
        "matrix_absolute_error_max": "matrix_absolute_error",
        "matrix_relative_error_max": "matrix_relative_error",
        "triplet_relative_residual_max": "triplet_relative_residual",
        "Av_residual_absolute_max": "Av_residual_absolute",
        "ATu_residual_absolute_max": "ATu_residual_absolute",
        "singular_relative_error_max": "singular_relative_error",
        "left_angle_radians_max": "left_angle_radians",
        "right_angle_radians_max": "right_angle_radians",
    }
    checks = []
    for line, row in enumerate(summary, 2):
        selected = indexed.get((row["dataset"], row["method"]), [])
        assert len(selected) == int(row["completed_PCA_repetitions"])
        if not selected:
            assert row["method"] == "scanpy" and int(row["preflight_refusals"]) == 1
            continue
        for sf, field in max_fields.items():
            observed = max(float(r[field]) for r in selected)
            assert observed == float(row[sf]), (row["configuration_id"], sf)
            checks.append({"configuration_id": row["configuration_id"], "summary_csv_line": line,
                           "summary_field": sf, "summary_value": row[sf],
                           "source_field": field, "comparison": "saved maximum agrees"})
        product_max = max(float(r[f"{p}_relative_error"]) for r in selected
                          for p in ("matvec", "rmatvec", "matmat8", "rmatmat8"))
        assert product_max == float(row["saved_product_relative_error_max"])
        checks.append({"configuration_id": row["configuration_id"], "summary_csv_line": line,
                       "summary_field": "saved_product_relative_error_max",
                       "summary_value": row["saved_product_relative_error_max"],
                       "source_field": "four saved product relative-error fields",
                       "comparison": "saved maximum agrees"})
        assert len({r["reference_norm"] for r in selected}) == 1
        assert float(selected[0]["reference_norm"]) == float(row["matrix_reference_norm"])
    proofs = Counter()
    for row in accuracy:
        if row["method"].startswith("BPCells"):
            proof = json.loads(row["native_matrix_proof"])
            proofs[(proof["path"], proof["sha256"])] += 1
    assert len(proofs) == 8 and sorted(proofs.values()) == [3] * 8
    fast = [r for r in accuracy if r["method"] == "BPCells_FALSE"]
    assert len(fast) == 12
    assert all(r["triplet_status"] == "OUTSIDE_TOLERANCE" for r in fast)
    assert sum(r["angle_status"] == "OUTSIDE_TOLERANCE" for r in fast) == 9
    assert all(r["angle_status"] == "SATISFIED" for r in fast if r["dataset"] == TARGETS[3])
    points = []
    for row in sorted(accuracy, key=lambda r: (TARGETS.index(r["dataset"]), METHODS.index(r["method"]), int(r["repetition"]))):
        proof = json.loads(row["native_matrix_proof"]) if row["native_matrix_proof"] else {}
        for field in FIELDS:
            value = row[field]
            assert value != "" and float(value) >= 0
            plotted, reason = True, "one saved pipeline scalar; technical repetition"
            if field in MATRIX_FIELDS and row["method"].startswith("BPCells"):
                plotted = row["repetition"] == "1"
                reason = "one native R matrix proof per target/mode, reused across three pipelines"
            elif field == "reference_norm":
                plotted = row["repetition"] == "1"
                reason = "same saved target reference norm across repetitions; one point per configuration"
            repeated = not (field == "reference_norm" or (field in MATRIX_FIELDS and row["method"].startswith("BPCells")))
            plot_y = METHODS.index(row["method"]) + OFFSETS[row["dataset"]]
            plot_y += (int(row["repetition"]) - 2) * 0.025 if repeated else 0
            points.append({"dataset": row["dataset"], "method": row["method"],
                "repetition": row["repetition"], "pipeline_label": row["pipeline_label"],
                "source_file": ACCURACY.relative_to(ROOT).as_posix(),
                "source_file_sha256": ACCURACY_SHA, "source_csv_line": row["_line"],
                "source_field": field, "source_value": value, "plot_value": value,
                "display_transform": "x identity; y categorical target/repetition offsets only",
                "plot_y_categorical_offset": plot_y,
                "plotted": str(plotted), "selection_reason": reason,
                "native_matrix_proof_path": ("nbpearson_confirmatory_real_v1/" + proof["path"].split("nbpearson_confirmatory_real_v1/", 1)[1]) if proof.get("path") else "",
                "native_matrix_proof_sha256": proof.get("sha256", ""),
                "matrix_status": row["matrix_status"], "triplet_status": row["triplet_status"],
                "angle_status": row["angle_status"], "subspace_status": row["subspace_status"],
                "saved_product_scope": row["saved_products_scope"]})
    data_dir = OUT / "plot_data"
    data_dir.mkdir(exist_ok=True)
    export_csv(data_dir / "figure3_points.csv", points)
    nonexecutions = [{"configuration_id": r["configuration_id"], "dataset": r["dataset"],
        "method": r["method"], "source_file": SUMMARY.relative_to(ROOT).as_posix(),
        "source_file_sha256": sha(SUMMARY), "source_csv_line": i,
        "execution_status": r["execution_status"], "preflight_refusals": r["preflight_refusals"],
        "repetitions_not_launched": r["repetitions_not_launched"],
        "source_repetition_states_json": r["repetition_states_json"],
        "plot_treatment": "categorical annotation only; no invented error point"}
        for i, r in enumerate(summary, 2) if r["completed_PCA_repetitions"] == "0"]
    assert len(nonexecutions) == 2
    export_csv(data_dir / "figure3_nonexecutions.csv", nonexecutions)
    report = {"sources": [{"path": p.relative_to(ROOT).as_posix(), "sha256": sha(p)} for p in (ACCURACY, SUMMARY)],
        "plots": ["figure3_relative", "figure3_absolute"], "exported_scalar_rows": len(points),
        "selection": "All saved fields exported unchanged. Native R matrix/error duplicates suppressed to eight proof points; reference norm shown once per configuration.",
        "transforms": ["numeric parsing of saved binary64 decimal scalars for x coordinates", "y = method index + target offset (-0.24, -0.08, +0.08, +0.24); pipeline points add 0.025*(repetition-2), native R matrix and one-per-configuration norm points add zero", "no numeric-error transformation or unit conversion"],
        "plotted_points_by_field": dict(Counter(r["source_field"] for r in points if r["plotted"] == "True")),
        "zero_values": sum(float(r["source_value"]) == 0 for r in points),
        "R_matrix_unique_proofs": len(proofs), "R_matrix_pipeline_uses": sum(proofs.values()),
        "maxima_consistency_checks": checks, "reference_norm_configuration_checks": 22,
        "BPCells_fast_triplet_exceedances": 12, "BPCells_fast_angle_exceedances": 9,
        "BPCells_fast_C4_angle_passes": 3, "data_inconsistencies": [],
        "scope": "Saved scalar documentary comparisons only; no residual, product, PCA, solver, reference or benchmark executed."}
    (data_dir / "figure3_source_map.json").write_text(json.dumps(report, indent=2) + "\n")
    return points


def panel(ax, points, field, title, *, linear=False, threshold=None, labels=False):
    selected = [r for r in points if r["source_field"] == field and r["plotted"] == "True"]
    for row in selected:
        idx = METHODS.index(row["method"])
        repeated = not (field == "reference_norm" or (field in MATRIX_FIELDS and row["method"].startswith("BPCells")))
        jitter = (int(row["repetition"]) - 2) * 0.025 if repeated else 0
        y = idx + OFFSETS[row["dataset"]] + jitter
        value = float(row["plot_value"])
        if value == 0 and not linear:
            ax.text(0.02, y, "0 (exact)", transform=ax.get_yaxis_transform(), fontsize=7)
        else:
            ax.scatter(value, y, marker=TARGET_MARKERS[row["dataset"]], s=14,
                       color=COLORS[row["method"]], edgecolors="white", linewidths=0.25,
                       alpha=0.92, zorder=3)
    ax.set_title(title, loc="left", fontsize=8, pad=6)
    ax.set_ylim(5.5, -0.5)
    ax.set_yticks(range(6), SHORT_LABELS if labels else [""] * 6)
    ax.tick_params(axis="both", labelsize=7, width=0.5, length=2.5)
    ax.grid(axis="x", color="#dddddd", linewidth=0.4, zorder=0)
    if linear:
        ax.set_xlim(700, 5900)
        ax.set_xticks([1000, 3000, 5000])
    else:
        ax.set_xscale("log")
        if field in [r[0] for r in RELATIVE]:
            ax.set_xlim(5e-17, 1e-5)
            ax.set_xticks([1e-16, 1e-12, 1e-8, 1e-6])
        else:
            ax.set_xlim(5e-14, 1e-2)
            ax.set_xticks([1e-12, 1e-8, 1e-4])
        ax.xaxis.set_major_formatter(LogFormatterMathtext())
        ax.minorticks_off()
    if threshold is not None:
        ax.axvline(threshold, color="#333333", linestyle=(0, (3, 2)), linewidth=0.7, zorder=1)


def target_legend(fig, y):
    handles = [Line2D([], [], color="#333333", marker=TARGET_MARKERS[t], linestyle="None",
                      markersize=4, label=name) for t, name in zip(TARGETS, TARGET_NAMES)]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.57, y),
               frameon=False, ncol=2, columnspacing=1.4, handletextpad=0.4, fontsize=7)


def main():
    setup()
    points = prepare()
    fig, axes = plt.subplots(3, 3, figsize=(170 / 25.4, 192 / 25.4))
    fig.subplots_adjust(left=0.16, right=0.985, top=0.91, bottom=0.20, wspace=0.34, hspace=0.58)
    for i, (field, title, threshold) in enumerate(RELATIVE):
        ax = axes.flat[i]
        panel(ax, points, field, title, threshold=threshold, labels=i % 3 == 0)
        ax.set_xlabel("Angle (rad)" if field.endswith("radians") else "Relative error", fontsize=7.5)
    fig.suptitle("Numerical fidelity on four confirmatory targets", fontsize=10, y=0.975)
    target_legend(fig, 0.092)
    fig.text(0.04, 0.065, "Dashed: 10⁻⁶ for matrix/products/singular values and angles (rad); 10⁻⁸ for triplets.", fontsize=7)
    fig.text(0.04, 0.041, "Eight R matrix checks reused across 24 technical pipelines; no independent datasets implied.", fontsize=7)
    fig.text(0.04, 0.017, "Large Scanpy targets: preflight refusal, no error points. BPCells fast passes matrix/products.", fontsize=7)
    paths = save(fig, "figure3_relative")
    fig, axes = plt.subplots(2, 2, figsize=(170 / 25.4, 145 / 25.4))
    fig.subplots_adjust(left=0.16, right=0.985, top=0.88, bottom=0.23, wspace=0.30, hspace=0.60)
    for i, (field, title, scale) in enumerate(ABSOLUTE):
        ax = axes.flat[i]
        panel(ax, points, field, title, linear=scale == "linear", labels=i % 2 == 0)
        ax.set_xlabel("Saved Frobenius norm" if field == "reference_norm" else "Saved absolute error", fontsize=7.5)
    fig.suptitle("Absolute errors and target reference norms", fontsize=10, y=0.975)
    target_legend(fig, 0.085)
    fig.text(0.04, 0.058, "Untransformed saved norms/residuals; no universal absolute threshold is inferred.", fontsize=7)
    fig.text(0.04, 0.022, "Reference norms: one point per configuration. R matrix errors: one point per native check.", fontsize=7)
    paths += save(fig, "figure3_absolute")
    print(json.dumps({"figures": paths, "exported_scalar_rows": len(points), "scientific_computation": False}, indent=2))


if __name__ == "__main__":
    main()

"""Render historical development scalars from the frozen saved summary only.

No nbpearson import, matrix construction, numerical reference, PCA, timing run,
scientific summary calculation or smoothing is performed.
"""
import csv
import hashlib
import json

from plot_style import ROOT, OUT, COLORS, LABELS, MARKERS, setup, save
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import LogFormatterMathtext, FixedLocator, FuncFormatter


SOURCE = ROOT / "nbpearson_paper_evidence_rev3/comparison_summary.csv"
SOURCE_SHA = "0b3fde4bbef127fe9198ec6c249b8d5a423229faba741da431bcc6bbc27b494d"
ALIASES = {"bpcells_slow_false": "BPCells_FALSE", "bpcells_slow_true": "BPCells_TRUE"}
DATASETS = ["pbmc", "spatial_small", "spatial"]
DATASET_LABELS = ["PBMC\n2,700 × 2,000", "Spatial small\n2,000 × 1,775", "Spatial\n46,769 × 2,000"]
SHAPES = {"pbmc": ("2700", "2000"), "spatial_small": ("2000", "1775"), "spatial": ("46769", "2000")}
SESSIONS = ["PY_COMPARISON", "BP_LOCAL_031"]
SESSION_METHODS = {"PY_COMPARISON": ["interpolated", "interpolated_grouped", "exact_grouped", "scanpy"],
                   "BP_LOCAL_031": ["BPCells_FALSE", "BPCells_TRUE"]}
METHOD_OFFSETS = {"interpolated": -0.24, "interpolated_grouped": -0.08,
                  "exact_grouped": 0.08, "scanpy": 0.24,
                  "BPCells_FALSE": -0.10, "BPCells_TRUE": 0.10}
TIME_FIELDS = ["construction_pca_seconds_min", "construction_pca_seconds_median", "construction_pca_seconds_max"]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_literals(value):
    """Keep saved JSON numeric tokens for the provenance export."""
    return json.loads(value, parse_float=str, parse_int=str)


def prepare():
    assert digest(SOURCE) == SOURCE_SHA, "Frozen historical summary changed"
    rows = []
    with SOURCE.open(newline="") as handle:
        reader = csv.DictReader(handle)
        source_fields = list(reader.fieldnames)
        last_line = reader.line_num
        for record, row in enumerate(reader, 1):
            start, end = last_line + 1, reader.line_num
            last_line = end
            if not row["summary_id"].startswith(("S-PY_COMPARISON-", "S-BP_LOCAL_031-")):
                continue
            assert (row["N"], row["G"]) == SHAPES[row["dataset"]]
            assert row["matrix_tolerance"] == "1e-06"
            assert row["n_repetitions"] == "3"
            assert len(json.loads(row["source_ids_json"])) == 3
            raw_times = json_literals(row["construction_pca_seconds_individual_json"])
            assert len(raw_times) == 3 and all(float(v) > 0 for v in raw_times)
            assert all(row[f] and float(row[f]) > 0 for f in TIME_FIELDS + ["matrix_relative_error_max"])
            assert float(row[TIME_FIELDS[0]]) <= float(row[TIME_FIELDS[1]]) <= float(row[TIME_FIELDS[2]])
            row.update({"source_file": SOURCE.relative_to(ROOT).as_posix(),
                        "source_file_sha256": SOURCE_SHA,
                        "source_csv_record": record, "source_line_start": start,
                        "source_line_end": end,
                        "plot_method": ALIASES.get(row["method"], row["method"]),
                        "plot_stratum": "historical development; not later-real confirmatory"})
            rows.append(row)
    assert len(rows) == 16
    assert len([r for r in rows if r["session"] == SESSIONS[0]]) == 10
    assert len([r for r in rows if r["session"] == SESSIONS[1]]) == 6
    assert len({r["summary_id"] for r in rows}) == 16
    assert all(r["plot_method"] in SESSION_METHODS[r["session"]] for r in rows)
    fast = [r for r in rows if r["plot_method"] == "BPCells_FALSE"]
    assert len(fast) == 3 and all(r["n_precision_satisfied"] == "0" for r in fast)
    assert next(r for r in fast if r["dataset"] == "pbmc")["matrix_n_satisfied"] == "3"
    assert all(r["matrix_n_satisfied"] == "0" for r in fast if r["dataset"] != "pbmc")

    data_dir = OUT / "plot_data"
    data_dir.mkdir(exist_ok=True)
    with (data_dir / "historical_s1.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=source_fields + [
            "source_file", "source_file_sha256", "source_csv_record", "source_line_start",
            "source_line_end", "plot_method", "plot_stratum"])
        writer.writeheader()
        writer.writerows(rows)

    cells = []
    for row in rows:
        common = {"summary_id": row["summary_id"], "session": row["session"],
                  "dataset": row["dataset"], "method": row["method"],
                  "source_file": row["source_file"], "source_file_sha256": SOURCE_SHA,
                  "source_csv_record": row["source_csv_record"],
                  "source_line_start": row["source_line_start"], "source_line_end": row["source_line_end"]}
        for field in ["matrix_relative_error_max"] + TIME_FIELDS:
            cells.append(dict(common, source_field=field, source_json_index=None,
                              source_value_literal=row[field], source_ids_json=row["source_ids_json"],
                              unit="dimensionless" if field.startswith("matrix_") else "seconds",
                              plotted_as="maximum over saved matrix errors" if field.startswith("matrix_")
                              else "saved timing " + field.rsplit("_", 1)[1],
                              transformation="identity; numeric parsing for plotting only"))
        ids = json.loads(row["source_ids_json"])
        for index, literal in enumerate(json_literals(row["construction_pca_seconds_individual_json"])):
            cells.append(dict(common, source_field="construction_pca_seconds_individual_json",
                              source_json_index=index, source_value_literal=literal,
                              original_record_id=ids[index], unit="seconds", plotted_as="saved technical timing repetition",
                              transformation="identity; categorical x offset only"))
    assert len(cells) == 112
    report = {
        "source": {"path": SOURCE.relative_to(ROOT).as_posix(), "sha256": SOURCE_SHA},
        "selection": "Exactly summary_id prefixes S-PY_COMPARISON- and S-BP_LOCAL_031-; 16 saved summaries",
        "data_export": "historical_s1.csv copies all original selected field strings, including literal JSON, scopes and source IDs; appended provenance fields only",
        "exported_summary_records": 16, "plotted_scalar_cells": cells,
        "summary_use": "Use saved matrix_relative_error_max and construction_pca_seconds median/min/max; do not recalculate scientific summaries or sum phase medians",
        "axis_units": {"matrix": "dimensionless relative error; log scale", "timing": "seconds; log scale", "N": "observations/barcodes; spatial rows are bins", "G": "features"},
        "measurement_scopes": [{"summary_id": r["summary_id"], "session": r["session"],
            "time_scope": r["time_scope"], "rss_scope": r["rss_scope"], "solver": r["solver"],
            "initialization": r["initialization"], "comparability_scope": r["comparability_scope"],
            "source_ids_json": r["source_ids_json"], "historical_summary_source_json": r["historical_summary_source_json"]}
            for r in rows],
        "missing_configurations": [{"session": "PY_COMPARISON", "dataset": ds, "method": "scanpy",
            "treatment": "No selected saved pipeline summary; omitted, never encoded as a zero"}
            for ds in ["pbmc", "spatial"]],
        "boundaries": ["Historical development stratum only; not pooled with later-real confirmatory or synthetic stress evidence",
            "Python and native R sessions/solvers/starts and timing/RSS/product boundaries differ; no cross-session speed ratio, ranking or equivalence claim",
            "Timing is constructor plus PCA, not end-to-end process or export/reference verification time",
            "Matrix maxima represent one saved summary per configuration, not independent biological observations",
            "Three individual times are technical repetitions; saved medians/minima/maxima are descriptive, not confidence intervals"],
        "source_field_identity_checks": "Frozen hash and 16 selected records checked; every original field string preserved in exported CSV",
        "data_inconsistencies": [],
        "execution_scope": "Static rendering and source-value checks only; no numerical core, benchmark, residual/product/reference or PCA execution"
    }
    (data_dir / "historical_s1_source_map.json").write_text(json.dumps(report, indent=2) + "\n")
    return rows


def common_axis(ax, *, bottom=False):
    ax.set_xlim(-0.50, 2.50)
    ax.set_xticks(range(3), DATASET_LABELS if bottom else ["PBMC", "Spatial small", "Spatial"])
    ax.tick_params(axis="both", labelsize=7, width=0.5, length=2.5)
    ax.set_yscale("log")
    ax.minorticks_off()
    ax.grid(axis="y", color="#dddddd", linewidth=0.4, zorder=0)


def plot_matrix(ax, selected):
    for row in selected:
        method = row["plot_method"]
        x = DATASETS.index(row["dataset"]) + METHOD_OFFSETS[method]
        ax.scatter(x, float(row["matrix_relative_error_max"]), color=COLORS[method],
                   marker=MARKERS[method], s=22, linewidths=0.4, edgecolors="white", zorder=3)
    common_axis(ax)
    ax.set_ylim(5e-17, 1e-5)
    ax.set_yticks([1e-16, 1e-12, 1e-8, 1e-6])
    ax.yaxis.set_major_formatter(LogFormatterMathtext())
    ax.axhline(1e-6, color="#333333", linestyle=(0, (3, 2)), linewidth=0.7, zorder=1)


def plot_time(ax, selected, *, native):
    for row in selected:
        method = row["plot_method"]
        x = DATASETS.index(row["dataset"]) + METHOD_OFFSETS[method]
        low, median, high = [float(row[field]) for field in TIME_FIELDS]
        ax.vlines(x, low, high, color=COLORS[method], linewidth=1, zorder=2)
        ax.hlines([low, high], x - 0.026, x + 0.026, color=COLORS[method], linewidth=0.7, zorder=2)
        for j, value in enumerate(json_literals(row["construction_pca_seconds_individual_json"])):
            ax.scatter(x + (j - 1) * 0.022, float(value), color=COLORS[method],
                       marker=".", s=11, zorder=3)
        ax.scatter(x, median, marker=MARKERS[method], s=25, facecolors="white",
                   edgecolors=COLORS[method], linewidths=0.8, zorder=4)
    common_axis(ax, bottom=True)
    ax.set_ylim((0.20, 120) if native else (0.04, 2))
    ticks = [0.3, 1, 3, 10, 30, 100] if native else [0.05, 0.1, 0.3, 1]
    ax.yaxis.set_major_locator(FixedLocator(ticks))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, position: f"{value:g}"))


def main():
    setup()
    rows = prepare()
    fig, axes = plt.subplots(2, 2, figsize=(168 / 25.4, 178 / 25.4))
    fig.subplots_adjust(left=0.14, right=0.985, bottom=0.19, top=0.79, wspace=0.32, hspace=0.40)
    for column, session in enumerate(SESSIONS):
        selected = [r for r in rows if r["session"] == session]
        plot_matrix(axes[0, column], selected)
        plot_time(axes[1, column], selected, native=column == 1)
    axes[0, 0].set_title("a  Historical Python session", loc="left", fontsize=8)
    axes[0, 1].set_title("b  Historical native R session", loc="left", fontsize=8)
    axes[1, 0].set_title("c  Python construction + PCA", loc="left", fontsize=8)
    axes[1, 1].set_title("d  R construction + PCA", loc="left", fontsize=8)
    axes[0, 0].set_ylabel("Maximum matrix relative error", fontsize=8)
    axes[1, 0].set_ylabel("Construction + PCA (s)", fontsize=8)
    axes[0, 1].set_ylabel("Relative error", fontsize=8)
    axes[1, 1].set_ylabel("Time (s)", fontsize=8)
    fig.suptitle("Historical development evidence", fontsize=10, y=0.97)
    fig.text(0.5, 0.928, "Separate sessions; descriptive saved results", ha="center", fontsize=8)
    methods = SESSION_METHODS[SESSIONS[0]] + SESSION_METHODS[SESSIONS[1]]
    legend = [Line2D([], [], color=COLORS[m], marker=MARKERS[m], linestyle="None",
                     markersize=4, label=LABELS[m]) for m in methods]
    fig.legend(handles=legend, loc="upper center", bbox_to_anchor=(0.52, 0.90),
               ncol=3, frameon=False, columnspacing=1.1, handletextpad=0.3, fontsize=7)
    fig.text(0.50, 0.108, "Dashed line: matrix criterion 10⁻⁶. Timing dots: three saved repetitions.",
             ha="center", fontsize=7)
    fig.text(0.50, 0.077, "Open symbol: saved median; whisker: saved min–max. Timing axes differ.",
             ha="center", fontsize=7)
    fig.text(0.50, 0.041, "Different solvers, starts and measurement boundaries; no cross-session speed ratios.",
             ha="center", fontsize=7)
    paths = save(fig, "figureS1_historical_development")
    print(json.dumps({"figure": "S1", "saved_summary_records": len(rows),
                      "outputs": paths, "source_sha256": SOURCE_SHA,
                      "scientific_computation": "NONE"}))


if __name__ == "__main__":
    main()

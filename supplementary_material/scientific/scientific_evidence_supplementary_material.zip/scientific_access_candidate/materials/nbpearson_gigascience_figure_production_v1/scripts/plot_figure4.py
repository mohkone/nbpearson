"""Plot the saved 27-pipeline synthetic mechanism stress, without rerunning it."""
import csv
import hashlib
import json
from statistics import median

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator

from plot_style import ROOT, OUT, COLORS, MARKERS, setup, save

SUMMARY = "nbpearson_confirmatory_v1/depth_diversity_results.csv"
PERF = "nbpearson_confirmatory_v1/performance_results.csv"
ACCURACY = "nbpearson_confirmatory_v1/accuracy_results.csv"
DATASETS = ["stress_U16", "stress_U256", "stress_U2048"]
METHODS = ["interpolated", "interpolated_grouped", "exact_grouped"]
LABELS = ["A: interpolated", "B: grouped interpolant", "C: exact grouped"]
PRODUCTS = ["matvec", "rmatvec", "matmat8", "rmatmat8"]
PRODUCT_LABELS = ["Vector product", "Transposed vector", "Width-eight block", "Transposed width-eight"]
FIELDS = ["plot_part", "panel", "dataset", "method", "record_type", "repetition", "metric",
          "raw_value", "raw_unit", "display_value", "display_unit", "display_transform",
          "source_path", "source_sha256", "source_record_index", "source_key", "source_field"]


def read(path):
    with (ROOT / path).open(newline="") as handle:
        return list(csv.DictReader(handle))


def main():
    setup()
    plt.rcParams.update({"xtick.labelsize": 7.2, "ytick.labelsize": 7.2, "legend.fontsize": 7.2})
    srows, prows, arows = read(SUMMARY), read(PERF), read(ACCURACY)
    hashes = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in [SUMMARY, PERF, ACCURACY]}
    si = {(r["dataset"], r["method"]): (i + 1, r) for i, r in enumerate(srows)}
    pi = {(r["dataset"], r["method"], int(r["repetition"])): (i + 1, r) for i, r in enumerate(prows) if r["dataset"] in DATASETS}
    ai = {(r["dataset"], r["method"], int(r["repetition"])): (i + 1, r) for i, r in enumerate(arows) if r["dataset"] in DATASETS}
    assert len(si) == 9 and len(pi) == len(ai) == 27 and pi.keys() == ai.keys()
    records = []

    def add(part, panel, dataset, method, role, rep, field, row, source, index, scale=1.0, unit="relative", display_unit="relative"):
        raw = row[field]; value = float(raw) * scale
        transform = "identity" if scale == 1 else ("bytes / 2**20" if scale == 1 / 2**20 else "seconds * 1000")
        key = "|".join([dataset, method] + ([str(rep)] if rep != "" else []))
        records.append(dict(zip(FIELDS, [part, panel, dataset, method, role, rep, field, raw, unit,
            format(value, ".17g"), display_unit, transform, source, hashes[source], index, key, field])))
        return value

    # Exact saved-scalar cross-checks only; scientific errors/products are not recalculated.
    for (dataset, method), (_, s) in si.items():
        assert s["N"] == "2048" and s["G"] == "512" and s["nnz"] == "81920"
        assert s["U_d"] == dataset.split("_U")[1]
        assert s["nodes"] == ("" if method == "exact_grouped" else "16")
        assert s["repetitions_completed"] == "3" and s["all_observed_criteria_satisfied"] == "True"
        ps = [pi[dataset, method, rep][1] for rep in [1, 2, 3]]
        aas = [ai[dataset, method, rep][1] for rep in [1, 2, 3]]
        source_order = [p for p in prows if p["dataset"] == dataset and p["method"] == method]
        assert [float(p["construction_pca_seconds"]) for p in source_order] == json.loads(s["construction_pca_individual_seconds"])
        assert float(s["construction_pca_median_seconds"]) == median(float(p["construction_pca_seconds"]) for p in ps)
        assert float(s["construction_pca_min_seconds"]) == min(float(p["construction_pca_seconds"]) for p in ps)
        assert float(s["construction_pca_max_seconds"]) == max(float(p["construction_pca_seconds"]) for p in ps)
        assert all(p["operator_storage_bytes"] == s["operator_storage_bytes"] for p in ps)
        for product in PRODUCTS:
            assert float(s[product + "_median_seconds_per_call"]) == median(float(p[product + "_seconds_per_call"]) for p in ps)
        for field in ["matrix_relative_error", "triplet_relative_residual"]:
            assert float(s[field + "_max"]) == max(float(a[field]) for a in aas)
        assert all(a["overall_status"] == "SATISFIED_ALL_OBSERVED_CRITERIA" for a in aas)

    def base(ax):
        ax.set_xticks(range(3), ["16", "256", "2048"])
        ax.set_xlabel("Distinct depths, U", fontsize=7.5)
        ax.set_xlim(-.48, 2.48)
        ax.grid(axis="y", color="#dddddd", linewidth=.35, zorder=0)

    fig, axes = plt.subplots(2, 2, figsize=(170 / 25.4, 151 / 25.4))
    fig.subplots_adjust(left=.105, right=.985, top=.88, bottom=.16, hspace=.55, wspace=.30)
    for ax in axes.flat: base(ax)
    panels = [(axes[0, 0], "storage", "a  Permanent operator arrays", "Operator arrays (MiB)"),
              (axes[0, 1], "pipeline", "b  Construction + PCA", "Duration (ms)"),
              (axes[1, 0], "matrix", "c  Observed matrix fidelity", "Relative matrix error"),
              (axes[1, 1], "triplet", "d  Observed triplet fidelity", "Relative triplet residual")]
    for ax, _, title, ylabel in panels:
        ax.set_title(title, fontsize=8, loc="left", pad=7); ax.set_ylabel(ylabel, fontsize=7.5)
    axes[0, 0].set_ylim(0, 10)
    axes[0, 0].text(.02, .96, "At U = N: B 1,372,292 bytes\nA 1,323,012 bytes", transform=axes[0, 0].transAxes, fontsize=7.2, va="top")
    axes[0, 1].set_ylim(45, 220)
    for ax, threshold in [(axes[1, 0], 1e-6), (axes[1, 1], 1e-8)]:
        ax.set_yscale("log"); ax.set_ylim(1e-17 if threshold == 1e-6 else 1e-16, threshold * 10)
        ax.axhline(threshold, color="#555555", linestyle=(0, (3, 2)), linewidth=.7)
        ax.text(.98, .985, "criterion " + ("10⁻⁶" if threshold == 1e-6 else "10⁻⁸"), transform=ax.transAxes, ha="right", va="top", fontsize=7.2, color="#555555")
    for x, dataset in enumerate(DATASETS):
        for mi, method in enumerate(METHODS):
            source_index, s = si[dataset, method]; xx = x + (mi - 1) * .20; color, marker = COLORS[method], MARKERS[method]
            for field in ["N", "G", "nnz", "U_d", "U_d_over_N"]:
                add("figure4_overview", "configuration", dataset, method, "saved_metadata", "", field, s,
                    SUMMARY, source_index, unit="count" if field != "U_d_over_N" else "ratio",
                    display_unit="count" if field != "U_d_over_N" else "ratio")
            if s["nodes"]:
                add("figure4_overview", "configuration", dataset, method, "saved_metadata", "", "nodes", s,
                    SUMMARY, source_index, unit="nodes", display_unit="nodes")
            value = add("figure4_overview", "storage", dataset, method, "configuration_total", "", "operator_storage_bytes", s, SUMMARY, source_index, 1 / 2**20, "bytes", "MiB")
            axes[0, 0].scatter(xx, value, s=35, color=color, marker=marker, edgecolors="black", linewidths=.4, zorder=3)
            for rep in [1, 2, 3]:
                p_index, p = pi[dataset, method, rep]; a_index, a = ai[dataset, method, rep]; jitter = (rep - 2) * .038
                value = add("figure4_overview", "pipeline", dataset, method, "technical_repetition", rep, "construction_pca_seconds", p, PERF, p_index, 1000, "s", "ms")
                axes[0, 1].scatter(xx + jitter, value, s=13, color=color, marker=marker, alpha=.6, linewidths=.35)
                for ax, panel, field in [(axes[1, 0], "matrix", "matrix_relative_error"), (axes[1, 1], "triplet", "triplet_relative_residual")]:
                    value = add("figure4_overview", panel, dataset, method, "technical_repetition", rep, field, a, ACCURACY, a_index)
                    assert value > 0; ax.scatter(xx + jitter, value, s=13, color=color, marker=marker, alpha=.6, linewidths=.35)
            low, high = [add("figure4_overview", "pipeline", dataset, method, role, "", field, s, SUMMARY, source_index, 1000, "s", "ms") for role, field in [("saved_min", "construction_pca_min_seconds"), ("saved_max", "construction_pca_max_seconds")]]
            med = add("figure4_overview", "pipeline", dataset, method, "saved_median", "", "construction_pca_median_seconds", s, SUMMARY, source_index, 1000, "s", "ms")
            axes[0, 1].plot([xx, xx], [low, high], color=color, linewidth=.7, zorder=1)
            axes[0, 1].scatter(xx, med, s=35, color=color, marker=marker, edgecolors="black", linewidths=.4, zorder=3)
            for ax, panel, field in [(axes[1, 0], "matrix", "matrix_relative_error_max"), (axes[1, 1], "triplet", "triplet_relative_residual_max")]:
                value = add("figure4_overview", panel, dataset, method, "saved_max", "", field, s, SUMMARY, source_index)
                ax.scatter(xx, value, s=35, color=color, marker=marker, edgecolors="black", linewidths=.4, zorder=3)
    handles = [Line2D([], [], color=COLORS[m], marker=MARKERS[m], linestyle="none", markersize=5, label=l) for m, l in zip(METHODS, LABELS)]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.53, .045), ncol=3, frameon=False)
    fig.suptitle("Existing synthetic depth-diversity stress", fontsize=10, y=.99)
    fig.text(.105, .925, "N = 2048, G = 512; U/N = 0.0078125, 0.125, 1. Technical repetitions only.", fontsize=7.2)
    fig.text(.105, .02, "Small marks: saved repetitions. Large marks: saved time median or error maximum; no connecting curves.", fontsize=7)
    save(fig, "figure4_overview")

    fig, axes = plt.subplots(2, 2, figsize=(170 / 25.4, 145 / 25.4))
    fig.subplots_adjust(left=.105, right=.985, top=.88, bottom=.17, hspace=.53, wspace=.30)
    for ax, product, label in zip(axes.flat, PRODUCTS, PRODUCT_LABELS):
        base(ax); ax.set_title(chr(97 + PRODUCTS.index(product)) + "  " + label, fontsize=8, loc="left", pad=7)
        ax.set_ylabel("Time per call (ms)", fontsize=7.5)
        for x, dataset in enumerate(DATASETS):
            for mi, method in enumerate(METHODS):
                index, s = si[dataset, method]; xx = x + (mi - 1) * .20
                for rep in [1, 2, 3]:
                    p_index, p = pi[dataset, method, rep]
                    value = add("figure4_products", product, dataset, method, "technical_repetition", rep, product + "_seconds_per_call", p, PERF, p_index, 1000, "s", "ms")
                    ax.scatter(xx + (rep - 2) * .038, value, s=13, color=COLORS[method], marker=MARKERS[method], alpha=.6, linewidths=.35)
                value = add("figure4_products", product, dataset, method, "saved_median", "", product + "_median_seconds_per_call", s, SUMMARY, index, 1000, "s", "ms")
                ax.scatter(xx, value, s=35, color=COLORS[method], marker=MARKERS[method], edgecolors="black", linewidths=.4, zorder=3)
        ax.set_ylim(bottom=0); ax.yaxis.set_major_locator(MaxNLocator(4))
        if product == "rmatmat8":
            ax.text(.02, .96, "B costs more than A at all three U", transform=ax.transAxes, va="top", fontsize=7.2)
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.53, .05), ncol=3, frameon=False)
    fig.suptitle("Existing synthetic stress: all four fixed products", fontsize=10, y=.99)
    fig.text(.105, .925, "Small marks: saved process means of ten calls. Large marks: saved median of three process means.", fontsize=7)
    fig.text(.105, .02, "Discrete depth-diversity categories; no smoothing, intermediate samples, speed ratios or cross-campaign pooling.", fontsize=7)
    save(fig, "figure4_products")

    for part in ["figure4_overview", "figure4_products"]:
        with (OUT / "plot_data" / (part + ".csv")).open("w", newline="") as handle:
            writer = csv.DictWriter(handle, FIELDS); writer.writeheader(); writer.writerows(r for r in records if r["plot_part"] == part)
    mapping = {"sources": [{"path": p, "sha256": h} for p, h in hashes.items()],
        "source_record_index_definition": "1-based CSV data-record index, excluding header",
        "selected_datasets": DATASETS, "selected_methods": METHODS, "pipelines": 27,
        "key": "dataset|method|repetition; original trace/product_individual_csv links retained in source CSV",
        "display_conversions": ["bytes / 2**20 = MiB", "seconds * 1000 = ms"],
        "repetition_display": "Categorical x positions; method offsets -0.20, 0, +0.20 and repetition offsets -0.038, 0, +0.038; measured y values unchanged",
        "summary_display": "Saved configuration totals, saved time/product medians, saved time min/max and saved error maxima; no recalculated errors or timings",
        "individual_array_order": "Saved summary time arrays follow source performance-CSV row order, not necessarily repetition number. Plotted repetitions use explicit dataset/method/repetition keys from raw rows.",
        "validation": "All nine saved summary rows and 27 matched performance/accuracy rows agree in storage, time/product medians, time ranges and error maxima; all 27 saved statuses satisfied",
        "exported_rows": len(records), "new_scientific_computations": [], "smoothing": False,
        "stratum": "Original synthetic mechanism campaign, separate from historical development and later real data",
        "limits": "Depth diversity is not the sole varying property; margins, clipping, spectra and solver work also differ. No causal attribution or biological inference."}
    (OUT / "plot_data/figure4_source_map.json").write_text(json.dumps(mapping, indent=2) + "\n")
    print(json.dumps({"figure4_export_rows": len(records), "source_consistency": "PASS", "rendered": ["figure4_overview", "figure4_products"]}))


if __name__ == "__main__":
    main()

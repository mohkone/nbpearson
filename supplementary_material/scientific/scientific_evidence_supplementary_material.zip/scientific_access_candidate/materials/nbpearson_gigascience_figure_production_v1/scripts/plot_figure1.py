"""Vector architecture diagram from saved definitions; no numerical execution."""
import hashlib
import json
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import matplotlib.pyplot as plt
from plot_style import ROOT, OUT, setup, save, COLORS

setup()
fig, ax = plt.subplots(figsize=(168.8 / 25.4, 166 / 25.4))
fig.subplots_adjust(left=0.01, right=0.99, bottom=0.01, top=0.99)
ax.set(xlim=(0, 1), ylim=(0, 1))
ax.axis("off")


def box(x, y, w, h, text, color="#F3F5F7", edge="#69727A", size=8.5):
    patch = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.009,rounding_size=0.01",
                          facecolor=color, edgecolor=edge, linewidth=0.8)
    ax.add_patch(patch)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=size,
            linespacing=1.45)


def arrow(x1, y1, x2, y2, dashed=False):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                 mutation_scale=10, color="#48525B", linewidth=0.9,
                 linestyle="--" if dashed else "-"))


box(.025, .845, .28, .105, "Sparse integer counts\n$X$: observations × genes")
box(.36, .845, .28, .105, "Fixed or derived margins\n$n$, $p$; scalar $\u03b8$ and clip $c$")
box(.70, .825, .275, .145, "Explicit user choice\nResource admission estimate\nAnalytic selection diagnostic", size=8)
arrow(.165, .84, .22, .765)
arrow(.50, .84, .50, .765)
arrow(.835, .82, .835, .765, dashed=True)
box(.035, .615, .93, .145,
    "Shared target: clip residuals before gene-wise centering\n"
    "Sparse correction $C=S+D$; anchored background; $H$ centers columns\n"
    "No parameter fitting, observation aggregation or gene standardization", size=8.5)

positions = [.025, .36, .695]
titles = ["A · interpolated", "B · grouped interpolant", "C · exact grouped"]
equations = [r"$HC+W_NF^\top$", r"$HC+PW_dF^\top$", r"$HC+PK_c$"]
details = ["Background: $N$ × $r$\nand $G$ × $r$ factors",
           "Background: $U_d$ × $r$\nand $G$ × $r$ factors\n+ group indices / multiplicities",
           "Background: $U_d$ × $G$ table\n+ group information\n$U_d=N$ gives an $N$ × $G$ table"]
for x, title, equation, detail, method in zip(positions, titles, equations, details,
                                           ["interpolated", "interpolated_grouped", "exact_grouped"]):
    box(x, .305, .28, .245, "", color="#FFFFFF", edge=COLORS[method])
    ax.text(x + .14, .515, title, ha="center", va="center", fontsize=8.3,
            color=COLORS[method], fontweight="bold")
    ax.text(x + .14, .465, equation, ha="center", va="center", fontsize=11)
    ax.text(x + .14, .375, detail, ha="center", va="center", fontsize=8.1, linespacing=1.4)
    arrow(x + .14, .61, x + .14, .555)
    arrow(x + .14, .30, .45, .245)

box(.025, .12, .60, .12, "Real LinearOperator: four products\nmatvec · rmatvec · matmat · rmatmat", size=8.7)
box(.73, .12, .245, .12, "External SVD solver\nSeparate tolerance\nand convergence", color="#FFF8E8", size=8.2)
arrow(.635, .18, .72, .18)
ax.text(.5, .075, r"Exactly equal binary64 depths; $P^\top$ sums within groups; weighted centering",
        ha="center", fontsize=7.5)
ax.text(.5, .040, r"$r$: interpolation nodes, distinct from PCA dimension; C has no interpolation error",
        ha="center", fontsize=7.5)
ax.text(.5, .008, "Analytic selection ≠ floating-point certificate; construction: NOT_EVALUATED",
        ha="center", fontsize=7.5)
save(fig, "figure1_operator_architecture")

sources = ["nbpearson_manuscript_v3/MANUSCRIPT_V3.md",
           "nbpearson_manuscript_v3/TECHNICAL_SUPPLEMENT_V3.md", "nb_pca_package_dev1/README.md"]
mapping = {"figure": "figure1_operator_architecture", "evidence_type": "Descriptive schematic only; no measured ordinate",
    "sources": [{"path": name, "sha256": hashlib.sha256((ROOT / name).read_bytes()).hexdigest()} for name in sources],
    "label_sources": {"fixed_target_and_clip_order": "Manuscript sections2.1–2.2 / supplementS1",
        "three_representations_and_storage": "Manuscript section2.3 Table1 / supplementS2",
        "group_sum_and_weighted_centering": "Manuscript section2.3 / supplementS1–S2",
        "four_products_external_solver_and_diagnostics": "Manuscript section3 / supplementS4 / dev1 README"},
    "limits": "Background dimensions exclude sparse correction, means, input arrays, construction/product temporaries and solver memory; cached exact means no interpolation, not exact floating arithmetic"}
(OUT / "plot_data/figure1_source_map.json").write_text(json.dumps(mapping, indent=2) + "\n")

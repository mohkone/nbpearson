# Confirmatory protocol V1 — frozen before numerical execution

## Status and scope
Frozen on the UTC timestamp in EXPERIMENT_MANIFEST.json, before generation,
qualification, or timing of the new numerical inputs. This protocol tests
nbpearson 0.1.0.dev1 unchanged, loaded from the already-installed copy whose
five sources match the evaluated wheel. No tuning, replacement core, package
installation, or publication. Documentary source qualification precedes this
freeze; it produced DATA HOLD for both independent resources. That result
does not authorize substitute data. Synthetic outcomes cannot lift these holds.

## Admission and sources
Only the two user-specified official 10x resources may supply independent data.
Require an official exact unnormalized integer-count output/version, advertised
or HTTP byte size, bounded transfer receipt and SHA-256 before numerical use.
No established in-project count copy has been identified; no outside-project
search. Acquisition limit: one attempt per admitted official artifact, 128 MiB
maximum, 60 s, no retries or proxy/TLS changes. Unknown size/version or failed
access means DATA HOLD, not a measured algorithm failure. Do not download raw
barcode matrices of unknown size. Vendor barcode filtering is documented if a
filtered integer-count output is admitted; normalized/corrected counts are excluded.

## Prospective real-data preparation (not yet executed)
Validate schema, nonnegative finite integer values, feature types, and unique
IDs. Select Gene Expression features if explicitly typed; missing types require
a documented source contract. Order observations by SHA256 of UTF-8
NBPEARSON-CONFIRMATORY-V1| plus exact barcode, tie by exact ID.
Two predetermined targets per source: first min(1000,available) observations,
first 1000 positive genes by stable ID; and first min(10000,available)
observations, first 2000 positive genes by stable ID. Identify positivity on
that target's selected observations, not using variance or performance.
Remove only zero rows/columns after selection, preserve excluded indices,
never replace excluded observations. Do not silently reduce sizes if a method
fails. Each target has its own margins and axes, shared identically across arms.
N>=100 and min(N,G)>=64 required for this solver contract; otherwise NOT_ADMITTED.
Cells/nuclei from a single resource and nested sizes are not independent cohorts.

Calculate binary64 n_i=sum_j X_ij; t_j=sum_i X_ij; M=sum_j t_j; p_j=t_j/M once.
Freeze counts, axes, n,p and SHA-256 before each target's evaluation.
Scanpy's official recalculation must agree on this universe; record numerical
differences without substituting a different target.

## Target, arms and solvers
theta=100 finite, c=sqrt(N)>=sqrt(theta); clip BEFORE gene centering, no scaling.
mu=n*p, variance mu+mu^2/theta, no Poisson/scaled-NB or gene-specific dispersion.
Arms for admitted real targets: interpolated, interpolated_grouped, exact_grouped,
official Scanpy Pearson-residual PCA, BPCells slow=FALSE and slow=TRUE.
NB interpolation: matrix_rtol=1e-6, max_nodes=128, same original N in bound,
16 first disjoint adjacent pairs. All package refusals remain active, no fallback.

nbpearson/direct reference: scipy svds ARPACK k=21, retain20, ncv64, tol1e-10,
maxiter10000, Gaussian v0 seed6619. Scanpy: official normalization/PCA with
theta/clip explicit, mask_var=None, float64, zero_center=True, ARPACK,
random_state6619, native sklearn tol0 and initial vector; record signatures.
BPCells0.3.1: native Spectra k=nu=nv=21,ncv64,tol1e-10,maxitr10000,
set.seed6619,threads1; no claim of identical initialization to Python.
BPCells receives gene_beta=p linear,cell_read_counts=n,gene_theta=100,
columns_are_cells=TRUE,min_var=0; native explicit gene centering via product
then add_rows; no SCTransform fitting. Native fast/slow remain distinct.

## Separately labelled synthetic mechanism experiment
Exactly three matrices N=2048,G=512,40 positive counts per row;
requested unique depths U={16,256,2048}. d[u]=2000+floor(u*18000/(U-1)).
Assign arange(N)%U, then permute using seed71302. All groups represented.
Same supports across U: reset support RNG71303, include i%G plus39 distinct
other columns sampled without replacement; sort indices. Assign one count to
each support, distribute n_i-40 by uniform Multinomial with RNG71304.
Build CSR directly. These are computational loads, not biological simulations
or independent biological evidence; no seed is selected after timing.
Verify actual depths/nnz/positivity/integrality, save sparse artifacts and margins.
Only the three nbpearson representations are stress arms (27 planned pipelines).
Three direct-block SVD references, one per input, are evaluation-only, not speed baselines.
No selection dispatcher or retrospective U/N threshold.
Report N,G,nnz,density/sparsity,U,U/N,multiplicities,nodes,storage and cost.

## Qualification before campaign
First use a separate deterministic synthetic fixture128x64,4 distinct support
positions per row, positive integer values RNG71301 in[1,70), with its own
frozen margins. One run and separate direct verification per Python arm,
including Scanpy if memory-admitted. One tiny native qualification per BPCells
mode against independent dense formula (only8192 entries). Check logging,
orientation, margin roundtrip, centering, products and adjoint.
Run existing standalone Decimal80/160 tiny quasi-null/L=0 checks unchanged;
these are harness qualification, not new confirmatory real datasets.
Numerical native approximation failure is retained; it is not automatically
a mapping defect. Do not tune thresholds. A harness error may be corrected
only before campaign, preserving the failed script/result and amendment.
Any numerical core defect stops that arm; no core correction in V1.

## Accuracy and precision criteria
Real/stress oracle: direct binary64 residuals in256-row blocks, mean accumulation
with compensation/fsum, then second-pass centered squared norms; no global dense
residual matrix. This is a floating reference, not real-arithmetic truth.
Matrix and four product relative errors<=1e-6; report absolute error and norm.
Exactly zero reference: relative undefined, absolute criterion1e-12 (named
separately, not a silent mixed tolerance). No denominator epsilon.
Decimal80/160 on tiny fixture only, agreement1e-60, original relative criterion.
Adjoint and centering diagnostics use direct norm; threshold1e-6.
SVD: both ||Av-sigma*u|| and ||A^T*u-sigma*v||, aggregated relative residual
<=1e-8, singular relative error<=1e-6, max subspace angle<=1e-6rad only when
reference gap20/21 >2*matrix_abs_error+max(triplet_absolute_residuals).
Otherwise label NOT_INTERPRETABLE_GAP, not PASS. Orthogonality is reported.
Absent converged direct reference: singular/subspace NOT_EVALUATED, not inferred
from convergence. Direct reference is a fresh streamed ARPACK computation, no
historical reference is reused on new counts. Selection bound in exact arithmetic,
floating validation, SVD convergence and truncation remain separate.

## Resource preflight and process boundary
One numerical thread; external watchdog samples VmRSS/VmHWM every50ms from
process launch to exit for ALL Python/R arms, including imports, load, construction,
SVD, fixed products and export. Direct verification is a SEPARATE fresh process,
also measured and budgeted, not hidden in pipeline RSS.
512MiB=536870912 bytes per process. Admission includes runtime baseline,input
copies, factors, temporary arrays, SVD workspace. Package admission unchanged.
Scanpy preflight: baseline_after_import+6*8*N*G+3*CSR_bytes+64MiB.
R preflight: baseline_after_import+4*CSR_bytes+6*8*256*G+
64MiB+4*8*(N+G)*64. Do not allocate inadmissible dense tables.
RSS sampling is operational, not an instantaneous physical guarantee.

Each process has300s wall limit INCLUDING imports/products/export (stricter than
300s construction+PCA), with limit detection,kill and observed exit recorded.
Cumulative numeric campaign limit1800s across generation,qualification,runs and
verification. Source metadata qualification recorded separately; transfer bounded
as above. Launch no job after the cumulative limit. A timeout/memory stop blocks
all remaining repetitions of that arm/input; record these outside completed tables.
Do not retry stopped arms or reinterpret censored times as completed durations.

## Repetitions, products and timing
Three fresh process repetitions per admitted stress/real arm/input.
Randomize the full predetermined job order using RNG71306 BEFORE first pipeline;
persist schedule. Same solver initial vector per input across nb arms.
No pipeline warmup. AFTER SVD completes, measure full matvec,rmatvec,matmat8,
rmatmat8 on normalized Gaussian probes seed71305 reset per shape: one warmup
then10 calls per operation, identical for each arm; finitude checks outside
timers for Python and R. No R restart per product.
Construction includes validation,count fingerprint,copies,margins binding,
grouping,selection,correction,background,centering. Input loading separate.
Primary construction+PCA ends when solver returns materialized triplets;
sorting and export separate. Process elapsed includes all phases.
Report individual measurements,median,range and counts/calls/columns;
do not divide total time by solver calls to infer product cost.
Compare costs only for completed precision-comparable arms on same counts,
same target, same timing/RSS boundary; no same-solver claim across runtimes.
Native C++ permanent storage unexposed is NOT_EXPOSED, not wrapper size as total.

## Reporting and scientific decision
All planned jobs, holds, failures,censored and nonexecuted repetitions appear
in manifest/receipts/report; result CSV rows only for completed traceable
executions. Preserve accuracy violations and native fast results.
No modification after outcomes, new seeds or favourable subset selection.
No biological advantage, publication acceptance, novelty or universal speed claim.
GO requires completed independent real evaluation plus reproducible useful
numerical/cost evidence; CONDITIONAL records limited support or incomplete
independent evidence with exact remaining conditions; NO-GO is acceptable if
completed evaluation establishes no sufficiently distinctive advantage.
Data unavailability alone is not evidence of algorithmic inferiority.

"""Check saved timed products and saved direct-reference triplets, without PCA.

Only direct binary64 NB formulas and frozen input/probe files are used as truth.
No nbpearson or previous verifier imports, no new timing campaign or fitting.
Run under the campaign's existing external resource/cumulative-budget guard.
"""
import hashlib
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
from scipy import sparse

ROOT = Path(__file__).resolve().parent
PRODUCT_RTOL = 1e-6
TRIPLET_RTOL = 1e-8
ZERO_REFERENCE_ATOL = 1e-12


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def blocks(x, depth, proportion):
    for first in range(0, x.shape[0], 256):
        last = min(first + 256, x.shape[0])
        mu = depth[first:last, None] * proportion[None, :]
        raw = (x[first:last].toarray() - mu) / np.sqrt(mu + mu * mu / 100.0)
        yield first, last, np.clip(raw, -math.sqrt(x.shape[0]), math.sqrt(x.shape[0]))


def stable_mean(x, depth, proportion):
    total = np.zeros(x.shape[1])
    compensation = np.zeros_like(total)
    for _, _, raw in blocks(x, depth, proportion):
        # fsum within a block, compensated accumulation between blocks.
        term = np.array([math.fsum(map(float, raw[:, j]))
                         for j in range(x.shape[1])]) / x.shape[0]
        increment = term - compensation
        updated = total + increment
        compensation = (updated - total) - increment
        total = updated
    return total


def comparison(actual, expected, rtol):
    assert actual.shape == expected.shape
    assert np.isfinite(actual).all() and np.isfinite(expected).all()
    absolute = float(np.linalg.norm(actual - expected))
    norm = float(np.linalg.norm(expected))
    relative = absolute / norm if norm else None
    passed = relative <= rtol if norm else absolute <= ZERO_REFERENCE_ATOL
    return dict(absolute_error=absolute, reference_norm=norm,
                relative_error=relative,
                relative_status="DEFINED" if norm else "UNDEFINED_ZERO_REFERENCE",
                threshold=rtol if norm else ZERO_REFERENCE_ATOL,
                threshold_contract="relative" if norm else "named_zero_reference_absolute",
                status="SATISFIED" if passed else "OUTSIDE_TOLERANCE")


def load_input(name):
    directory = ROOT / "inputs" / name
    metadata = json.loads((directory / "input.json").read_text())
    hashes = {}
    for filename in ("counts.npz", "parameters.npz", "probes.npz"):
        actual = sha256(directory / filename)
        assert actual == metadata["sha256"][filename], (name, filename)
        hashes[filename] = actual
    x = sparse.load_npz(directory / "counts.npz").astype(np.float64)
    with np.load(directory / "parameters.npz", allow_pickle=False) as f:
        depth = np.array(f["depth"], dtype=np.float64)
        proportion = np.array(f["p"], dtype=np.float64)
    with np.load(directory / "probes.npz", allow_pickle=False) as f:
        probes = {key: np.array(f[key]) for key in ("v", "w", "V", "W")}
    assert x.shape == (metadata["N"], metadata["G"])
    assert x.nnz == metadata["nnz"]
    assert depth.shape == (x.shape[0],) and proportion.shape == (x.shape[1],)
    assert np.isfinite(x.data).all() and (x.data >= 0).all()
    assert np.array_equal(x.data, np.floor(x.data))
    assert np.isfinite(depth).all() and (depth > 0).all()
    assert np.isfinite(proportion).all() and (proportion > 0).all()
    expected_shapes = {"v": (x.shape[1],), "w": (x.shape[0],),
                       "V": (x.shape[1], 8), "W": (x.shape[0], 8)}
    for key, value in probes.items():
        assert value.shape == expected_shapes[key] and np.isfinite(value).all()
    return x, depth, proportion, probes, hashes


def reference_triplets(directory, x):
    pipeline = json.loads((directory / "pipeline.json").read_text())
    assert pipeline["status"] == "COMPLETED" and pipeline["method"] == "direct"
    assert (pipeline["N"], pipeline["G"], pipeline["nnz"]) == (*x.shape, x.nnz)
    with np.load(directory / "solution.npz", allow_pickle=False) as f:
        u, s, vt = (np.array(f[key]) for key in ("u", "s", "vt"))
    assert u.shape == (x.shape[0], 21)
    assert s.shape == (21,) and vt.shape == (21, x.shape[1])
    assert all(np.isfinite(a).all() for a in (u, s, vt))
    assert (s > 0).all() and (s[:-1] >= s[1:]).all()
    return u, s, vt


def main():
    start = time.perf_counter()
    output = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "saved_output_checks.json"
    assert not output.exists(), "Never overwrite verification receipts"
    manifest = json.loads((ROOT / "EXPERIMENT_MANIFEST.json").read_text())
    schedule = manifest["schedule"]
    assert len(schedule) == 27
    results = []
    references = []
    missing = []
    for name in ("stress_U16", "stress_U256", "stress_U2048"):
        x, depth, proportion, probes, input_hashes = load_input(name)
        mean = stable_mean(x, depth, proportion)
        joined_v = np.column_stack((probes["v"], probes["V"]))
        joined_w = np.column_stack((probes["w"], probes["W"]))
        direct_forward = np.empty((x.shape[0], 9))
        direct_reverse = np.zeros((x.shape[1], 9))
        reference_dir = ROOT / "runs" / (name + "_reference")
        reference_available = ((reference_dir / "pipeline.json").is_file()
                               and (reference_dir / "solution.npz").is_file())
        if reference_available:
            ru, rs, rvt = reference_triplets(reference_dir, x)
            av = np.empty_like(ru)
            atu = np.zeros_like(rvt.T)
        norm_terms = []
        for first, last, raw in blocks(x, depth, proportion):
            truth = raw - mean
            norm_terms.append(float(np.sum(truth * truth)))
            direct_forward[first:last] = truth @ joined_v
            direct_reverse += truth.T @ joined_w[first:last]
            if reference_available:
                av[first:last] = truth @ rvt.T
                atu += truth.T @ ru[first:last]
        reference_norm = math.sqrt(math.fsum(norm_terms))
        expected_products = {"matvec": direct_forward[:, 0],
                             "rmatvec": direct_reverse[:, 0],
                             "matmat8": direct_forward[:, 1:],
                             "rmatmat8": direct_reverse[:, 1:]}
        if reference_available:
            checks = {}
            for k in (20, 21):
                left = float(np.linalg.norm(av[:, :k] - ru[:, :k] * rs[:k]))
                right = float(np.linalg.norm(atu[:, :k] - rvt[:k].T * rs[:k]))
                snorm = float(np.linalg.norm(rs[:k]))
                relative = max(left, right) / snorm if snorm else None
                checks[str(k)] = dict(
                    Av_residual_absolute=left, ATu_residual_absolute=right,
                    singular_values_norm=snorm, relative_residual=relative,
                    status=("SATISFIED" if relative is not None
                            and relative <= TRIPLET_RTOL else "OUTSIDE_TOLERANCE"),
                    left_orthogonality_error=float(
                        np.linalg.norm(ru[:, :k].T @ ru[:, :k] - np.eye(k))),
                    right_orthogonality_error=float(
                        np.linalg.norm(rvt[:k] @ rvt[:k].T - np.eye(k))))
            references.append(dict(
                dataset=name, solution_sha256=sha256(reference_dir / "solution.npz"),
                input_sha256=input_hashes, reference_norm=reference_norm,
                gap_20_21=float(rs[19] - rs[20]), triplets=checks,
                triplet_threshold=TRIPLET_RTOL,
                orthogonality_status="REPORTED_NO_NEW_GATE",
                status=("SATISFIED" if all(v["status"] == "SATISFIED"
                                         for v in checks.values())
                        else "OUTSIDE_TOLERANCE")))
        else:
            missing.append(dict(dataset=name, artifact="direct_reference",
                                status="NOT_EVALUATED_MISSING_SAVED_REFERENCE"))
        for job in schedule:
            if job["dataset"] != name:
                continue
            label = f'{name}_{job["method"]}_r{job["repetition"]}'
            directory = ROOT / "runs" / label
            if not ((directory / "pipeline.json").is_file()
                    and (directory / "product_outputs.npz").is_file()):
                missing.append(dict(**job, status="NOT_EVALUATED_MISSING_SAVED_PRODUCTS"))
                continue
            info = json.loads((directory / "pipeline.json").read_text())
            assert info["status"] == "COMPLETED" and info["method"] == job["method"]
            assert (info["N"], info["G"], info["nnz"]) == (*x.shape, x.nnz)
            with np.load(directory / "product_outputs.npz", allow_pickle=False) as f:
                assert set(f.files) == set(expected_products)
                comparisons = {key: comparison(np.asarray(f[key]), expected, PRODUCT_RTOL)
                               for key, expected in expected_products.items()}
            results.append(dict(
                **job, input_sha256=input_hashes,
                product_outputs_sha256=sha256(directory / "product_outputs.npz"),
                pipeline_sha256=sha256(directory / "pipeline.json"),
                products=comparisons,
                status=("SATISFIED" if all(v["status"] == "SATISFIED"
                                         for v in comparisons.values())
                        else "OUTSIDE_TOLERANCE")))
    assert len(results) + sum("method" in row for row in missing) == 27
    report = dict(
        kind="supplemental_saved_output_verification_no_new_PCA",
        purpose="Verify actual saved timed outputs and direct-reference triplets",
        method_unchanged=True, new_performance_measurements=False,
        floating_point_certificate=False,
        reference_scope="independent direct binary64 formula in blocks256",
        matrix_rtol=PRODUCT_RTOL, triplet_rtol=TRIPLET_RTOL,
        zero_reference_absolute_threshold=ZERO_REFERENCE_ATOL,
        completed_product_runs_checked=len(results),
        completed_reference_solutions_checked=len(references),
        products=results, references=references, absent_artifacts=missing,
        status=("SATISFIED" if not missing
                and all(row["status"] == "SATISFIED" for row in results + references)
                else "INCOMPLETE_OR_OUTSIDE_TOLERANCE"),
        elapsed_seconds=time.perf_counter() - start,
        verifier_sha256=sha256(Path(__file__)))
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({key: report[key] for key in (
        "status", "completed_product_runs_checked",
        "completed_reference_solutions_checked", "elapsed_seconds")}))


if __name__ == "__main__":
    main()

# Scientific decision — CONDITIONAL

**One recommendation: retain the frozen dev1 implementation and defer a publication-oriented GO decision.**

The new evidence supports a limited computational contribution:27 completed
synthetic pipelines with observed accuracy satisfied, correct reuse of factors,
and storage savings at repeated depths. It also preserves negative evidence:
grouped interpolation does not consistently improve fixed-product cost, loses
its storage advantage at U=N, and BPCells fast exceeds the product threshold
on the tiny qualifier. These observations do not establish universal superiority.

Neither independent real dataset was numerically evaluated. Both are DATA HOLD
because exact eligible outputs/version,size and local acquisition/hash were not
jointly qualified. This is not a scientific failure of BPCells,Scanpy or nbpearson.
The synthetic experiment is not independent biological evidence.

Conditions still necessary for GO:
1. Admit the two specified unnormalized-count artifacts with exact provenance,
   sizes,transfer receipts and hashes; retain the fixed deterministic selections.
2. Complete bounded real-data qualification and all admitted six native arms,
   resolving the documented unexecuted Scanpy preflight/R-verification plumbing
   without changing the statistical target or tuning the numerical core.
3. Evaluate numerical fidelity and final triplets separately from convergence;
   assess any cost advantage only within matched scopes and completed precision
   criteria. Preserve all negative outcomes,holds and censures.

Initial qualification failures,pre-campaign harness amendments and supplementary
saved-output verification are explicit limitations of this execution.
No installation,new numerical method,manuscript change,public release or submission
is recommended or performed by this decision. The evidence does not justify
GO, but data unavailability alone does not establish an algorithmic NO-GO.

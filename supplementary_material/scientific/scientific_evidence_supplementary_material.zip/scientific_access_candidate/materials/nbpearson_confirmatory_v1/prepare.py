"""Frozen deterministic synthetic generator; no biological data or dense counts."""
import json,hashlib,time,math
from pathlib import Path
import numpy as np
from scipy import sparse,io
ROOT=Path(__file__).resolve().parent
def make(name,n,g,u=None,qualification=False):
    out=ROOT/'inputs'/name;out.mkdir(parents=True,exist_ok=False)
    rs=np.random.default_rng(71303);rg=np.random.default_rng(71302);rc=np.random.default_rng(71304 if not qualification else 71301)
    width=4 if qualification else 40
    groups=np.arange(n)%u if u else None
    if u:groups=groups[rg.permutation(n)];depth=2000+np.floor(np.arange(u)*18000/(u-1)).astype(int);requested=depth[groups]
    indices=np.empty((n,width),dtype=np.int32);values=np.empty_like(indices,dtype=np.float64)
    for i in range(n):
        anchor=i%g;others=rs.choice(g-1,width-1,replace=False);others+=others>=anchor
        indices[i]=np.sort(np.r_[anchor,others])
        values[i]=rc.integers(1,70,width) if qualification else 1+rc.multinomial(int(requested[i])-width,np.full(width,1/width))
    x=sparse.csr_matrix((values.ravel(),indices.ravel(),np.arange(0,n*width+1,width)),shape=(n,g))
    d=np.asarray(x.sum(1)).ravel();tot=np.asarray(x.sum(0)).ravel();p=tot/tot.sum()
    assert (d>0).all() and (p>0).all() and np.isfinite(x.data).all() and np.all(x.data==np.floor(x.data))
    if u:assert len(np.unique(d))==u and np.array_equal(d,requested)
    assert x.nnz==n*width
    rng=np.random.default_rng(71305);q={}
    for key,shape in [('v',(g,)),('w',(n,)),('V',(g,8)),('W',(n,8))]:
        a=rng.normal(size=shape);a/=np.linalg.norm(a,axis=0);q[key]=a
    sparse.save_npz(out/'counts.npz',x);np.savez(out/'parameters.npz',depth=d,p=p);np.savez(out/'probes.npz',**q)
    record=dict(name=name,N=n,G=g,nnz=x.nnz,density=x.nnz/(n*g),sparsity=1-x.nnz/(n*g),U_d=len(np.unique(d)),U_d_over_N=len(np.unique(d))/n,
        multiplicity=np.unique(d,return_counts=True)[1].tolist(),depth_min=float(d.min()),depth_max=float(d.max()),removed_rows=[],removed_columns=[],
        row_group_permutation_seed=71302,support_seed=71303,count_seed=71301 if qualification else 71304,probe_seed=71305,kind='qualification' if qualification else 'synthetic_stress')
    # No R exports for stress arms; only tiny qualification has a dense oracle.
    if qualification:
        io.mmwrite(out/'counts_gene_by_obs.mtx',x.T)
        for key,a in q.items():np.savetxt(out/(key+'.tsv'),a,fmt='%.17g',delimiter='\t')
        np.savetxt(out/'depth.tsv',d,fmt='%.17g');np.savetxt(out/'proportion.tsv',p,fmt='%.17g')
        np.savetxt(out/'config.tsv',[100,math.sqrt(n),n,g],fmt='%.17g')
        mu=d[:,None]*p;rr=(x.toarray()-mu)/np.sqrt(mu+mu*mu/100);rr=np.clip(rr,-math.sqrt(n),math.sqrt(n));rr-=rr.mean(0)
        np.savetxt(out/'oracle_obs_by_gene.tsv',rr,fmt='%.17g',delimiter='\t')
    record['sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()}
    (out/'input.json').write_text(json.dumps(record,indent=2)+'\n')
    return record
if __name__=='__main__':
    records=[make('qualification',128,64,qualification=True)]
    records += [make('stress_U'+str(u),2048,512,u) for u in (16,256,2048)]
    (ROOT/'inputs_manifest.json').write_text(json.dumps(records,indent=2)+'\n')
    print('Generated four fixed synthetic sparse inputs; no biological data.')

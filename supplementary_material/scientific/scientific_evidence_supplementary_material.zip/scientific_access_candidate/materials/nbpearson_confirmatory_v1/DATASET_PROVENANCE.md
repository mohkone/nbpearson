# Dataset provenance — confirmatory V1

Qualification date: 14 November 2026 Asia/Shanghai (13 November 2026 UTC). This document separates official source reports from acquired local evidence. **Both datasets are currently DATA HOLD**; neither is a numerical failure of any comparison arm.

| Dataset | Official source-reported metadata | Licence/access evidence | Local evidence and admission |
|---|---|---|---|
| A — Human PBMC10k | [Official dataset page](https://www.10xgenomics.com/datasets/10k-human-pbmcs-3-ht-v3-1-chromium-x-3-1-high): Cell Ranger6.1.0/count,11996 recovered cells,one sample,published2021-09-14. | Page explicitly identifies CC BY4.0; summary link accessible as documentary metadata. | No downloaded count artifact; exact selected output,size,shape and SHA-256 unverified. DATA HOLD. |
| B — adult mouse brain nuclei10k | [Official dataset page](https://www.10xgenomics.com/datasets/10k-Mouse-Brain-CNIK-3p-nextgem): Cell Ranger8.0.0/multi,9684 nuclei,one sample,published2024-04-15. | Page explicitly identifies CC BY4.0; summary link accessible as documentary metadata. | Dynamic matrix download list not exposed by the page parser; no acquired artifact or verified size/hash. DATA HOLD. |

The reported counts above are provider metadata, not dimensions measured from downloaded files or prospective final subsets. These are independent source resources relative to the historical PBMC3k/spatial development artifacts, but independence of any selected observations has not been demonstrated by local data processing.

## Exact count-output qualification

The dataset pages expose output-tab headings but their dynamic matrix lists were not returned by the documentary browser. No exact HDF5 output is silently invented from a naming pattern.

For A, an [official10x analysis guide](https://www.10xgenomics.com/analysis-guides/background-removal-guidance-for-single-cell-gene-expression-datasets-using-third-party-tools), section “PBMC10k”, explicitly lists this uncorrected raw feature-barcode count URL:

https://cf.10xgenomics.com/samples/cell-exp/6.1.2/10k_PBMC_3p_nextgem_Chromium_X/10k_PBMC_3p_nextgem_Chromium_X_raw_feature_bc_matrix.h5

That path uses6.1.2 while the requested dataset page states6.1.0. It is an established official link in that guide, **not an admitted substitute** for a qualified output version of the specified dataset. No CellBender or other background-corrected output is admitted.

Two pattern-inferred filtered-count URLs were tested only through the documentary web tool and were inaccessible; they remain explicitly unverified in source_qualification.json. A label “filtered” would identify a barcode-filtered count output, not by itself a normalized expression matrix, but the contents and source linkage still require qualification.

## Access receipt and outstanding operations

One bounded local HTTP request for the A metadata page failed with “URLError: <urlopen error [Errno1] Operation not permitted>”; timeout15s,metadata read cap4MiB,no bytes,no retries. No proxy/TLS modification or bypass was attempted. Web-readable metadata does not establish a usable local download channel.

No matrix was acquired, decompressed, selected or normalized; no local biological SHA-256 can be reported. Download sizes are **unknown**, not zero. No local count copy of established provenance was identified by this task; no recursive search outside the project was performed.

To lift a hold, record the exact official unnormalized integer-count output and version, its advertised or HTTP byte length, and an authorized bounded transfer receipt. Hash the received bytes; validate HDF5 layout,integer/nonnegative counts,feature types,identifier uniqueness and dimensions before preparation. Record all exclusions and the final axes/margins without changing the prospective protocol. Do not substitute another dataset,output version or favourable selection after observing accuracy or timings.

## Licence scope

Both official pages explicitly licence their datasets CC BY4.0. The [Creative Commons deed](https://creativecommons.org/licenses/by/4.0/), “terms” and “notices”, documents attribution,licence-link and change-indication requirements, and notes other rights may remain. Preserve source attribution and describe subset transformations. This is a documentary finding, not legal advice, donor consent evidence or an ethics exemption. Neither the software licence nor public download availability alone supplies data rights.

Detailed documentary receipts and source URLs: [source_qualification.json](source_qualification.json). No biological outcomes,labels or annotations were analyzed.

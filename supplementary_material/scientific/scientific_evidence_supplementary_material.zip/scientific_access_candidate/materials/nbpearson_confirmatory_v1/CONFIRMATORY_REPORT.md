# Confirmatory evaluation V1 — bounded report

## Decision and actual scope

**CONDITIONAL. Independent real-data confirmation was not executed.** Both requested
official resources remain DATA HOLD: their exact admitted count-output/version,
download size, transfer and local SHA-256 were not established together.
Web-readable metadata/licences are not locally acquired counts. No substitute
dataset, historical PBMC/spatial rerun, software installation or core change was used.

Completed evidence is separately labelled: six tiny matrix/product qualifications,
two existing standalone Decimal qualification tests, three new streamed reference
SVDs, and 27 prospectively scheduled synthetic stress pipelines with 27 separate
matrix/triplet verifications. These are computational evidence, not two independent
biological datasets. No conclusion of publication readiness follows.

## Frozen design and preservation

[CONFIRMATORY_PROTOCOL.md](CONFIRMATORY_PROTOCOL.md) and
[EXPERIMENT_MANIFEST.json](EXPERIMENT_MANIFEST.json) record the pre-numerical freeze,
seeds, exact schedule, input hashes, source preservation, software and limits.
The installed dev1 sources matched the evaluated wheel SHA-256
6334eb9758d004ba7171b8c430f4b1df9d659ac2327ff152db26905b282238e7.
Only the new directory was written; relevant dev1/rev3/V2.1 files were rehashed.

Primary target: theta100,clip=sqrt(N),gene centering after clipping,standard NB
variance,fixed full-universe binary64 margins. The synthetic stress uses N2048,
G512,nnz81920 (density0.078125,sparsity0.921875),40 positive counts/row,
U16/256/2048; no zero margins were removed. All interpolation selections used
16 nodes (degree15), distinct from20 retained components and21 calculated triplets.
Clipping entries were49515/49838/49938 respectively; full columns0.

## Matrix, product and spectral accuracy

All27 synthetic runs converged and satisfy the frozen observed matrix/product,
triplet,singular-value and interpretable-subspace criteria. Maxima across them:
- matrix relative Frobenius error:1.6884238618319313e-14;
- error of actual saved timed products:2.43274938817766e-14;
- relative triplet residual against direct formula:7.216806708871208e-15;
- singular-value relative error:2.6080618431968423e-15;
- left/right maximal angles:5.360887590000392e-13 /5.351112106271226e-13rad.

The three direct references were additionally checked at20 and21 triplets
against the direct binary64 formula; all satisfied1e-8 residual criterion.
The gap criterion was satisfied for all evaluated synthetic subspaces.
These are observations against a floating reference, not interval bounds or
a universal floating-point certificate. The construction diagnostic remains
NOT_EVALUATED; L floating remains an uncertified lower bound.

[accuracy_results.csv](accuracy_results.csv) separates matrix,triplet,subspace,
selection and actual-saved-product statuses. [saved_output_checks.json](saved_output_checks.json)
checks108 saved arrays: the last saved output of each ten-call lot, not all
individual calls. The original verifier reconstructs a fresh operator; its
results were preserved and supplemented, not silently replaced.

## Synthetic cost and representation

Three fresh processes per cell; medians and ranges below come only from this
session. Sorting/export are outside construction+PCA; sorting time was not
separately recorded. Products follow PCA with one warmup and ten timed calls;
finitude checks are outside timing. Full-process RSS includes imports,load,
construction,PCA,products and export for every timed arm; verification RSS is
separate. Times below are seconds, products microseconds/call, storage bytes.

| U / U/N | Representation | Nodes | Pipeline median [min,max] s | Operator bytes | Peak process RSS bytes | matvec µs | rmatvec µs | matmat8 µs | rmatmat8 µs |
|---|---|---:|---|---:|---:|---:|---:|---:|---:|
| 16 / 0.0078125 | interpolated | 16 | 0.060977 [0.060627,0.061227] | 1323012 | 89145344 | 52.641 | 88.579 | 229.353 | 261.837 |
| 16 / 0.0078125 | interpolated_grouped | 16 | 0.059598 [0.058619,0.059598] | 1079684 | 89329664 | 56.115 | 90.489 | 250.510 | 356.053 |
| 16 / 0.0078125 | exact_grouped | N/A | 0.059063 [0.057359,0.059312] | 1081604 | 88252416 | 51.769 | 88.442 | 236.714 | 358.788 |
| 256 / 0.125 | interpolated | 16 | 0.081043 [0.080097,0.083004] | 1323012 | 89194496 | 54.301 | 90.330 | 231.670 | 265.633 |
| 256 / 0.125 | interpolated_grouped | 16 | 0.075419 [0.074964,0.076043] | 1114244 | 89403392 | 52.810 | 87.588 | 230.393 | 363.070 |
| 256 / 0.125 | exact_grouped | N/A | 0.094356 [0.092347,0.095540] | 2068484 | 90947584 | 70.020 | 105.175 | 305.905 | 433.037 |
| 2048 / 1 | interpolated | 16 | 0.070925 [0.069372,0.071470] | 1323012 | 89124864 | 64.182 | 93.324 | 235.624 | 261.186 |
| 2048 / 1 | interpolated_grouped | 16 | 0.070967 [0.069746,0.071254] | 1372292 | 89522176 | 64.960 | 95.464 | 250.650 | 385.562 |
| 2048 / 1 | exact_grouped | N/A | 0.181679 [0.179919,0.199264] | 9437188 | 98426880 | 192.601 | 220.026 | 862.591 | 1002.111 |

The grouped interpolant saves permanent storage at repeated depths, but this
small workload does not establish a consistent fixed-product speed advantage.
At U=N its storage exceeds the non-grouped interpolant and its transposed block
product is slower. At intermediate U its lower pipeline median coexists with
different solver work: do not attribute the whole change to a cheaper product.
The exact grouped table is competitive at low U and increasingly costly as
U grows; it avoids interpolation error but remains floating.

Solver call/column counts, construction,selection,PCA,loading,export,process time,
array-storage breakdown and individual product timings are preserved in
[performance_results.csv](performance_results.csv) and each run's products.csv.
Examples at repetition1: A/B both262 direct and262 transpose vector calls atU16;
atU256 A369/B346; atU2048 A308/B284. Each also has one matmat call processing21
columns. This is not an imposed iteration equality. Inputs' margins,clipping and
spectra also vary across U, so effects are not causally attributable to U alone.
Three repetitions and submillisecond products do not support universal rankings.

## Tiny qualification, negative evidence and harness amendments

Python three representations and official Scanpy normalization pass matrix and
four-product criteria on the128x64 qualifier. BPCells slow=TRUE passes as well.
BPCells slow=FALSE has matrix error8.65418368313025e-7, but matvec error
1.04721903949447e-6 exceeds1e-6; all continuous errors remain in accuracy_results.csv
and its qualification.json. This is approximation evidence on one synthetic
fixture, not a claim about either unavailable real dataset. No native Spectra
PCA was executed here; matrix qualification is not PCA pipeline validation.
Python and R qualifiers have different execution scopes and are not speed baselines.

Five initial qualification processes failed: the reference and three nb arms
attempted ncv64 on64 columns (ARPACK requires ncv<min(shape)); Scanpy import failed
because cache locations were unwritable. Failed receipts and original code are
retained. Before the stress campaign, the tiny qualifier became matrix/products-only
without changing its counts,thresholds or solver settings; the stress dimensions
and full solver contract were unchanged. Process-local cache directories fixed
the import plumbing without JIT disabling,installation or library edits.
See [QUALIFICATION_AMENDMENT.json](QUALIFICATION_AMENDMENT.json). This is a
qualification amendment, not a pristine error-free preregistered execution.

The later saved-output verifier closes a measurement coverage limitation:
original checks reconstructed products rather than reading timed outputs, and
direct reference triplets lacked an independent residual gate. The supplementary
checks use the already-fixed criteria on saved outputs, no PCA/performance rerun
or core change. Its code hash and receipt are recorded separately.

## Resources and remaining limits

Guarded numerical children, including generation,qualification,failures,reference
SVDs,verification and table/report consolidation, are accounted in ledger.json.
Before this reporting process: 49.841994s,
well below1800s. No300s wall or512MiB process limit was triggered; the watchdog
scope is whole process (stricter than construction+PCA alone), sampled50ms.
Highest observed RSS over all completed/failed numeric children before reporting:
272617472 bytes. Timed stress pipeline maximum:
98426880 bytes.
Sampling is not an instantaneous physical guarantee. Host context was sampled
after these runs and labelled as such; power,clock policy and competing workload
were not prospectively controlled. Source-page/documentary time is separate.

Two real sources, four target configurations and72 planned real repetitions
are recorded DATA HOLD, outside completed-result CSVs. Their N,G,nnz,U and costs
cannot be supplied from provider-reported counts. No completion time or ratio
is inferred for them. Scanpy's full pipeline branch still lacks a dense preflight
gate (only its tiny qualifier has it); the unexecuted branch must not be claimed
qualified for future independent-data use. Native R large-case verification
and SVD pipelines are likewise not established by the tiny matrix qualifier.

## Scientific interpretation

The new synthetic evidence supports correct structured representations and a
bounded mechanism result: compression reduces repeated-depth storage, while
cost benefits are workload-dependent and disappear at unique depths here.
It does not provide the requested independent real-data publication evidence
or demonstrate differentiation against all six admitted real-data arms.
Keep the implementation frozen. The single recommendation is CONDITIONAL:
defer a GO claim until the two source holds and the explicitly incomplete
real-data pipeline qualifications are resolved under this fixed target.
No manuscript,GitHub,release or submission changes were made.

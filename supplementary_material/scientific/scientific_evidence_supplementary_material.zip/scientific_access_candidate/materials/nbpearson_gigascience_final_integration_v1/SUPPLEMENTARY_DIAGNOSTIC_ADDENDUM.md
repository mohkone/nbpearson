# Integrated supplementary diagnostic addendum and preserved scientific tables

Separate final-integration companion, 16 November 2026 (Asia/Shanghai). All five original V3.1 table blocks below are preserved byte-for-byte. EA-F1, EA-F2, EA-F3 and EA-R1 integrate audited documentary explanations using saved evidence. R means recorded, D means documentary scalar calculation or summary, and a test assertion is not a newly observed per-case value. Historical V2 wording in the retained source sections describes those earlier records; no scientific execution occurred here. Original figures/source values remain unchanged. Exact source/placement identities are in `verification/SCIENCE_TABLE_IDENTITY.json`.

## Supplementary Table S1: Explicit representations

Verbatim original V3.1 Table 1; source-block identity is recorded in `verification/SCIENCE_TABLE_IDENTITY.json`.

| API representation | Conceptual centered operator | Stored background |
|---|---|---|
| interpolated (A) | \(HC+W_NF^\top\) | N×r and G×r |
| interpolated_grouped (B) | \(HC+PW_dF^\top\) | \(U_d\)×r, G×r, group indices and multiplicities |
| exact_grouped (C) | \(HC+PK_c\) | \(U_d\)×G plus group information |

## Supplementary Table S2: Confirmatory real-data targets

Verbatim original V3.1 Table 2; source-block identity is recorded in `verification/SCIENCE_TABLE_IDENTITY.json`.

| Target | N | G | nnz | \(U_d\) | \(U_d/N\) | Nodes A/B | Clipped entries |
|---|---:|---:|---:|---:|---:|---:|---:|
| C1: PBMC small | 1000 | 1000 | 164880 | 567 | 0.567000 | 48 | 71 |
| C2: PBMC large | 9999 | 2000 | 3159138 | 2354 | 0.235424 | 57 | 66 |
| C3: Mouse small | 1000 | 1000 | 122789 | 418 | 0.418000 | 34 | 66 |
| C4: Mouse large | 9684 | 2000 | 2228468 | 1391 | 0.143639 | 40 | 78 |

## Supplementary Table S3: Maximum errors over completed confirmatory pipelines

Verbatim original V3.1 Table 3; source-block identity is recorded in `verification/SCIENCE_TABLE_IDENTITY.json`.

| Method | PCA runs | Matrix relative | Four-product relative max | Retained-triplet relative residual | Singular relative | Angle max | All final criteria |
|---|---:|---:|---:|---:|---:|---:|---:|
| interpolated | 12 | 2.15e-16 | 2.33e-15 | 4.63e-15 | 2.3e-15 | 8.78e-14 | 12/12 |
| interpolated_grouped | 12 | 2.15e-16 | 2.45e-15 | 5.32e-15 | 2.46e-15 | 5.23e-14 | 12/12 |
| exact_grouped | 12 | 1.57e-16 | 2.4e-15 | 5.91e-15 | 2.95e-15 | 2.19e-14 | 12/12 |
| scanpy | 6 | 9.92e-17 | 8.48e-16 | 2.26e-15 | 2.51e-15 | 6.06e-14 | 6/6 |
| BPCells_FALSE | 12 | 5.07e-07 | 5.96e-07 | 3.73e-07 | 2.11e-07 | 2.52e-06 | 0/12 |
| BPCells_TRUE | 12 | 2.57e-15 | 6.07e-15 | 5.05e-13 | 1.02e-14 | 7.92e-12 | 12/12 |

## Supplementary Table S4: Construction plus PCA times

Verbatim original V3.1 Table 4; source-block identity is recorded in `verification/SCIENCE_TABLE_IDENTITY.json`.

| Target | A | B | C | Scanpy | BPCells fast* | BPCells slow |
|---|---|---|---|---|---|---|
| C1: PBMC small | 0.109008 [0.103105, 0.109954] | 0.104087 [0.102695, 0.108437] | 0.167724 [0.154273, 0.178803] | 0.197671 [0.197619, 0.240007] | 0.223000 [0.220000, 0.239000] | 1.004000 [1.001000, 1.009000] |
| C2: PBMC large | 0.973818 [0.967567, 1.032645] | 0.976686 [0.913775, 1.008432] | 1.328785 [1.281662, 1.353993] | Preflight refusal | 3.066000 [3.060000, 3.087000] | 14.166000 [14.130000, 14.199000] |
| C3: Mouse small | 0.068751 [0.065361, 0.070597] | 0.072075 [0.069559, 0.073028] | 0.098933 [0.097062, 0.104905] | 0.185306 [0.179849, 0.191452] | 0.158000 [0.153000, 0.167000] | 0.794000 [0.762000, 0.802000] |
| C4: Mouse large | 0.746582 [0.710380, 0.759311] | 0.774988 [0.678611, 0.777795] | 0.882104 [0.859039, 1.028137] | Preflight refusal | 1.915000 [1.906000, 1.926000] | 9.583000 [9.568000, 9.605000] |

## Supplementary Table S5: Permanent operator-owned arrays

Verbatim original V3.1 Table 5; source-block identity is recorded in `verification/SCIENCE_TABLE_IDENTITY.json`.

| Target | A bytes | B bytes | A−B bytes | C bytes |
|---|---:|---:|---:|---:|
| C1: PBMC small | 2758564 | 2609748 | 148816 | 6551636 |
| C2: PBMC large | 43437200 | 40069192 | 3368008 | 75763312 |
| C3: Mouse small | 2029472 | 1886128 | 143344 | 4852160 |
| C4: Mouse large | 30535236 | 27981524 | 2553712 | 49168084 |


<a id="ea-f1"></a>
## EA-F1 — Complete permanent-array accounting

The component accounting includes the separately stored correction-mean vector `C_mean`, a binary64 array of length G (8G bytes). Every original operator total already includes `C_mean`; it must not be added again. The unchanged “Group/mean metadata” column comprises grouping and basis/background mean arrays as applicable and excludes `C_mean`. Counts, input margins/probes, construction/product temporaries, outputs, object overhead and solver workspace are outside these operator-owned array totals. Process RSS is separate.

The following additive detail retains all seven original §S7.5 cell strings and totals; only G and `C_mean` are exposed as explanatory columns. It complements the unchanged aggregate Table S5 above. In component headings C denotes the sparse correction; a row ending /C denotes the exact-grouped representation.

| Target/arm | G (recorded) | C bytes | Left bytes | Right bytes | Table bytes | Group/mean metadata bytes | C_mean bytes (already in total) | Operator total bytes |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| PBMC-S/A | 1000 | 1982564 | 384000 | 384000 | — | 0 | 8000 | 2758564 |
| PBMC-S/B | 1000 | 1982564 | 217728 | 384000 | — | 17456 | 8000 | 2609748 |
| PBMC-S/C | 1000 | 1982564 | — | — | 4536000 | 25072 | 8000 | 6551636 |
| PBMC-L/A | 2000 | 37949656 | 4559544 | 912000 | — | 0 | 16000 | 43437200 |
| PBMC-L/B | 2000 | 37949656 | 1073424 | 912000 | — | 118112 | 16000 | 40069192 |
| PBMC-L/C | 2000 | 37949656 | — | — | 37664000 | 133656 | 16000 | 75763312 |
| Mouse-S/A | 1000 | 1477472 | 272000 | 272000 | — | 0 | 8000 | 2029472 |
| Mouse-S/B | 1000 | 1477472 | 113696 | 272000 | — | 14960 | 8000 | 1886128 |
| Mouse-S/C | 1000 | 1477472 | — | — | 3344000 | 22688 | 8000 | 4852160 |
| Mouse-L/A | 2000 | 26780356 | 3098880 | 640000 | — | 0 | 16000 | 30535236 |
| Mouse-L/B | 2000 | 26780356 | 445120 | 640000 | — | 100048 | 16000 | 27981524 |
| Mouse-L/C | 2000 | 26780356 | — | — | 22256000 | 115728 | 16000 | 49168084 |

All 12 rows reconcile across the 36 saved primary receipts: the old displayed-component gap is 8G and every total already includes it. Integer reconciliation is D bookkeeping, not a memory measurement. [Exact original cells, components and source identities](verification/STORAGE_SOURCE_RECONCILIATION.json) are retained.

## Table interpretation and retained numerical definitions

Table S1 uses C for the sparse correction and label C for the exact-grouped representation; they are different uses of the letter. Write R=S+B, with S_ij=X_ij/sqrt(mu_ij+mu_ij²/theta) and B_ij=-sqrt(theta)(1+theta/(n_i p_j))^(-1/2). On the original nonzero support, D_ij=clip(R_ij,-c,c)-R_ij; elsewhere D=0. In the supported finite-clipping domain, zero-count residuals lie above -sqrt(theta), so no omitted zero-count adjustment is needed. C=S+D and the centered target is H(C+B). The implementation anchors B at n0=min(n), a gene-wise constant shift annihilated by H in exact arithmetic. Rationalized differences and the special global full-column stabilization are retained implementation details, not a new approximation family.

For the table's factor notation, F contains anchored background values at Chebyshev–Lobatto log-depth nodes; W_N is the column-centered cardinal basis on all observations. P is the implicit exact-depth incidence map. W_d is constructed directly at the distinct binary64 depths and centered with multiplicities m_u/N, giving P W_d=W_N in exact arithmetic. K_c is the directly evaluated anchored background table centered with those multiplicities. Group transpose reductions sum; no observation is merged or reweighted. r is an interpolation-node count, not the retained PCA dimension. Table S1's background dimensions exclude the sparse correction, means, grouping storage where not explicitly listed, inputs, temporaries and solver workspace.

The classical selector uses log-depth half-span h, rho=pi/(2h)+sqrt(1+(pi/(2h))²), and the exact-arithmetic bound Delta_r=4 sqrt(theta*N*G)/(rho-1)*rho^(-(r-1)). For q disjoint adjacent row pairs in the frozen order, L²=(1/2)sum_l ||T_(2l,:)-T_(2l+1,:)||² is an exact-arithmetic lower bound on ||HT||_F. The implemented floating evaluation of L is not certified. Selection tests Delta_r <= matrix_rtol*L logarithmically, within node/resource ceilings; unusable L is refused rather than replaced by an epsilon. L=0 does not imply A=0. The equal-depth background is centered away but the sparse correction may remain nonzero. The preserved Technical Supplement V3 and source modules give the complete version-specific derivation, compensated formulas, cancellation examples and resource estimates. No new theorem or floating-point certificate is introduced here.

<a id="ea-f2"></a>
## EA-F2 — Recorded selection state and documentary checks

R fields below are literal saved values. A/r1 represents each target; A/B selection-defining values agree across three primary repetitions and their separate verifier reconstructions. All A/B statuses are `selected`, with R matrix tolerance `rtol=1e-6`, R node ceiling `max_nodes=128`, and 16 requested/evaluated adjacent pairs (0,1), (2,3), …, (30,31): 32 original norm rows. C has intentional `NOT_APPLICABLE_NO_INTERPOLATION`, not a missing selection record. Endpoints are target `input.json` fields `depth_min/depth_max`, after recorded selection/exclusions; they are not separate selector dictionary keys.

| Target | R depth min | R depth max | R log-depth span | R pairs | R L | R Delta_r | R nodes r |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| C1 / PBMC-S | 2.0 | 2346.0 | 7.067319848653476 | 16 | 137.4611140615462 | 0.0001180409726111074 | 48 |
| C2 / PBMC-L | 2.0 | 5523.0 | 7.923529289341242 | 16 | 213.70098239045257 | 0.0001485539438488209 | 57 |
| C3 / Mouse-S | 11.0 | 1503.0 | 4.917323116954604 | 16 | 147.10539045089334 | 0.00011464426748918398 | 34 |
| C4 / Mouse-L | 30.0 | 7111.0 | 5.468200778221362 | 16 | 207.71259393028924 | 0.00013220753013995452 | 40 |

The original dictionary retains logarithmic bounds, pair IDs, baselines, admission estimates and flags. All 36 primary and 36 verifier records are preserved separately in [SELECTION_SOURCE_RECORDS.json](verification/SELECTION_SOURCE_RECORDS.json). `floating_validation=NOT_EVALUATED`, uncertified L and absence of a floating-point certificate remain explicit.

### D — first-admissible-node trace

The frozen saved-scalar rule is ell(r)=log_prefactor−(r−1)log_rho, with q=log_rho>0 and threshold t=log(rtol)+log(L). The audited check is ell(r)≤t<ell(r−1) within the original loop/ceiling and recorded admission limits. Positive q implies all smaller candidate node counts also fail that same saved accuracy criterion. Under the same baseline, the frozen admission polynomials are nondecreasing in r. This establishes first admissibility **relative to the saved scalar state**, not direct re-evaluation of the original contrasts, L, residuals or historical loop. The quantities in this next table are D calculations except the selected bound marked R.

| Target | D rtol × recorded L | R selected Delta_r | D implied Delta_(r−1) | D selected passes / preceding fails |
| --- | ---: | ---: | ---: | --- |
| C1 / PBMC-S | 0.0001374611140615462 | 0.0001180409726111074 | 0.00018165015065912872 | PASS / FAIL as required |
| C2 / PBMC-L | 0.00021370098239045256 | 0.0001485539438488209 | 0.00021870453669237453 | PASS / FAIL as required |
| C3 / Mouse-S | 0.00014710539045089332 | 0.00011464426748918398 | 0.00020928844696687716 | PASS / FAIL as required |
| C4 / Mouse-L | 0.00020771259393028923 | 0.00013220753013995452 | 0.00022842929971147945 | PASS / FAIL as required |

All 48 interpolated records satisfy these documentary checks. The prior scalar audit used `math.isclose(rel_tol=2e-14, abs_tol=2e-14)` solely for serialization/formula identity checks; acceptance/admission inequalities were checked directly. That allowance is neither a new scientific tolerance nor a roundoff certificate. Individual contrast values and a complete per-node attempt history are not serialized in `analytic_selection`; no missing values are filled in.

### R estimates and observed RSS, with D ranges

Selector and final API budgets are R **536,870,912 bytes (512 MiB)**. A's final API estimate adds three canonical CSR buffer totals to its selector estimate; B uses its grouped estimator at both layers. C has only a direct-table API estimate. For C2/A/r1, the R selector/final estimates are **398,369,384 / 512,218,352 bytes**. The table shows D min–max summaries of the three R primary process values only; verifier snapshots are retained separately and are not pooled.

| Target / representation | D range: selector estimate | D range: final API estimate | D range: observed pipeline peak RSS |
| --- | ---: | ---: | ---: |
| C1 / PBMC-S/A | 163,924,808–164,326,216 | 169,872,500–170,273,908 | 94,502,912–95,031,296 |
| C1 / PBMC-S/B | 181,454,796–181,868,492 | 181,454,796–181,868,492 | 94,744,576–95,236,096 |
| C1 / PBMC-S/C | Not applicable | 177,082,884–177,299,972 | 101,314,560–101,535,744 |
| C2 / PBMC-L/A | 398,217,832–398,393,960 | 512,066,800–512,242,928 | 238,239,744–238,424,064 |
| C2 / PBMC-L/B | 451,808,520–451,882,248 | 451,808,520–451,882,248 | 238,579,712–239,841,280 |
| C2 / PBMC-L/C | Not applicable | 495,959,488–496,090,560 | 256,655,360–256,839,680 |
| C3 / Mouse-S/A | 159,605,664–160,023,456 | 164,038,080–164,455,872 | 91,639,808–92,307,456 |
| C3 / Mouse-S/B | 175,814,912–175,999,232 | 175,814,912–175,999,232 | 92,499,968–92,549,120 |
| C3 / Mouse-S/C | Not applicable | 171,871,024–171,989,808 | 98,213,888–98,316,288 |
| C4 / Mouse-L/A | 324,480,840–324,849,480 | 404,821,908–405,190,548 | 194,797,568–194,842,624 |
| C4 / Mouse-L/B | 370,141,964–370,326,284 | 370,141,964–370,326,284 | 194,990,080–195,235,840 |
| C4 / Mouse-L/C | Not applicable | 390,378,116–390,742,660 | 207,765,504–208,265,216 |

Observed peaks are original `real_performance_results.csv` values: main-child PID VmRSS/VmHWM from launch through exit, excluding summed descendants and separate verification. Neither estimate is measured RSS; neither the baseline labels nor sampled peaks certify instantaneous whole-system memory. `baseline_live_bytes` and `baseline_high_water_bytes` are separate recorded labels from a high-water-based mechanism. The original 1e-6 matrix/product and 1e-8 original-target triplet criteria are unchanged.


Table S2 preserves final target sizes, nonzeros, depth diversity, nodes and clipping counts. Table S3 preserves displayed rounded maxima and all-final-criterion counts, not a replacement for continuous scalar tables. Table S4 reports construction-plus-PCA seconds as median [minimum, maximum] over technical processes; it is not complete workflow elapsed time. Fast BPCells remains visible as a different precision setting, not a final-precision-equivalent speed winner. Table S5 reports permanent operator-array bytes, not total memory. The exact storage denominator and all exclusions are retained in the main text and evidence map.

## Preserved confirmatory campaign settings

The following settings/accounting are copied from V3.1 §§4.2–4.4 with headings and the relocated table reference adjusted. They describe the saved biological confirmatory campaign, not any execution in this V2 task or the later clean-install tutorial. No parameter, threshold, observation or timing was recomputed. All five scientific tables above remain the verbatim source blocks.


The later evaluation used two prespecified 10x resources: Human PBMC 10k Chromium X, Cell Ranger 6.1.0, and Adult Mouse Brain Nuclei NextGEM 10k, Cell Ranger 8.0.0. The raw HDF5 matrices had 36601×11996 and 33696×9684 features×observations, respectively. The molecule_info file was excluded.

They were acquired manually and admitted under documentary amendment A1, explicitly approved by Mohamed Kone on 14 November 2026 UTC. Local integrity/schema/integer-count checks succeeded. Dates, durations, redirections and HTTP receipts were not retained; the exact Mouse transfer URL remains unknown and its absence was explicitly accepted. The investigator declared no intentional content modification, a statement that is not independent authentication of external origin. A1 changed documentary eligibility only; numerical criteria, methods, parameters and the original protocol remain unchanged.

Observation order was SHA-256 of the UTF-8 prefix NBPEARSON-CONFIRMATORY-V1| followed by the exact barcode, ties by exact identifier. Each resource supplied a small target of its first 1000 ordered observations and 1000 positive Gene Expression features, and a larger target of its first min(10000, available) observations and 2000 such features, ordered by stable feature ID. Positivity was assessed on each target's observations. Only zero margins after selection were removed; excluded indices were retained, without replacement. One zero row was removed from the larger PBMC target; no selected columns or other rows were removed.



These are four targets from two sources not used for development of the frozen numerical core, with nested small/large observation selections and separately defined final gene sets and margins. The largest new target is 9,999 × 2,000. They are not four independent cohorts, do not establish generalization across donors and do not support atlas-scale speed or accuracy claims. The primary settings were \(\theta=100\), \(c=\sqrt N\), matrix_rtol=10⁻⁶, max_nodes=128 and the first 16 disjoint adjacent pairs. Margins were calculated once on each final target, frozen, and passed unchanged. Scanpy's recalculated margins agreed; R parameter exports round-tripped bitwise.

### Native comparators and accuracy criteria

All six arms were retained: the three nbpearson representations, official Scanpy Pearson-residual PCA, and BPCells slow=FALSE/TRUE. Scanpy received float64 counts, explicit theta/clip, mask_var=None, no HVG selection or gene standardization. In genes×observations orientation, BPCells received linear gene_beta=p, cell_read_counts=n, constant gene_theta, columns_are_cells=TRUE, min_var=0 and symmetric clip_range. Centering was applied explicitly through native operations after clipping, without relying on ignored center/scale options of its SVD. No SCTransform parameter fit was added.

SciPy ARPACK requested 21 triplets, retaining 20, with ncv=64, tol=10⁻¹⁰, maxiter=10000 and Gaussian v0 seed6619. Scanpy used its official sklearn/ARPACK path, tol=0 and native initialization; ncv/maxiter were not exposed. BPCells used native Spectra, k=nu=nv=21, ncv=64, tol=10⁻¹⁰, maxitr=10000 and set.seed(6619). These are native pipelines, not a same-solver or identical-start comparison.

<a id="ea-f3"></a>
### EA-F3 — Native solver interpretation

The settings above retain nbpearson SciPy ARPACK `tol=1e-10`, Scanpy/sklearn ARPACK `tol=0`, and BPCells native Spectra `tol=1e-10`. nbpearson used an explicit Gaussian NumPy starting vector; sklearn retained native initialization and R used `set.seed(6619)`. Equal seed integers do not imply identical starts. Nominal tolerances alone do not order solver effort. These configurations support no same-solver or causal cross-runtime ranking of operator efficiency. [Saved native controls, version scope and source identities](verification/SOLVER_RELIABILITY_SOURCE_RECORDS.json) remain distinct from independent accuracy checks.

The independent direct reference used 256-row binary64 residual blocks, stable mean accumulation and a two-pass centered norm. No whole-matrix dense oracle was built. The small admitted official Scanpy candidate itself materialized dense residuals. Each target had a fresh direct ARPACK reference whose 20/21 triplets were independently gated.

Frozen thresholds were relative matrix and four-product error ≤10⁻⁶; aggregated triplet residual ≤10⁻⁸; singular-value relative error ≤10⁻⁶; and maximal subspace angles ≤10⁻⁶ rad when the gap criterion permitted interpretation. Both \(Av-\sigma u\) and \(A^\top u-\sigma v\) were checked against the target. The gap criterion was \(s_{20}-s_{21}>2e_{\rm matrix,abs}+\max(e_{Av},e_{A^\top u})\). Adjoint and centering diagnostics were separately normalized. Exactly zero references have undefined relative error and a named absolute criterion of 10⁻¹², with no denominator epsilon. Orthogonality was reported separately.

Eight native R matrix checks—four targets × two modes—were reused across 24 R pipeline repetitions, three per target/mode. These repetitions are technical process repetitions, not independent datasets or 24 independent R matrix checks. Saved products and triplets were checked individually for every completed pipeline. Only the last output array of each ten-call product lot was saved; all individual durations were retained. Direct binary64 and agreement of small Decimal 80/160-digit oracles are not interval certificates.

### Timing, memory and bounded execution

Three fresh processes were planned per arm/target: 72 pipelines in a real-only order shuffled once with random.Random(71306) before its first run. No pipeline warm-up was performed. Fixed products followed PCA, using normalized Gaussian probes seed71305, one warm-up and ten calls for each direction and width-eight block. Finitude checks were outside both Python and R timers. Products ran inside their native runtime without restarting R for each multiplication.

Loading, construction, PCA, products, export, whole-process elapsed time and verification were separated. Construction included validation, count copying/fingerprinting, fixed-margin binding, grouping, node selection, factors/background and centering as applicable. Python recorded a construction+PCA interval; R summed construction and SVD sub-times. R proc.time has coarser resolution than Python perf_counter. Installation and acquisition were not benchmark costs. For the EA-F3 interpretation, construction-plus-PCA excludes loading, product batches, export and independent verification; the broader launch-to-exit RSS boundary below includes runtime/import baselines. Native clock resolution and allocator baselines remain confounds.

The process watchdog sampled main-PID VmRSS/VmHWM every 50 ms from launch through exit for both runtimes, including imports, loading, products and export; verification was separate. This is a matched nominal boundary, not equality of runtime baselines or an instantaneous bound on unseen allocations. Descendant RSS was not summed. Each process had one numerical thread, a 512-MiB RSS cap and 300-s whole-process wall limit, additionally bounded by the remaining 1800-s cumulative allowance.

The saved cumulative total was 532.2440518923686 s, comprising 50.19525759114185 s already counted and 482.04879430122674 s of new guarded work, including preserved failures and report/documentary checks. No time or RSS stop occurred. Host metadata observed before this real campaign reports an Intel Core i5-12500H, Linux and 16087840 kB MemTotal; competing workload, power and frequency were not fully controlled. This observation does not establish hardware or conditions for the earlier campaigns.

## Functional tutorial and adverse-evidence boundaries

The later clean-install tutorial used only the documented 16 × 3 rank-one fixture. Its null-action tolerance is 1e-11 absolute, distinct from the scientific campaign's 1e-12 zero-reference rule above. It performed one external k=1 ARPACK calculation per representation, not the scientific campaign's 21 computed/20 retained triplets. Source, fixture, expected outputs, theta=100, clip=10 and all existing assertions were unchanged. A fresh offline dependency installation succeeded; earlier dependency-reuse smoke and blocked online installation remain separate historical phases. See [clean-install synchronization](../nbpearson_gigascience_author_revision_v3/CLEAN_INSTALL_SYNCHRONIZATION.md) for exact receipts/hashes and the unauthenticated wheel-acquisition limitation. No tutorial or numerical import was run in V2.

<a id="ea-r1"></a>
### EA-R1 — Existing refusal-versus-variation case

An existing autonomous test illustrates why a refused analytic selection must not be interpreted as absence of variation in the target. Its four-observation count fixture has identical rows within each adjacent pair but different profiles between pairs. The selected pair contrasts therefore give L=0 while the centered fixed-NB target is nonzero. A/B correctly raise `SelectionError` with `insufficient_norm_bound`; this reports insufficient information for their analytic selection rule, not a zero matrix. On this small admitted fixture, explicitly requested C agrees with the independent direct target under the test's existing assertion. No automatic fallback is made, and C is not a general recovery strategy when its table cannot be admitted. The passing test supplies assertion-level evidence; individual error values were not saved. Analytic selection, observed arithmetic and solver convergence remain separate, and `floating_validation=NOT_EVALUATED` is preserved.

The unchanged `test_L_zero_nonzero_target_and_exact_zero` is recorded as `ok` in the saved release test receipt (13 passes/four historical skips). This source/pass-backed case is separate from the preceding 16×3 clean-install tutorial. No per-case error/norm transcript or new advanced tutorial is supplied. [Test source and receipt identities](verification/SOLVER_RELIABILITY_SOURCE_RECORDS.json) are retained.

The original synthetic stress retained 27 technical pipelines at N=2048, G=512 and U_d=16/256/2048, with 40 positive counts per row. At U_d=N, B's permanent arrays exceeded A's; exact-grouped storage increased with distinct-depth count. These saved stress observations are computational loads, not independent biology or a causal isolation of depth diversity. Historical Python and native-R timings remain separate sessions; the 46,769-row spatial target is observations/barcodes or spatial bins, not automatically cells.

The twelve fast BPCells pipelines passed later-real matrix/four-product criteria but exceeded the stricter retained-triplet threshold; nine angle checks missed their criterion and three larger-Mouse checks passed. Eight R matrix proofs were reused across 24 technical pipelines. Only the final output of each ten-call product batch was saved for numerical verification. Slow BPCells and completed Scanpy runs passed the recorded final criteria. Two Scanpy preflight refusals plus four nonlaunches are not observed OOMs or numerical failures. No missing time/error/RSS was imputed.

The original preparation/thread-pool, R metadata-serialization and report-writer incidents, their corrections and charged times remain in the frozen records. Current source-to-display audits and figures retain unfavorable values and nonexecutions. Moving material here does not erase partial A1 provenance, source reuse/ethics questions, runtime/solver differences or pending human figure approval. The [claim map](../nbpearson_gigascience_author_revision_v3/EVIDENCE_AND_CLAIM_TRACEABILITY.md) and [reviewer-access plan](../nbpearson_gigascience_author_revision_v3/AUTHOR_APPROVAL_AND_PUBLICATION_GATES.md) identify the exact source records and remaining legitimate-access requirements.

## Supplementary figure legends (existing evidence)

These retain the proposed Supplementary Figures S1–S5 captions/alt text from the earlier preparation; numerical values and graphics are unchanged. Human visual/scientific approval remains pending.

### Supplementary Figure S1 — All four real-data product costs

**All four complete fixed-product costs in the later real campaign.** The same four targets, six arms and method symbols as the main composite are shown for (a) vector, (b) transposed vector, (c) width-eight block and (d) transposed width-eight products. Each small mark is a saved process mean over ten timed calls after one warmup; larger outlined marks are the saved medians of three process means. Only the final output of each ten-call batch was saved for numerical verification; this plot does not imply ten independent verified outputs. Time is shown in milliseconds on logarithmic axes, with direction- and target-specific ranges; no speed ratios or cross-session comparisons are constructed. B’s median transposed width-eight cost is higher than A’s on all four targets. C2/C4 Scanpy remain categorical preflight/nonlaunch states. † Fast BPCells has a distinct final precision outcome: it meets matrix/four-product criteria, while its twelve completed pipelines exceed the stricter 10⁻⁸ retained-triplet criterion. Three process repetitions are technical repeats of each fixed target. Historical development, the original synthetic campaign and later real timing are kept separate.

Alt text: Four rows display forward and transpose vector and width-eight product times. Small marks show saved technical process means and large marks saved medians. Grouped interpolation has higher transposed width-eight cost on every target.

### Supplementary Figure S2 — Absolute errors and reference norms

**Absolute numerical errors and reference norms from the later real campaign.** The four panels retain saved matrix absolute error, target Frobenius norm, forward triplet residual norm and transpose triplet residual norm. Target/method symbols match Figure 3. Matrix/reference-norm quantities are not the denominator of the triplet contract, which uses the retained singular-value norm. Reference norms are displayed once per configuration; reused native R matrix proofs are not treated as independent repetitions. No universal absolute threshold is inferred from relative criteria. Scanpy C2/C4 have categorical nonexecution records and no invented error points. This companion preserves continuous unfavorable values rather than turning precision into a binary ranking. Values are copied from the same frozen 66-pipeline accuracy table; no numerical result was recalculated.

Alt text: Four panels show absolute matrix error, reference matrix norm and both original-target triplet-residual directions, retaining their distinct units. Undefined large Scanpy runs have no numerical point.

### Supplementary Figure S3 — Existing synthetic stress overview

**The existing synthetic depth-diversity stress exposes a storage trade-off.** Saved results comprise nine configurations and 27 technical process repetitions, with N = 2048, G = 512, 81,920 positive entries and 40 positive counts per row. Exact categorical distinct-depth counts are U = 16, 256 and 2048 (U/N = 0.0078125, 0.125 and 1). A and B use 16 interpolation nodes; C is exact-grouped, with no interpolation-node count. Node count is distinct from 20 retained/21 computed PCA triplets. (a) Complete permanent operator-array totals, converted as bytes/2²⁰ to MiB, exclude inputs, temporaries, output buffers and solver memory. At U = N, B uses 1,372,292 bytes versus A’s 1,323,012 bytes. C’s total grows from 1,081,604 to 9,437,188 bytes; these are operator totals, not background-table bytes alone. (b) Saved construction-plus-PCA times, three process points with saved median and saved minimum–maximum segment. (c,d) Saved continuous matrix relative errors and triplet relative residuals; small points show repetitions and large outlined marks their saved maxima. Dashed lines show the recorded 10⁻⁶ matrix and 10⁻⁸ triplet criteria. All 27 saved pipeline statuses satisfy the recorded criteria. Distinct method/repetition positions are categorical display offsets; no intermediate values, connected curves or smoothing are implied. This computational mechanism stress is not biological validation. Margins, clipping, spectra and solver work also vary, so differences cannot be causally attributed to depth diversity alone. Historical development and later real results are separate evidence strata.

Alt text: Three discrete distinct-depth categories show permanent arrays, saved pipeline duration and continuous matrix/triplet fidelity. Grouped interpolation saves arrays at repeated depths but exceeds ungrouped storage when all depths differ. Exact-grouped table storage grows with distinct depths.

### Supplementary Figure S4 — Existing synthetic product costs

**All four fixed-product costs from the existing synthetic mechanism stress.** Saved (a) vector, (b) transposed vector, (c) width-eight block and (d) transposed width-eight times are shown for the same N = 2048, G = 512 configurations at U = 16, 256 and 2048. A, B and C denote interpolated, grouped-interpolant and exact-grouped operators. Small points are the saved process means over ten timed calls after one warmup; larger outlined marks are saved medians over three technical processes. Seconds are multiplied by 1000 for milliseconds. B’s median transposed width-eight cost exceeds A’s at all three observed U values, including where B saves permanent bytes. The three categories are shown without connecting lines, smoothing, inferred intermediate behavior or performance ratios. All 27 pipelines satisfied the recorded criteria; continuous matrix/triplet observations appear in the overview companion. No new synthetic load, benchmark, PCA computation or biological evaluation was performed for these figures. The timings remain within their original synthetic campaign and are not pooled with later real or historical prototype timings. Depth diversity is one of several varying load properties, not an isolated causal intervention.

Alt text: Four panels show all product directions for the same three saved synthetic categories. Grouped interpolation has higher transposed width-eight cost at all categories. No curves or intermediate measurements are implied.

### Supplementary Figure S5 — Historical development, separate sessions

**Historical development evidence in separate execution sessions.** (a,b) Saved maximum relative matrix error for each dataset/method configuration; dashed line, 10⁻⁶ matrix criterion. (c,d) Saved construction-plus-PCA median (open symbol), minimum–maximum (whisker) and all three individual technical timings (dots, slightly offset for visibility). Timing axes differ. Values and summaries are copied from the frozen historical comparison table; no errors, medians, PCA or benchmarks were recomputed. Python and native R columns describe different sessions, solvers, initializations and measurement boundaries; they support no cross-session speed ratio or pooled ranking. Python comprises ten configurations/30 pipelines (A/B/C on three targets and Scanpy on spatial small); native R comprises six configurations/18 pipelines (two BPCells modes on three targets). Scanpy's absent PBMC/full-spatial configurations have no fabricated zero. Native R fast meets the matrix criterion on PBMC but exceeds it on both spatial targets; none of the nine historical fast-mode pipelines meets all saved final precision criteria. This operating-point result is not a claim of general inaccuracy. Python RSS excludes independent verification whereas native R RSS includes direct verification; neither RSS nor separate product timings are plotted here. Constructor-plus-PCA timing excludes loading, products, export and verification and is not an end-to-end runtime. Spatial small (2,000 × 1,775) is a target within the historical spatial resource; full spatial (46,769 × 2,000) belongs to this development stratum. These observations are not pooled with later confirmatory or synthetic-stress evidence and establish no independent atlas-scale validation. Source IDs, complete original fields, timing/RSS scopes and plotted-cell mappings accompany the figure.

Alt text: Four panels keep historical Python and native R sessions separate. Matrix errors and saved timing repetitions are shown without cross-session ratios. Spatial target rows are observations/barcodes or spatial bins; the 46,769-row target is historical development evidence.


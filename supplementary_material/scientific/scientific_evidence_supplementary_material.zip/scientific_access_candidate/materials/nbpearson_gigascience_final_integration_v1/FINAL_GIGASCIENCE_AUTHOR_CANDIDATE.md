# nbpearson: auditable Python operators for fixed negative binomial Pearson-residual principal component analysis

Mohamed Kone¹, Chao Hou¹, Gaoussou Haidara¹, ShuLin Wang¹*  
¹ School of Computer Science and Engineering, Hunan University, Changsha, China.  
*Supplied corresponding-author details: ShuLin Wang; <CONTACT_EMAIL_OMITTED>.

**AI-assisted author-finalization candidate, 16 November 2026 (Asia/Shanghai).** This separate derivative integrates the audited F1–F3 documentary clarifications and the existing reliability-case explanation into GigaScience V3. The investigator-reported four-author project approval is accepted. Exact new changes are listed for author review; no signatures or renewed approvals are invented. Software, historical results, figures and all five original science-table blocks remain unchanged. This is not submission authorization.

## Abstract

**Background:** Fixed negative-binomial Pearson residuals can densify sparse counts. Existing principal component analysis (PCA) tools address this problem, but some Python workflows also need to keep a specified target fixed while inspecting representation costs and numerical errors.

**Findings:** nbpearson 0.1.0.dev1 binds margins to canonical counts and exposes three user-selected representations through the same four vector/block products. Researchers can retain one target, inspect stored arrays and approximation/refusal diagnostics, and separately check an external solver's output. The saved confirmatory campaign planned 72 pipelines and completed 66; all 36 nbpearson pipelines met its criteria. Two sources unused in development supplied four nested targets, largest 9,999 × 2,000 observations × genes. Grouped interpolation saved 5.39–8.36% of complete ungrouped operator-owned permanent arrays, excluding input, temporary and solver memory. Runtime and process-memory gains were not uniform; grouped width-eight transpose products were slower on all four targets. A clean offline NumPy 2.5.4/SciPy 1.18.1 installation reproduced the 16 × 3 synthetic tutorial.

**Conclusions:** The supported use is inspectable operator construction and validation within an in-memory Python workflow. The evidence demonstrates numerical fidelity and modest array savings, not unique PCA functionality, superior biological inference or reduced analyst effort. Limited source diversity, acquisition provenance and native-solver differences constrain interpretation; exact-version review and verified access remain pending.

**Keywords:** Pearson residuals; negative binomial; sparse counts; linear operators; principal component analysis; reproducibility.

## Findings

### The user problem and a concrete workflow

The intended user is a Python analyst or software developer with an in-memory sparse integer-count matrix and a specified fixed-standard-negative-binomial (NB) principal component analysis (PCA) target. A zero count generally has a nonzero residual, so materializing all residuals loses count sparsity. Scanpy already provides an official Pearson-residual PCA pipeline; BPCells offers fixed-parameter NB residuals, backed computation and streaming singular value decomposition (SVD) in R. Other Python implementations also provide implicit residual/PCA functionality [1, 2, 3, 4, 5, 6, 7, 8]. nbpearson does not establish priority for this computation.

Consider an analyst who has finished selecting observations and genes and wants to assess storage and numerical fidelity before retaining PCA coordinates. The analyst binds chosen depths and gene proportions to the canonical counts, then constructs a requested representation with the same margins, theta and clipping. A mismatched count fingerprint is refused. Valid supplied margins are retained rather than silently recomputed; the binding does not establish that the analyst chose scientifically appropriate margins.

The same probes can then be applied through `matvec`, `rmatvec`, `matmat` and `rmatmat`: forward/transpose vectors and blocks. Changing representation changes background storage, not the intended statistical target. The analyst can inspect complete owned-array bytes, node selection and any refusal, then pass the operator to an external SciPy solver and assess its triplets against the original target [9, 10, 11]. The supplied tutorial demonstrates this sequence on a tiny matrix; the saved biological campaign separately exercises original-target checks at larger sizes. It does not make whole-matrix dense checking practical for large inputs.

This is implemented, tested control over a numerical workflow. The demonstrated outcomes are numerical agreement with the declared target and modest array savings in the tested grouped cases. These do not by themselves establish comparative usability. Easier debugging, fewer integration errors or reduced researcher effort are plausible uses, not measured outcomes. A researcher satisfied by Scanpy's pipeline or needing BPCells' backed workflow has no demonstrated reason here to switch. The constructor copies compressed sparse row (CSR) counts into memory; it is not an atlas-scale streaming backend or a new normalization method.

### Fixed target

Let \(X\in\mathbb R^{N\times G}\) contain nonnegative integer counts, oriented observations × genes. For positive fixed depths \(n_i\), gene proportions \(p_j\) and shared finite \(\theta>0\),

\[
\mu_{ij}=n_i p_j,\qquad
R_{ij}=\frac{X_{ij}-\mu_{ij}}{\sqrt{\mu_{ij}+\mu_{ij}^{2}/\theta}},\qquad
T=\operatorname{clip}(R,-c,c),\qquad
A=HT,\quad H=I-\frac{\mathbf1\mathbf1^\top}{N}.
\]

Clipping precedes column centering; genes are not subsequently standardized. The supported finite-clipping domain is \(c\ge\sqrt\theta\); an explicit unclipped mode is separate. Automatic margins are computed once in binary64 on the canonical counts. `FixedMargins` binds supplied binary64 depths/proportions to the canonical count fingerprint, permitting traceable reuse without silent recalculation. Changing the count universe requires an explicit corresponding margin decision. Product-of-margins means are not a general exact NB maximum-likelihood fit [1].

### Choosing and checking a representation

A/B/C are explicit choices for one target, with observation-specific sparse corrections for counts and clipping. They change storage of the dense zero-count background (Figure 1; original formulas in Supplementary Table S1). There is no dispatcher.

| Representation | When to consider it | Main limitation |
| --- | --- | --- |
| A — `interpolated` | Use an ungrouped factorization as the comparison point, especially when few depths repeat. | Stores N×r and G×r factors; interpolation and floating-point error remain. |
| B — `interpolated_grouped` | Consider sharing coefficients when depths repeat exactly and owned-array storage matters. | Stores U_d×r and G×r factors plus grouping metadata; reductions can cost time and grouping can increase total bytes. |
| C — `exact_grouped` | Consider removing interpolation error when a U_d×G background table fits. | Can become N×G when U_d=N; “exact” does not mean exact floating-point arithmetic or automatic speed. |

Here U_d counts exactly distinct binary64 depths, and r is an interpolation-node count, separate from PCA dimension. B constructs the same interpolant at those depths; it does not merge observations or bin nearby depths. Group transpose reductions sum, centering uses group multiplicities, and each observation retains its sparse correction. These details preserve the original observation weights. A/B use established barycentric interpolation [12].

U_d/N alone cannot determine a preferred choice: factor costs also depend on r and gene count, while sparse corrections, metadata, product width/direction and external solver work contribute. The saved biological results show that B saves arrays while its width-eight transpose costs more; the all-distinct synthetic case makes B larger than A. This supports inspecting the relevant costs, not a universal selection rule. The [separate use-case guide](../nbpearson_gigascience_author_revision_v3/DISTINCTIVE_USE_CASE_AND_REPRESENTATION_GUIDE.md) distinguishes measured examples from conceptual guidance.

Diagnostics expose requested/constructed representation, margin binding, clipping, analytic node selection, owned arrays and admission estimates. Invalid counts/margins or clipping, unusable norm contrasts, node ceilings and resource estimates can cause explicit refusal. The maximum application programming interface (API) admission budget is 512 mebibytes (MiB), including the process baseline in its estimate; it is not a resident-set-size (RSS) guarantee or watchdog. Input copies, temporary products and external solver allocations matter.

An existing autonomous test distinguishes L=0 from a zero centered target; its named refusals and assertion-level evidence are explained in [Supplementary EA-R1](SUPPLEMENTARY_DIAGNOSTIC_ADDENDUM.md#ea-r1).

Three accuracy questions remain separate: analytic interpolation selection in exact arithmetic; observed floating-point matrix/products; and convergence/fidelity of external SVD triplets. The computed norm contrast is not a certified lower bound, and `floating_validation=NOT_EVALUATED` remains after external checks. Near-null cancellation and the identity \(A^\top\mathbf1=0\) require absolute-error handling or refusal for zero-reference actions. Supplementary details retain bounds and numerical qualifications; no global floating-point certificate is claimed.

The original selection records retain the norm-pair identities, contrast lower-bound value, interpolation bound, selected node count and admission estimates. Across C1–C4, interpolated A/B selected 48/57/34/40 nodes using 16 original adjacent pairs, matrix tolerance 1e-6 and a 128-node ceiling. Saved scalar state supports the first-admissible-node decision trace, but does not independently validate the original contrasts or certify floating-point fidelity. Selector estimates, final API admission estimates and observed process RSS are separate quantities; `floating_validation=NOT_EVALUATED` remains unchanged. ([Supplementary EA-F2](SUPPLEMENTARY_DIAGNOSTIC_ADDENDUM.md#ea-f2)).

### Reproducible example and clean installation

The supplied tutorial loads the documented 16 × 3 sparse integer fixture, freezes its original margins and explicitly constructs A/B/C. It checks all four products against a tiny independent direct formula and invokes external SciPy ARPACK (ARnoldi PACKage) for one singular triplet per representation. Theta=100 and clip=10 are explicit: the default sqrt(16)=4 is outside this constructor's supported clipping domain. The fixture has two row profiles, one nonzero centered component and no actively clipped entry; it is a functional example, not a numerical stress campaign.

The verification history has three distinct stages: an initial dependency-reuse smoke check; a proxy-blocked online attempt with no tutorial execution; and a successful fresh offline installation. In the last stage, NumPy **2.5.4**, SciPy **1.18.1** and unchanged nbpearson **0.1.0.dev1** loaded from a new isolated CPython **3.12.3** environment on Linux x86-64/glibc **2.39**, without numerical-package links to system/user/earlier installations. `pip check` and all eight recorded stages passed. One invocation reproduced the existing expected outputs, centering and external-triplet checks. Matrix/products at 10⁻⁶ and original-target triplets at 10⁻⁸ remained separate checks [11, 13, 14, 9, 10].

This resolves the local clean-installation condition for the supplied offline wheels and host. Their acquisition/provider chain was not independently authenticated; online availability and general cross-platform compatibility are not established. The earlier failure remains preserved. Neither the earlier V3 revision nor this documentary integration performs an installation or numerical rerun. Exact commands, wheel/source hashes, environment proofs, outputs and chronology are mapped in the [supporting reproducibility record](../nbpearson_gigascience_author_revision_v3/CLEAN_INSTALL_SYNCHRONIZATION.md). Tool-assisted preparation is disclosed under Declarations [15, 16].

### Saved scientific evidence and its limits

The confirmatory campaign used Human PBMC 10k Chromium X and Adult Mouse Brain Nuclei NextGEM 10k [17, 18], two resources not used in core development, with nested small/large observation targets and separately fixed gene sets/margins. The largest final target was 9,999 × 2,000; four target sizes are not four independent cohorts. Of 72 planned pipelines, 66 completed: 36 nbpearson, six Scanpy and 24 BPCells. All 36 nbpearson pipelines passed the recorded criteria; 54 completed pipelines across methods passed every final criterion. Repetitions are technical processes. Eight R matrix checks were reused across 24 R pipeline repetitions; they are not 24 independent matrix checks. Supplementary Tables S2–S5 retain the exact V3.1 cells, and Figure 3 retains continuous errors.

Matrix and four-product relative criteria were 10⁻⁶. For retained triplets, the distinct original-target contract was

\[
\frac{\max\{\|AV-U\Sigma\|_F,\;\|A^\top U-V\Sigma\|_F\}}
{\|s_{\mathrm{retained}}\|_2}\le10^{-8}.
\]

The maximum combines both directions; its denominator is the retained singular-value norm. The reference was an independently evaluated streamed binary64 formula, not an interval oracle. Subspace-angle interpretation used the frozen spectral-gap rule. Convergence alone did not establish fidelity. BPCells `slow=FALSE` passed matrix/products but exceeded this manuscript's stricter triplet criterion in all twelve completed pipelines; slow mode and the completed Scanpy runs passed final criteria. For users, matrix/product agreement and solver completion do not replace checking the required original-target triplet contract. This describes the tested precision settings, not general BPCells inaccuracy. Nine fast-mode angle checks exceeded their threshold; the three larger-Mouse angle checks passed.

Grouped interpolation saved **5.39–8.36%** using **100×(A_bytes−B_bytes)/A_bytes**, where A_bytes is the complete ungrouped operator-owned permanent-array total. Input counts, construction/product temporaries, outputs and solver memory are excluded. These are not total-memory savings. The stored correction mean `C_mean` (8G bytes) is already included in these totals ([Supplementary EA-F1](SUPPLEMENTARY_DIAGNOSTIC_ADDENDUM.md#ea-f1)). B's construction-plus-PCA median was lower only for the small PBMC target, its maximal observed process RSS was slightly higher on all four targets, and its transposed width-eight product median was higher on all four. Figure 2 separates these quantities; construction-plus-PCA excludes loading/products/export. For users, sharing background coefficients is therefore a storage trade-off, not an expectation of lower total RAM or faster PCA. These are native pipelines: nbpearson uses SciPy ARPACK `tol=1e-10` with an explicit Gaussian start, Scanpy uses its official sklearn/ARPACK path with `tol=0` and native initialization, and BPCells uses native Spectra. Equal seed integers do not ensure identical starts. Construction-plus-PCA boundaries and clocks differ; no causal cross-runtime ranking follows ([Supplementary EA-F3](SUPPLEMENTARY_DIAGNOSTIC_ADDENDUM.md#ea-f3)).

Six planned large-Scanpy runs were uncompleted: two conservative preflight refusals and four subsequent nonlaunches. They are not observed out-of-memory failures and have no imputed completion time or speed ratio. Existing synthetic stress separately retains the adverse all-distinct-depth case, where grouped metadata makes B larger than A. Historical PBMC and spatial development remain separate strata; the 46,769 × 2,000 spatial target consists of observations/barcodes or spatial bins, not automatically cells, and is not independent confirmation at that scale [19, 20]. Supplementary Figures S1–S5 retain product costs, absolute errors, stress and historical sessions.

Acquisition was admitted under amendment A1 with investigator attestation and explicit missing transfer history, including the exact Mouse transfer URL. Local hashes establish preservation, not provider authentication. These two sources do not establish atlas-scale accuracy, inter-donor generalization or downstream biological benefit. Harness incidents, unfavorable results, source caveats and nonexecutions remain in the preserved evidence and reviewer-access inventory. No new scientific campaign was conducted for this revision.

### Scope of the comparison

Analytic Pearson residuals and implicit computation precede nbpearson [1]. Saved executions used Scanpy 1.12.5 and BPCells 0.3.1; later pinned-source inspections are not new benchmarks. Scanpy 1.13.0's inspected Pearson-PCA path materializes dense residuals. BPCells' existing fixed-NB/backed functionality is credited above; its official package citation and methods preprint are distinct [2, 3, 4, 5, 6]. Experimental Python-binding scope is not evidence that other Python workflows are absent.

sparse-count-pca v1.0.0 provides implicit PCA/AnnData integration; its scaled-NB variance generally differs at heterogeneous depths and its backed sparse canonicalization loads counts into memory. anndataoom 0.1.9 provides lazy Python fixed-NB components; their apparent centered-PCA composition and float32 behavior were not qualified here against the strict criteria [7, 8]. No superiority over those tools is demonstrated. nbpearson's additional utility is the documented combination of explicit representations, bound-target products, diagnostics and reproducibility records for the stated workflow; uniqueness, comparative usability and biological gains are unestablished.

## Availability of source code and requirements

- **Project/version:** nbpearson 0.1.0.dev1; frozen commit `c0f41107f888d69713c8e22e488bf1e7386f8c4d`, 23 approved files [11].
- **Operating system/language:** the tested host was Linux x86-64; implementation language is Python. General cross-platform compatibility remains unverified.
- **Runtime:** Python; metadata requires >=3.10. Clean verification used CPython 3.12.3, NumPy 2.5.4 and SciPy 1.18.1 on Linux x86-64/glibc 2.39. No cross-platform support matrix is inferred.
- **Original-code licence:** MIT, Copyright (c) 2026 Mohamed Kone, based on his explicit ownership/distribution-authority statement. Dependencies retain their licences. Scientific-material and external-data rights remain separate human-review matters.
- **Homepage:** https://github.com/mohkone/nbpearson (private; not a reviewer/public route). RRID/bio.tools registration, if applicable, remains unverified; no identifier is supplied.
- **Access:** the saved authenticated owner-access check from 16 November 2026 records the repository private at the frozen reference; reviewer access was not tested. Code, local wheel, synthetic fixture, expected outputs and offline receipts are preserved locally. Verified reviewer access and an archival identifier for this candidate remain pending. No release, DOI or registration identifier is invented.

The [smaller proposed reviewer-access plan](../nbpearson_gigascience_author_revision_v3/REVIEWER_REPRODUCIBILITY_PACKAGE_PLAN.md) separates exact software, the synthetic example and clean-install receipts, scientific summaries/figures/protocols, biological acquisition/preprocessing instructions, and relevant failures/amendments. Later sharing requires authorized recipients/access verification and privacy/rights review. This revision creates no invitation, upload, archive or visibility change.

## Data Availability

Saved scalar results, figure source tables/scripts, unchanged figures and protocols support this candidate. All five V3.1 table blocks are preserved verbatim as Supplementary Tables S1–S5 in the [integrated supplementary companion](SUPPLEMENTARY_DIAGNOSTIC_ADDENDUM.md), with a [source-hash/placement map](verification/SCIENCE_TABLE_IDENTITY.json). Main Figures 1–3 and Supplementary Figures S1–S5 retain the earlier graphic files; human visual/scientific approval at final publication dimensions is requested, not assumed.

Raw biological matrices are not bundled with the software example. Official PBMC/Mouse resource pages and recorded artifact identities provide access instructions [17, 18]; they do not repair A1's historical transfer gaps. Historical reuse terms and any matrix/derivative redistribution require human confirmation. A rights-aware evidence access route and permanent identifiers have not been verified. This statement must be completed before submission, rather than presented as a fulfilled open-access obligation.

## Declarations

The investigator reports four-author project approval. The source declarations below retain their record-specific qualifications; they do not reopen collective project approval. This derivative records exact documentary changes for review, without inventing signatures, personal forms or renewed approvals.

### Ethics approval and consent to participate

**Pending human record.** Investigators must supply the secondary-data ethics/consent determination, appropriate approval/waiver or supported non-applicability explanation and responsible-body/reference details. The absence of new recruitment and availability of public data do not by themselves establish an ethics exemption.

### Consent for publication

**Pending human determination** of applicability and permissions for the actual materials. No consent, exemption or permission is invented.

### Competing interests

**Pending individual author confirmation and forms.** Earlier lead-investigator statements reported no conflicts; they remain attributed statements, not current individual declarations.

### Authorship and contributions

**Pending each human author's confirmation.** Supplied names, affiliation/contact and earlier human-role statements remain for review. Final authorship/order, CRediT roles, correspondence/ORCID details and responsibility for this exact candidate need explicit records. AI tools are not authors, coauthors or scientific contributors and receive no CRediT role. Automated audits and AI reviews are not independent human validation or approval.

### Acknowledgements: factual AI-use disclosure

Human acknowledgements/permissions remain to be confirmed. OpenAI ChatGPT and Codex were used as tools, as reported in the investigator's earlier disclosure; Codex was used for V2 and this targeted V3 text and documentary checks [15, 16]. This is factual tool-use disclosure, not scientific contributor credit or thanks assigning responsibility to an AI system. No AI is credited as a contributor in Acknowledgements.

### Funding

**Pending human confirmation.** The earlier lead-investigator statement reported no funding; support, identifiers and relevant arrangements require confirmation for the final manuscript.

### End-of-paper AI-use summary and human responsibility

Reported historical uses include planning/literature discussion, code/testing/workflow assistance, interpretation, documentation and editing. Current V3 use comprises targeted workflow/representation explanations, evidence classification, manuscript editing, a smaller proposed reviewer-material selection, policy review and documentary identity audits. Earlier figure-code/caption and tutorial/code assistance are separately inventoried. No new figure or numerical experiment was generated in V3.

The current session describes Codex as GPT-6 based; an exact deployment/build identifier is not independently recorded. Historical model/version/user-session metadata were not consistently retained and are not reconstructed. Authors must check known dates/uses, affected outputs and gaps. V3 is dated 16 November 2026 in Asia/Shanghai; offline PASS receipts retain actual 15 November 2026 UTC timestamps.

Humans must independently verify, revise as needed and approve the scientific presentation and disclosure, affirm responsibility, and approve relevant AI-generated/revised supplementary outputs after privacy/rights review. Tool citations, Acknowledgements/cover-letter disclosure and the relevant open-output supplement require journal/OUP completion. No private transcript, AI output or author communication was uploaded; no supplement identifier or policy-compliance exception is claimed.

For this final evidence integration, Codex with collaborating agents assisted with the approved documentary insertions, source/claim checks, change mapping and identity audits, directed by Mohamed Kone on 16 November 2026. No new figure, numerical experiment or advanced tutorial was produced. The historical AI-use disclosure and unknown model/version metadata above are retained; this assistance supplies no human scientific-verification or exact-version approval record [15, 16].

## Abbreviations

API: application programming interface; ARPACK: ARnoldi PACKage; CPU: central processing unit; CSR: compressed sparse row; MiB: mebibyte (2²⁰ bytes); NB: negative binomial; PCA: principal component analysis; RSS: resident set size; SVD: singular value decomposition.

## References

Software/version references are distinct from software articles and preprints. Current source inspection is not a new competitor execution. The private software and AI-tool metadata entries require final human bibliographic/access completion.

1. Lause J, Berens P, Kobak D. Analytic Pearson residuals for normalization of single-cell RNA-seq UMI data. *Genome Biology*. 2021;22:258. [doi:10.1186/s13059-021-02451-7](https://doi.org/10.1186/s13059-021-02451-7).

2. Wolf FA, Angerer P, Theis FJ. SCANPY: large-scale single-cell gene expression data analysis. *Genome Biology*. 2018;19:15. [doi:10.1186/s13059-017-1382-0](https://doi.org/10.1186/s13059-017-1382-0). The later Pearson-PCA interface requires its own documentation.

3. Scanpy development team. Scanpy 1.13.0, source commit 3962176e93ba148bc0f61443c517877d736f2b3b. Official source and release provenance. https://github.com/scverse/scanpy/tree/3962176e93ba148bc0f61443c517877d736f2b3b ; https://pypi.org/project/scanpy/ . Source review 15 November 2026; not an executed benchmark version.

4. Parks B, Abdi I. BPCells: Single Cell Counts Matrices to PCA. R package version 0.3.1; software citation recommended by its authors, 2025. [Official citation page](https://bnprks.github.io/BPCells/authors.html), accessed 15 November 2026. This software citation is distinct from the methods preprint below and is not assigned its DOI.

5. Parks B, Greenleaf W. Scalable high-performance single cell data analysis with BPCells. bioRxiv [preprint], version 1, posted 1 April 2025. https://doi.org/10.1101/2025.03.27.645853 . Consulted preprint record: https://pubmed.ncbi.nlm.nih.gov/40236161/ . This citation identifies the preprint edition, separately from the package; it makes no claim about absence of a later article.

6. BPCells authors. Version 0.3.1 documentation for [sctransform_pearson](https://bnprks.github.io/BPCells/reference/sctransform_pearson.html) and [svds](https://bnprks.github.io/BPCells/reference/svds.html). Inherited consultation: 13 November 2026; native execution receipts establish the installed functions.

7. sparse-count-pca developers. sparse-count-pca v1.0.0. Source commit d1438169f82e01a9e090493255ca6ad60bb7d9d5. https://github.com/jgarthur/sparse_count_pca/tree/d1438169f82e01a9e090493255ca6ad60bb7d9d5 . Source review 15 November 2026; software/documentation evidence, not a matched-target benchmark.

8. anndataoom developers. anndataoom 0.1.9. Source commit 04eeeb14fda85309df80ce3b176d5b6bca2637f1. https://github.com/omicverse/anndata-oom/tree/04eeeb14fda85309df80ce3b176d5b6bca2637f1 . Source review 15 November 2026; beta software, no new execution here.

9. SciPy community. SciPy, version 1.18.1 [software]. https://scipy.org/ . Tested version and exact supplied-wheel identity are recorded in the offline-installation receipts; the software article is cited separately.

10. Virtanen P, Gommers R, Oliphant TE, et al.; SciPy 1.0 Contributors. SciPy 1.0: Fundamental Algorithms for Scientific Computing in Python. *Nature Methods*. 2020;17:261–272. [doi:10.1038/s41592-019-0686-2](https://doi.org/10.1038/s41592-019-0686-2).

11. Kone M. nbpearson: explicit negative-binomial Pearson-residual linear operators. Version 0.1.0.dev1; commit c0f41107f888d69713c8e22e488bf1e7386f8c4d. https://github.com/mohkone/nbpearson . Private source reference, authenticated readback 16 November 2026 (Asia/Shanghai). Public/reviewer access and an archival software citation remain pending; no DOI is supplied.

12. Berrut JP, Trefethen LN. Barycentric Lagrange Interpolation. *SIAM Review*. 2004;46(3):501–517. [doi:10.1137/S0036144502417715](https://doi.org/10.1137/S0036144502417715).

13. NumPy community. NumPy, version 2.5.4 [software]. https://numpy.org/ . Tested version and exact supplied-wheel identity are recorded in the offline-installation receipts. External wheel-acquisition provenance is not independently authenticated.

14. Harris CR, Millman KJ, van der Walt SJ, et al. Array programming with NumPy. Nature. 2020;585:357–362. https://doi.org/10.1038/s41586-020-2649-2 . Primary article metadata checked 16 November 2026 (Asia/Shanghai).

15. OpenAI. ChatGPT [generative AI tool]. https://chatgpt.com/ . Historical use reported by Mohamed Kone; exact model/version, response dates and complete session metadata were not consistently recorded. Affected outputs and known preparation dates are retained in the AI-use inventory; author verification is pending.

16. OpenAI. Codex [AI-assisted coding tool]. https://openai.com/codex/ . Recorded V2/V3 use: Mohamed Kone, 16 November 2026 (Asia/Shanghai). Session described as GPT-6 based; exact deployment/build unrecorded. Historical metadata gaps remain explicit. OpenAI is cited as tool provider, not as a scientific author of this manuscript.

17. 10x Genomics. Human PBMC 10k Chromium X, Cell Ranger 6.1.0 dataset resource. https://www.10xgenomics.com/datasets/10k-human-pbmcs-3-ht-v3-1-chromium-x-3-1-high . Current resource/rights check 15 November 2026; not a historical transfer receipt.

18. 10x Genomics. Mouse Brain NextGEM 10k, Cell Ranger 8.0.0 dataset resource. https://www.10xgenomics.com/datasets/10k-Mouse-Brain-CNIK-3p-nextgem . Current resource/rights check 15 November 2026; exact historical transfer URL remains unknown.

19. NCBI Gene Expression Omnibus. [GSM8594567: P1 Human Colon Cancer](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM8594567). Official sample record, 2025; links GSE280315/GSE280318.

20. Faria de Oliveira M, Romero JP, Chung M, et al. High-definition spatial transcriptomic profiling of immune cell populations in colorectal cancer. *Nature Genetics*. 2025;57(6):1512–1523. [doi:10.1038/s41588-025-02193-3](https://doi.org/10.1038/s41588-025-02193-3). Cited for the historical source, not as replicated biological evidence.

## Figure legends

The existing graphic files are unchanged. The following captions/alt text are retained from the earlier author-review package; human source-to-display and visual approval at final size is requested. No automatic approval or new rendering is asserted. Supplementary figure legends remain with the reproducibility companion.

### Figure 1 — Existing operator architecture

The fixed negative-binomial Pearson-residual target is exposed through three manually selected representations. Sparse correction C=S+D is shared; background anchoring and gene-wise centering preserve the stated target in exact arithmetic. A stores N×r and G×r background factors. B directly constructs the U_d×r factor at exactly repeated binary64 depths, retaining group indices and multiplicities; its transpose sums within groups and centering uses multiplicities. C caches a U_d×G background table without interpolation error, while arithmetic remains floating point. If U_d=N, that table becomes N×G. No observations or counts are aggregated. All paths expose four real vector/block products to an external solver. The interpolation-node count r is separate from retained PCA dimension. Analytic selection and resource admission estimates do not certify floating arithmetic, solver accuracy or whole-process RSS. Construction retains floating_validation=NOT_EVALUATED. Background dimensions exclude sparse correction, means, input arrays, construction/product temporaries and external solver memory. Finite clipping requires c≥sqrt(theta); an unclipped path is also supported. This is a schematic of existing implementations, with no measured performance ordinate or new algorithm.

Alt text: Sparse counts and fixed margins feed one clipped, column-centered NB target. Three manually selected representations share sparse corrections and expose four products to an external solver. Diagnostics distinguish exact-arithmetic bounds from unverified floating behavior.

### Figure 2 — Permanent arrays, timing and process RSS

**Permanent-array savings without uniform time/RSS gains.** Four nested targets come from two sources, with maximum size 9,999 × 2,000. A/B/C are interpolated/grouped-interpolant/exact-grouped operators. (a) Complete operator-owned permanent arrays; B saves 5.39–8.36% relative to A (graphic: 5.4–8.4%). This excludes counts, temporaries, outputs and solver memory. BPCells native storage is unexposed. (b) Three technical process times, saved median (large mark) and minimum–maximum segment for construction plus PCA; loading and other phases are excluded. (c) Three observed process peaks, saved range and maximum (large mark); crosses show separate import baselines. RSS samples the main PID from launch to exit, excludes descendants and independent verification, and is not estimated from arrays. B improves pipeline median only on C1 and has slightly higher maximum RSS on all four targets. C2/C4 Scanpy had preflight refusals and subsequent nonlaunches, not observed OOMs. † Fast BPCells passes matrix/products but exceeds the stricter triplet criterion. Native solver settings and measurement scopes differ: nbpearson uses SciPy ARPACK `tol=1e-10` with an explicit Gaussian start, Scanpy uses its official sklearn/ARPACK path with `tol=0` and native initialization, and BPCells uses native Spectra. Construction-plus-PCA excludes loading, product batches, export and independent verification. Process RSS covers a broader launch-to-exit interval and includes runtime/import baselines. These observations support no same-solver or causal cross-runtime speed ranking. Repetitions are technical, not independent datasets.

Alt text: Four nested targets compare permanent arrays, construction-plus-PCA time and process RSS. Grouped interpolation saves arrays without uniform time/RSS gains. Missing large Scanpy runs are labelled preflight; BPCells storage is unexposed. RSS import baselines are separate crosses.

### Figure 3 — Continuous numerical fidelity

**Numerical fidelity and the BPCells fast precision operating point.** Panels show matrix error, four saved product errors, retained-triplet residual, singular-value error and left/right angles for the four confirmatory targets. Dashed lines mark 10⁻⁶ matrix/product/singular criteria, 10⁻⁸ triplet criterion and gap-conditional 10⁻⁶-radian angle criterion. Triplet residuals use the retained singular-value norm; both absolute directions appear in Supplementary Figure S2. Fast BPCells passes matrix/products but exceeds the stricter triplet criterion in twelve completed pipelines; this does not assess general accuracy or biological utility. Eight R matrix checks, reused across 24 R pipelines, are plotted once each. Other points are technical repetitions, not independent datasets or confidence intervals. Only the final output of each product timing batch was verified. Large Scanpy targets have no error points after preflight refusal. Agreement is against a streamed binary64 target, not a floating-point certificate or atlas-scale evaluation.

Alt text: Nine panels retain matrix, four product, triplet, singular-value and two angle quantities. Fast BPCells passes matrix/products but exceeds the stricter triplet threshold in twelve pipelines. Eight reused R matrix checks are shown once each; large Scanpy targets lack evaluated points.


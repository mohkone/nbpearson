# Admission locale des fichiers manuels

**Décision finale : DATA HOLD documentaire pour les deux sources.**
Les deux matrices filtrées passent les contrôles techniques locaux. Aucun
problème de comptes ou de correspondance de version n’a été trouvé ; le point
restant est le reçu d’acquisition requis par le protocole gelé, pas un besoin
de refaire les contrôles de comptes ou les téléchargements.

## Fichiers effectivement présents et contrôlés

| Source/fichier | Taille exacte | SHA-256 | Nature et dimensions |
|---|---:|---|---|
| PBMC — 10k_PBMC_3p_nextgem_Chromium_X_filtered_feature_bc_matrix.h5 | 39503734 octets | 42a789ff3f92f0e117d1ff4ffcb2fa8edee87dd2a03d83a81502709344a38bf0 | Matrice10x HDF5 CSC,36601 caractéristiques×11996 observations ;27164608 comptes stockés,int32 |
| Mouse — 10k_Mouse_Brain_CNIK_3p_nextgem_10k_Mouse_Brain_CNIK_3p_nextgem_count_sample_filtered_feature_bc_matrix.h5 | 29889377 octets | 895365af6c20b7a1dd80604ef19f1f963fc3b3c7738ba1589d49cf64651f62fe | Matrice10x HDF5 CSC,33696 caractéristiques×9684 observations ;20748068 comptes stockés,int32 |
| Mouse auxiliaire — 10k_Mouse_Brain_CNIK_3p_nextgem_10k_Mouse_Brain_CNIK_3p_nextgem_count_sample_molecule_info.h5 | 274859357 octets | 5c125c32452498d47995bebf3eb6ed8c0dede6a5accb399ec80728d2b1654f27 | HDF5 de molécules,filetype=molecule,file_version6 ; aucune matrice caractéristiques×observations |

Les fichiers ont été ouverts en lecture seule, sans déplacement ni modification.
Les noms,tailles,mtime et hashes des trois payloads ont été vérifiés avant/après.
[FILE_INVENTORY.csv](FILE_INVENTORY.csv) et [local_checks.json](local_checks.json)
conservent les détails ; aucun identifiant individuel n’est imprimé.

## Contrôles des deux matrices filtrées : PASS

Lecture de tous les comptes et indices par blocs de1000000 éléments, sans
densification. Pour chaque matrice : longueurs data/indices concordantes,
indptr de longueur N+1 monotone,de0 à nnz ; indices valides et strictement
croissants dans chaque colonne. L’orientation est **caractéristiques×observations,
CSC**, non observations×gènes dans le fichier source.

Tous les comptes stockés sont int32,finis,entiers et strictement positifs :
aucune valeur négative,fractionnaire,non finie ni zéro stocké. Minimum1 ;
maximum PBMC21233,Mouse4506. Cette observation et le schéma natif sont cohérents
avec des comptes UMI non normalisés ; l’intégralité seule ne prouve pas
l’historique de transformation.

- **PBMC :** software_version=cellranger-6.1.0,library_ids contenant
  10k_PBMC_3p_nextgem_Chromium_X,GRCh38,36601 Gene Expression.
  Les11996 observations concordent avec la notice gelée.
- **Mouse :** software_version=cellranger-8.0.0,library_ids contenant
  10k_Mouse_Brain_CNIK_3p_nextgem,GRCm39,33696 Gene Expression.
  Les9684 observations concordent avec **NextGEM**,sans substitution GEM-X11357.
- Barcodes et identifiants stables des caractéristiques sont uniques et non vides.
  Les noms de gènes comportent10 répétitions PBMC et26 Mouse : ils ne sont pas
  fusionnés. La future règle de tri par identifiant stable n’est pas appliquée ici.
- Les jeux HDF5 requis ont été lus avec succès, sans références externes/virtuelles
  pour ces jeux. Cela vérifie leur lisibilité/structure ; ce n’est pas une
  authentification indépendante des octets par le fournisseur.

Le fichier molecule_info a été haché et ses en-têtes/types/dimensions de tables
inspectés, **pas ses données moléculaires intégralement validées comme matrice**.
Il n’est pas la sortie demandée et n’est pas nécessaire à l’évaluation gelée.
Ses274859357 octets dépassent en outre le plafond d’acquisition128Mio ; cette
exclusion ne constitue pas un défaut de la matrice Mouse filtrée de29,9Mo.
Voir [MOLECULE_FILE_METADATA.json](MOLECULE_FILE_METADATA.json).

## Information supplémentaire fournie par l’opérateur

[Verbatim operator-message excerpt omitted from this documentary access derivative.]

La MD5 locale de la matrice Mouse est **ab4c53b314ceed83f722cd1771b4b275** :
elle correspond exactement à cette chaîne de32 caractères. La taille locale
29889377 octets est cohérente avec29.9MB décimaux arrondis. Il s’agit d’un
rapprochement supplémentaire avec la ligne de sortie fournie par l’opérateur ;
le libellé de l’algorithme du checksum n’était pas inclus dans le message.
Le SHA-256 local reste l’identifiant de conservation distinct.
Aucune reconsultation web n’a été faite pendant cette mission.
Voir [OPERATOR_SUPPLIED_OUTPUT_ROW.json](OPERATOR_SUPPLIED_OUTPUT_ROW.json).

## Admission finale et pièces restant à documenter

| Source | Technique | Rattachement aux sources gelées | Décision |
|---|---|---|---|
| PBMC10k | PASS | Nom,version6.1.0,library,GRCh38 et11996 observations concordants ; URL candidate déjà documentée, mais aucun reçu ne relie encore explicitement ce transfert manuel aux octets reçus | DATA HOLD documentaire |
| Mouse NextGEM10k | PASS ; MD5 candidate fournie concordante | Nom,version8.0.0,library NextGEM,GRCm39 et9684 observations concordants ; ligne de sortie29.9MB fournie,mais URL exacte de cette sortie non enregistrée | DATA HOLD documentaire |

Le [protocole gelé](../../nbpearson_confirmatory_v1/CONFIRMATORY_PROTOCOL.md),
rubrique Admission and sources, requiert avant usage : sortie/version officielles,
taille annoncée/HTTP,reçu de transfert borné et SHA-256. Les tailles locales des
deux matrices sont sous128Mio ; elles ne documentent pas à elles seules la
taille annoncée ni la durée maximale de60s du téléchargement manuel.

**Pièce précise attendue de l’opérateur :** reçu existant ou déclaration attribuée
précisant pour chaque matrice l’URL exacte,la source de la taille annoncée,les
dates/durée et les conditions du transfert manuel. Pour Mouse,relier la ligne
fournie à la notice NextGEM gelée et à son lien de sortie exact. Ne pas déduire
ces informations du mtime,de la vitesse de validation ou d’un nom de fichier.
Si la borne historique n’est pas documentable,conserver cette inconnue ou faire
décider explicitement son traitement ; aucune exception n’est inventée ici et
le protocole n’est pas modifié. Un nouveau téléchargement n’est pas demandé.

## Portée, ressources et conservation

La validation principale a utilisé l’interpréteur déjà disponible,Python
3.12.3,NumPy2.5.4,h5py3.16.0,
HDF52.0.0,un thread BLAS/OpenMP. Reçu :
[execution_receipt.json](execution_receipt.json),code0,durée
1.559s,pic RSS observé
118382592 octets,contrôle toutes les50ms,
plafonds512Mio et300s non déclenchés. L’échantillonnage n’est pas une garantie
instantanée ; la préinspection et le rapprochement MD5/métadonnées auxiliaires
restent distincts de cette durée principale. Ce n’est pas un benchmark.

Les889 fichiers protégés consultés/repris dans le contrôle d’intégrité
restent identiques,y compris dev1 et son wheel,rev3,V2.1,le protocole confirmatoire,
les27 pipelines synthétiques et les anciens rapports DATA HOLD. Les trois
payloads manuels sont identiques avant/après. Seul ce nouveau sous-dossier a été
écrit. Aucun benchmark,ACP,expérience synthétique,installation,téléchargement,
calcul de marges,sélection,normalisation ou HVG.

Reçu d’admission : [ADMISSION_RECEIPT.json](ADMISSION_RECEIPT.json).
**Les fichiers sont techniquement conformes ; DATA READY FOR FROZEN EVALUATION
n’est pas encore établi sous le contrat documentaire inchangé.**

# Reviewer scientific-access instructions

**REVIEWER_ACCESS: NOT_PROVISIONED.** These are inspection instructions for a local candidate, not an invitation, access credential or claim of delivery. No journal, reviewer or external host has been contacted. All four authors' project approval remains accepted.

## What would be supplied after authorization

The exact selection is [../](../), governed by [SCIENTIFIC_ACCESS_FILE_MANIFEST.json](../SCIENTIFIC_ACCESS_FILE_MANIFEST.json). Its identical embedded manifest, portable `verify_manifest.py`, README, documentation, indices and materials can travel as one directory. Internal verification/author-workspace files are outside that proposed recipient selection. No entire reviewer archive, dependency runtime or raw count matrix is implicitly included.

From any directory, using standard-library Python 3.10+:

```bash
python3 /path/to/../verify_manifest.py
```

The verifier checks exact paths, sizes and SHA-256, then prints a result. It does not import numerical software, execute scientific scripts, regenerate figures or write receipts. An eventual authorized recipient must compare the manifest hash with a separately communicated authenticated value and retain their actual retrieval/check receipt. This task checks relocation locally, which is not recipient access.

## Inspection order

1. Read the coverage and rights documents, then open `indices/PIPELINE_EVIDENCE_INDEX.json` inside the candidate. Each of the 72 entries identifies source/target/method/repetition, planned/observed settings, CSV row locators, target identities and recorded outcomes. Follow the staged `candidate_path` fields; source hashes are historical identities and `candidate_sha256` identifies the actual delivered derivative/copy.
2. For each of 66 completed runs, inspect `pipeline.json`, its guarded `receipt.json` and `products.csv`, then the separate `*_verify/verification.json` and verification guard receipt. Keep construction/PCA time distinct from whole-child elapsed time, sampled RSS and verification-process resources. The eight R matrix proofs are shared across 24 native pipelines; do not count them as 24 independent matrix measurements.
3. Inspect two first-repetition Scanpy memory-preflight records and the four subsequent nonlaunch entries in the execution manifest. Exit 0 of an admission process is not a completed PCA; none of these six plans is an observed OOM or a measured accuracy point. Retain the 12 native-fast triplet failures, nine angle failures and adverse timing/storage observations.
4. Use `indices/SOURCE_TO_TARGET_IDENTITIES.json`, target `input.json`, axes, indices, frozen margin/probe files and the preparation script/protocol to understand the four original targets. Raw source and target count matrices are withheld. Actual target rebuilding first requires lawful access to the exact hashed sources, with current source retrieval verified separately.
5. Inspect final manuscript/addendum tables and eight PDFs against pinned CSVs/source maps, original scalar source tables and saved table/addendum trace records. `indices/REFERENCE_RESOLUTION.json` resolves original figure-source identities to staged paths and marks historical-link limitations. Existing plots/scalars can be inspected without rendering or running an SVD.

## Four distinct scopes

| Level | Selection supports | Boundary |
| --- | --- | --- |
| A | Independent inspection of every recorded completed outcome and all six noncompleted plans | It supplies saved validation/scalar records, not independent recalculation of numerical errors from omitted arrays |
| B | Documentary verification of table cells, saved figure scalar sources, plotted selections/units and exact production PDFs | No new figure generation, full historical raw-data recomputation or novel visual approval is claimed |
| C | Documented preparation method, exact axes/indices/margins and fingerprints for all four targets | Conditional on lawful access to the exact source HDF5s and compatible preparation dependencies; actual acquisition/reconstruction unperformed |
| D | Inspection of original campaign code/settings/environment receipts | Full rerun kit **INCOMPLETE**: withheld counts/outputs, machine-bound guard/runtime/install paths, scientific environment and fresh-output execution setup remain unresolved |

Only the last output of each ten-call timed product lot was saved historically; the other nine arrays cannot be recovered from timing receipts. A1 does not restore missing historical acquisition metadata, authenticate provider origin or supply ethics/redistribution clearance.

## Exact next access action

The investigator/data custodian and relevant owners must authorize this exact manifest and its material-specific terms, attribution/changes and ethics/privacy scope. A designated host operator may only then provision a journal-compatible route with scope/duration/custodian. Required evidence is the real access identifier, authorized selection hash and actual recipient retrieval/hash receipt. No additional scientific rerun or independent external tester is required by this material-selection task. No transfer or follow-up action starts automatically.

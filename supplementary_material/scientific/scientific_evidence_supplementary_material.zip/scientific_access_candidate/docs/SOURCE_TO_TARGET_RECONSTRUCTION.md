# Source-to-target reconstruction

Scope: documentary reconstruction method for the four real confirmatory targets; no acquisition, array calculation or numerical rerun occurred. All original files remain unchanged. **BIOLOGICAL_TARGET_RECONSTRUCTION: DOCUMENTED**, conditional on lawful access to the exact source bytes identified below. This describes a complete recorded selection/preparation route; it does not establish that an external reviewer has obtained those bytes or that historical transfer provenance has been recovered.

The scientific-access selection contains the existing axis identities, original indices/exclusions, fixed margins, probes/configuration and preparation records/scripts. It deliberately omits the two original HDF5s and each target's `counts.npz` / `counts_gene_by_obs.mtx`. Those count payloads remain local. A reviewer must obtain the exact source bytes lawfully or receive a separately authorized count-payload selection before actually rebuilding the target counts. A matching source-page link alone is insufficient.

## Source identities and lawful access condition

| Source | Official resource and saved identity | Acquisition limitation |
| --- | --- | --- |
| `pbmc_10k` | 10x Genomics “10k Human PBMCs, 3′ v3.1, Chromium X”, Cell Ranger 6.1.0; resource page `https://www.10xgenomics.com/datasets/10k-human-pbmcs-3-ht-v3-1-chromium-x-3-1-high`. Saved filtered HDF5: 39,503,734 bytes; SHA-256 `42a789ff3f92f0e117d1ff4ffcb2fa8edee87dd2a03d83a81502709344a38bf0`; 36,601 features × 11,996 observations. | A1 records a known corresponding filtered-count URL, not the original manual transfer URL-to-bytes binding. Current exact-byte provider retrieval is not tested here. |
| `mouse_brain_nextgem_10k` | 10x Genomics “10k Mouse Brain Nuclei, CNIK, 3′ NextGEM”, Cell Ranger 8.0.0; resource page `https://www.10xgenomics.com/datasets/10k-Mouse-Brain-CNIK-3p-nextgem`. Saved filtered HDF5: 29,889,377 bytes; SHA-256 `895365af6c20b7a1dd80604ef19f1f963fc3b3c7738ba1589d49cf64651f62fe`; 33,696 features × 9,684 observations. | Exact historical filtered-count URL is unknown. Use the official resource to seek lawful exact source access, checking the hash; do not guess an historical URL or substitute a different matrix silently. |

The recorded PBMC corresponding-count URL is `https://cf.10xgenomics.com/samples/cell-exp/6.1.0/10k_PBMC_3p_nextgem_Chromium_X/10k_PBMC_3p_nextgem_Chromium_X_filtered_feature_bc_matrix.h5`. It was not fetched in this task. The Mouse molecule-info HDF5 is not a confirmatory input. Retain resource-specific terms/credit and describe transformations; this package supplies no new redistribution permission or ethics decision.

Both existing local HDF5s were rehashed and match these saved identities. Hash matching establishes local byte identity, not authenticated historical provider origin. If a lawful source retrieval has different bytes, stop treating it as the frozen input: record the mismatch rather than invent an equivalence or replace the frozen target.

## Exact preparation route

The active original is `nbpearson_confirmatory_real_v1/prepare_real_r2.py`, SHA-256 `6e35cf87f5a758eabe94b157521373ddd3040729cf5cd65bc66884c15823103b`. The first attempt `prepare_real.py` and its failure receipt remain part of the preparation-history record. `PREPARATION_HARNESS_AMENDMENT.json` explains the optional SciPy Matrix Market extension's late thread-pool registration and its preload correction; the scientific selection, seeds and thresholds did not change. Active outputs are `inputs_r2/`, not the partial first `inputs/` tree.

The script's only project-file input before source reading is `nbpearson_data_recovery_v1/provenance_resolution_v1/approval_a1_v1/APPROVAL_RECEIPT.json`, resolved relative to its project root. It requires A1's admitted status and explicit Mouse missing-URL acceptance; each source's relative file path, byte size, SHA-256 and expected dimensions come from that receipt. The selected receipt is a labelled privacy derivative, with original identity retained; removing a raw message does not change source/admission fields, but the derivative has its own hash and is not the historical original receipt.

For each resource, the frozen method is:

1. Interpret the original HDF5 `matrix` group as CSC features × observations. Check unique stable feature IDs and barcodes, explicit `Gene Expression` type, valid canonical indices and finite nonnegative integer counts. Read selected CSC columns in bounded slices of at most 1,000,000 entries / 128 columns; no full count or residual densification is part of preparation.
2. Sort observations by the SHA-256 digest of UTF-8 `NBPEARSON-CONFIRMATORY-V1|` plus the exact barcode, resolving digest ties by the exact barcode. Select the first `min(1000, available)` observations for `common_small` and `min(10000, available)` for `larger`.
3. Within each target's selected observations, retain eligible Gene Expression features with positive counts. Sort their exact stable IDs and take the first 1,000 or 2,000 respectively. This is target-specific positive-feature selection; it is not HVG selection, normalization, log1p or model fitting.
4. Build canonical binary64 CSR observations × genes. Remove only resulting zero rows/columns, with no replacement. Save retained/pre-exclusion indices and removals. PBMC larger removes selected row position 7,232 (zero based), source observation index 817, leaving 9,999 rows. No other target loses a row or column.
5. Compute fixed margins once on each final universe: `depth = CSR.sum(1)`, gene totals `t = CSR.sum(0)`, `M = NumPy.sum(t)`, `p = t/M`, all in binary64. Save `parameters.npz`, `depth.tsv`, `proportion.tsv`; preserve those frozen values for comparisons instead of recomputing on a different universe or using newly fitted margins.
6. Generate the original Gaussian normalized product probes with NumPy `default_rng(71305)`: `v`, `w`, and width-eight `V`, `W`. Save probe arrays and 17-significant-digit text exports. Save theta=100, clipping threshold `sqrt(N)`, N and G. Clipping precedes gene centering in later methods and is not applied to the saved counts.
7. Export genes × observations Matrix Market counts for R, with the same fixed binary64 margins/probes exported using `%.17g`. Native R receipts record little-endian binary64 parameter-roundtrip checks. Save axes (`observations.tsv`, `genes.tsv`), `selection_indices.json`, metadata, preparation preflight and `input.json` / `REAL_DATA_PREPARATION.json` hashes.

This recipe is the recorded original behavior, not a new recommended analysis. The axis files and selection indices give exact retained identities and ordering, not just a random-seed description. The preparation record hashes all 64 target files (16 per target); this task verified all 64 hashes without opening or recalculating their scientific arrays.

## Frozen targets and semantic fingerprints

| Target | N × G / nnz / distinct depths | Saved count fingerprint | Saved fixed-margin fingerprint |
| --- | --- | --- | --- |
| `pbmc_10k_common_small` | 1,000 × 1,000 / 164,880 / 567 | `67bd2c44781100793b1906bb121c4f44b382856c2e7f60c3ea2748d3f907ac32` | `e5cc6b54d20a9b93f72e4a7ab60c9c86dbc727d67a7f587e78a0b72839be88dd` |
| `pbmc_10k_larger` | 9,999 × 2,000 / 3,159,138 / 2,354 | `c65db0a83027fd2c07ff1c651ad3018cf71f775f4a06510591fe8e467186cbd1` | `6907b19651fffb827f55bc8f97d4eac93c6f91b3d9d4f3b95c116583d76050c0` |
| `mouse_brain_nextgem_10k_common_small` | 1,000 × 1,000 / 122,789 / 418 | `c439b0921dec188eaf74b57950693ef34d388e9825a1bb00532b016dc116e407` | `5f7ae74bd7957cf9bc1736993ed0c37b68d68323f9b7cf4ec17078f374cae78c` |
| `mouse_brain_nextgem_10k_larger` | 9,684 × 2,000 / 2,228,468 / 1,391 | `3be5f12975717e66e0c7412ee4e366b19dcf8d461f7b9e5c531a15b144553f3b` | `1d9afca68a53543e0c86fa98181ed44283105a3a31b53fa40e877ca1e2347cd0` |

These semantic fingerprints are copied from the saved `interpolated_r1/pipeline.json` package diagnostics for each target, not newly calculated. Distinguish them from SHA-256 of NPZ container bytes: count/margin semantic fingerprints, file hashes, source HDF5 identities and row/gene identity files serve different checks. `../indices/SOURCE_TO_TARGET_IDENTITIES.json` records their precise provenance plus the complete target-file hashes.

## Recorded runtime and portability limits

Preparation records NumPy 2.5.4 and h5py 3.16.0; saved campaign receipts record Python 3.12.3 and SciPy 1.18.1. The script also requires threadpoolctl and SciPy's private `scipy.io._fast_matrix_market._fmm_core`; its exact preparation-time threadpoolctl version is not recorded in `REAL_DATA_PREPARATION.json`. It preloads that optional extension before `threadpool_limits(1)`. Every registered numerical pool must be single-threaded during Matrix Market export. RSS inspection uses Linux `/proc/self/status`; this is not a platform-independent preparation harness.

The original r2 preparation process completed with exit 0. Its documented options were `--output-root .../inputs_r2 --phase-output .../runs/real_preparation_r2`, with the default preparation receipt path. A future authorized reconstruction must use a fresh output directory and fresh receipt filename (`--receipt`) because the script refuses existing receipts and target directories; its phase directory must exist. Relative approval/source locations must be resolved as documented. No preparation command was executed in this task.

Full campaign execution is a separate level. The original `guard.py` hardcodes a host Python environment, a temporary installed nbpearson location and the local R runtime. Existing campaign ledgers/run directories also intentionally prevent repeat writes. The machine-bound guard is omitted from executable source selection; the unchanged campaign runner is supplied for inspection and still depends on that guard. No tested portable launcher is supplied. Third-party runtimes are not automatically bundled. **The selected static evidence package is not a complete executable reproduction of the campaign.**

## A1 limitations retained

A1 admitted exactly the two hashed sources on the attributed investigator declaration and explicitly accepted the missing exact Mouse filtered-count URL. It did not restore exact transfer URL-to-bytes bindings, start/end/duration, attempts, HTTP status/redirects or Content-Length. It did not independently authenticate provider origin, confer redistribution rights, decide ethics/consent or change numerical criteria. No file mtime, current source page or preparation output can retrospectively fill those gaps. The selected privacy derivative retains admission conditions and unknowns while omitting verbatim private-message text.

The documentary reconstruction classification therefore concerns the **specified method and identities**. Actual reviewer target reconstruction remains conditional on lawful exact-source acquisition and the required runtime; actual reviewer access remains **NOT_PROVISIONED**. Unavailable historical provenance stays incomplete even if all four target counts can later be rebuilt.

## Candidate navigation

From this report, the candidate workspace mirror is `../materials/`. Append the workspace-relative original paths above to that mirror. The frozen software tree is separately under `../software/nbpearson/`. Resolve every original versus staged hash using `SCIENTIFIC_ACCESS_FILE_MANIFEST.json`; absolute host metadata is suppressed only in labelled documentary derivatives. The reconstruction identity index supplies hashes for all target files, explicitly distinguishing included files from withheld count matrices through the manifest.

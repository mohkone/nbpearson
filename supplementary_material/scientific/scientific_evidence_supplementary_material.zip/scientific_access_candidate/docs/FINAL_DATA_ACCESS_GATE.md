# Final scientific data-access decision

Prepared 17 November 2026, Asia/Shanghai. Frozen software: nbpearson **0.1.0.dev1**, commit **`c0f41107f888d69713c8e22e488bf1e7386f8c4d`**. All original artifacts remain unchanged.

| Decision | Exact result | Meaning |
| --- | --- | --- |
| SCIENTIFIC_EVIDENCE_COVERAGE | **COMPLETE** | The bounded selection accounts for all 66 completed pipeline outcomes and all six noncompleted plans, with original settings, targets, scalar accuracy/validation, timing/RSS receipts and adverse outcomes. It includes the table/figure scalar-source chain. Completeness is for saved-outcome inspection, not numerical re-execution. |
| BIOLOGICAL_TARGET_RECONSTRUCTION | **DOCUMENTED** | All four targets have a specified preparation route, exact axis/selection identities, fixed margins, fingerprints and source identities. Actual reconstruction is conditional on lawful matching source access and compatible dependencies; no source retrieval or reconstruction was performed. Historical acquisition provenance remains incomplete under A1. |
| RIGHTS_REVIEW | **READY_FOR_HUMAN_AUTHORIZATION** | A bounded local selection, classifications, omissions and privacy transformations are concrete and reviewable. No distribution authority, ethics decision or blanket licence is inferred. Withheld matrices/biological output arrays/runtimes are outside this authorization unit. |
| REVIEWER_ACCESS | **NOT_PROVISIONED** | No recipient route, invitation, transfer, deposit or retrieval receipt exists from this task. Local hash/relocation PASS is not actual reviewer access. |

The earlier data hold's missing **inspection-material selection** is resolved by this assembly. Its delivery/access condition is not resolved by local work. The selection supports A (all recorded outcome inspection) and B (documentary tables/figure-source verification); C is a documented conditional reconstruction route; D (full executable campaign reproduction) remains **INCOMPLETE**. Do not relabel this static evidence package as a full campaign reproduction.

## Remaining actions and required evidence

| Exact remaining action | Responsible party | Required evidence |
| --- | --- | --- |
| Review and authorize the exact scientific-access selection and material-specific rights/attribution/changes, actual privacy/secondary-data ethics scope and distribution terms | Investigator/data custodian, relevant material owners and corresponding author | Signed or otherwise recorded human authorization bound to the manifest SHA-256; actual rights/privacy/ethics basis where applicable. Collective project approval is already accepted and is not reopened. |
| Provision an appropriate reviewer route only after authorization, then verify actual recipient retrieval | Designated authorized host operator and corresponding author; eventual intended recipient | Real route/access identifier, exact file scope, duration/custodian, separately conveyed manifest identity and recipient-side complete retrieval/hash receipt. No scientific rerun is required for this access check. |
| If actual target rebuilding or full campaign rerun is later sought, separately resolve lawful exact sources/withheld payloads, preparation dependencies and machine-specific execution setup | Data steward and campaign maintainers, under a separately authorized scope | Exact lawful source-byte retrieval hashes or authorized input deposit, environment/setup record and usable fresh-output execution instructions. This is a scope boundary, not a new task initiated here. |

[SCIENTIFIC_ACCESS_FILE_MANIFEST.json](../SCIENTIFIC_ACCESS_FILE_MANIFEST.json) governs the exact candidate; [coverage](PIPELINE_EVIDENCE_COVERAGE.md), [reconstruction](SOURCE_TO_TARGET_RECONSTRUCTION.md), [rights/omissions](RIGHTS_AND_OMISSIONS_LEDGER.md) and [instructions](REVIEWER_SCIENTIFIC_ACCESS_INSTRUCTIONS.md) supply the basis. The internal verification record retains original/staged hashes, source preservation, privacy corrections, per-configuration coverage and relocation checks. No numerical experiment, benchmark, software modification, new biological download, GitHub operation, external sharing, DOI or journal submission occurred. Work stops at the four decisions above.

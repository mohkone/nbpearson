"""Read-only portable file-identity check; standard-library Python 3.10+."""
from pathlib import Path, PurePosixPath
import hashlib
import json


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'SCIENTIFIC_ACCESS_FILE_MANIFEST.json').read_text())
    expected = {'SCIENTIFIC_ACCESS_FILE_MANIFEST.json'}
    errors = []
    for row in manifest['files']:
        relative = PurePosixPath(row['candidate_path'])
        if relative.is_absolute() or '..' in relative.parts:
            errors.append({'path': str(relative), 'error': 'unsafe path'})
            continue
        expected.add(str(relative))
        path = root / str(relative)
        if path.is_symlink() or not path.is_file():
            errors.append({'path': str(relative), 'error': 'missing file or symlink'})
            continue
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1048576), b''):
                digest.update(chunk)
        if path.stat().st_size != row['bytes'] or digest.hexdigest() != row['sha256']:
            errors.append({'path': str(relative), 'error': 'identity mismatch'})
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if actual != expected:
        errors.append({'error': 'unexpected or missing paths',
                       'paths': sorted(actual ^ expected)})
    print(json.dumps({'pass': not errors, 'listed_files_checked': len(manifest['files']),
                      'errors': errors, 'scientific_executions': 0,
                      'scope': 'Local identity only; not public/reviewer availability or numerical recomputation'}, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == '__main__':
    main()

"""Check the supplement file identities using only the standard library."""
import hashlib
import json
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    manifest = root / "FILE_MANIFEST.json"
    sums = {}
    for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        sums[name] = digest
    if hashlib.sha256(manifest.read_bytes()).hexdigest() != sums[manifest.name]:
        raise SystemExit("FAIL: FILE_MANIFEST.json identity")
    data = json.loads(manifest.read_text(encoding="utf-8"))
    for row in data["files"]:
        name = row["path"]
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise SystemExit("FAIL: unsafe manifest path")
        path = root / relative
        if not path.is_file() or path.is_symlink():
            raise SystemExit("FAIL: missing or symbolic file " + name)
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if path.stat().st_size != row["bytes"] or digest != row["sha256"] or digest != sums[name]:
            raise SystemExit("FAIL: file identity " + name)
    print(json.dumps({"status": "PASS_FILE_IDENTITIES", "checked_payload_and_wrapper_files": len(data["files"]), "numerical_execution": False}, sort_keys=True))


if __name__ == "__main__":
    main()

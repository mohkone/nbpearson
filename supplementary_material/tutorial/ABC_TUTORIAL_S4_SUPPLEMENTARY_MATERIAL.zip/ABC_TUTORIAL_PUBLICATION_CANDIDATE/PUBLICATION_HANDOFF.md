# Exact supplementary publication / upload handoff

Status: **PACKAGE_PREPARED_AWAITING_PUBLIC_ACCESS**. No upload or external transfer is authorized by this editorial mission.

Proposed submission label: **Supplementary File S4 — Full A/B/C reproducibility tutorial**. The payload is the complete directory containing this file, with the relative layout preserved, governed by `FILE_MANIFEST.json` and `SHA256SUMS`. No existing GitHub source tree, tag or release is to be changed, retagged or recreated.

1. Corresponding author and software owner review the nine unchanged original payload files, new wrappers, notices and exact manifest. Approve their redistribution and the intended journal-compatible immutable supplement/archive destination. Confirm that current software distribution authority covers the exact historical evaluated wheel (whose original notice records an earlier unresolved permission state), the prepared MIT V2 wheel, selected tutorial and synthetic fixture. Preserve the distinct historical notices; do not infer retroactive authorization from matching modules. No dependency binary or third-party biological payload is selected.
2. An authorized human creates the deposit or journal supplement upload from these exact files. The prepared ZIP is `ABC_TUTORIAL_S4_PUBLICATION_CANDIDATE.zip`, adjacent to this directory. Its byte count and SHA-256 are recorded in the internal verification report `ABC_TUTORIAL_IDENTITY_CHECK.json` and the overall final-file manifest. Use those exact bytes after approval. The internal file manifest remains unchanged. Supply an immutable version identifier and accessible file/landing-page URL. Do not attach this supplement by changing GitHub release `v0.1.0`.
3. Retrieve the deposited version through the intended reader route into a separate recipient directory; save the request/download evidence, final URL and timestamp. Compare all payload and manifest hashes and run the standard-library `verify_manifest.py`. Retain the resulting check. No new numerical run is required by this handoff.
4. Record whether access is public or journal-restricted and whether the intended recipient can retrieve every listed file. Only then replace the non-URL placeholder below in the manuscript/supplement mapping and sign the exact approved final-file list.

Proposed citation, pending deposit: “Full A/B/C reproducibility tutorial for nbpearson 0.1.0.dev1. Supplementary material to the nbpearson Technical Note. [IMMUTABLE SUPPLEMENT IDENTIFIER AND VERIFIED URL TO BE INSERTED AFTER AUTHORIZED DEPOSIT].” Creator list, date, repository, DOI and any citation-export fields must come from the final authorized deposit, not inference. This placeholder is intentionally not a hyperlink and is not evidence of publication.

Record for completion by the authorized depositor:

| Field | Required entry |
|---|---|
| Exact approved manifest hash | Copy SHA-256 of FILE_MANIFEST.json from SHA256SUMS |
| Rights/content approver and date | Uncollected |
| Destination and access mode | Undecided |
| Deposit version identifier / official citation | Unavailable until deposit |
| Candidate archive | ABC_TUTORIAL_S4_PUBLICATION_CANDIDATE.zip; exact size/hash in final-file manifest; not uploaded |
| Recipient URL, retrieval timestamp and evidence | Not provisioned |
| Recipient manifest check and discrepancies | Not performed |
| Corresponding-author approval of final manuscript pointer | Uncollected |

The unrelated public C-only example is `examples/operator_products.py` in <https://github.com/mohkone/nbpearson/releases/tag/v0.1.0>. The evaluated commit remains `c0f41107f888d69713c8e22e488bf1e7386f8c4d`; release source commit remains `e6ed51e58ddce5f12f39d6a36b59d42f240191ed`; package version is `0.1.0.dev1`.

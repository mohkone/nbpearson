# Provenance and distribution decisions

This internal prerelease extracts local numerical code from NB-PCA v3/v4/v5,
v8 and v9, with its function-level map and original file hashes recorded in
`validation/SOURCE_MAP.json`. The archives remain the authoritative historical
record. Source headers describe established interpolation/LinearOperator
techniques and disclaim novelty and biological validation; those limitations
remain in force here.

No explicit public license grant, third-party validation, institutional
affiliation or DOI was found in the extracted local files. This document does
not invent any such grant. Rights, authorship attribution and redistribution
permission must be settled before external distribution. No publication is
authorized by the local wheel build.

NumPy and SciPy are runtime dependencies, retaining their own license and notice
requirements. Their source or site-packages are not copied into this package.
The code calls SciPy's BarycentricInterpolator, LinearOperator and sparse matrix
interfaces; their algorithms are not claimed as original work. The example
calls SciPy's existing svds solver. Classical approximation, rationalization,
compensated arithmetic, sparse-plus-low-rank and grouping identities are not
new mathematical results from packaging.

# Frozen expected results and interpretation

The authoritative numeric output is the unchanged `expected/verified_outputs.json`; it is not newly calculated. The original script's `--expected` comparison checks dictionary structure and nonfloating values exactly, and floating expected values with `rtol=1e-10`, `atol=2e-10`. Product/direct-formula assertions and singular-triplet criteria are separately coded in the unchanged script. Passing one contract does not replace another.

Expected terminal JSON contains `status=PASS_THREE_REPRESENTATIONS_FOUR_PRODUCTS_AND_EXTERNAL_SVD`, `expected_values_checked=true`, `version=0.1.0.dev1`, `shape=[16,3]`, `floating_validation=NOT_EVALUATED`; successful process exit is 0.

| Recorded item | Frozen value or interpretation |
|---|---|
| Synthetic counts | 16 × 3, int64 CSR, 40 nonzeros; original input unchanged |
| Model and target | theta=100, clip=10; clipping then column centering; no gene scaling |
| Margins | Original depths and proportions calculated once and supplied to A/B/C |
| Four products | matvec, rmatvec, matmat, rmatmat; shapes [16], [3], [16,2], [3,2] |
| A/B selection | matrix_rtol=1e-6, max_nodes=128; recorded interpolation nodes=9 |
| C selection | exact_grouped, no interpolation |
| Direct leading singular value | 5.354855829962119 |
| Operator-owned storage | A=1940 bytes, B=1164 bytes, C=804 bytes; not total RAM |
| Structural limitation | Fixture is rank one with no active clipping; not a biological benchmark |
| Numerical limitation | Analytic interpolation selection is not a floating-point certificate; floating_validation stays NOT_EVALUATED |

The saved Linux receipts establish prior functional PASS; investigator-led Windows PASS is reported within its recorded scope. This package preparation only verifies file identities and does not repeat those validations. Resource or timing results are not generalized from this fixture. This example does not reproduce all 66 completed biological pipelines.

# Full A/B/C reproducibility tutorial — supplementary publication candidate

**Supplementary File S4 — Full A/B/C reproducibility tutorial. Status: PACKAGE_PREPARED_AWAITING_PUBLIC_ACCESS.** This directory is a local candidate; no deposit, public URL or recipient access is established. The nine scientific/software payload files are unchanged frozen originals. New wrapper documents and the standard-library integrity checker make this selection standalone. No installation or numerical execution was performed when preparing it.

## Which example is this?

The public GitHub release `v0.1.0` at <https://github.com/mohkone/nbpearson/releases/tag/v0.1.0> contains `examples/operator_products.py` and `examples/expected_operator_products.json`: a C-only (`exact_grouped`) example with counts constructed inline. This separate tutorial loads `fixture/counts_csr.json` and exercises A (`interpolated`), B (`interpolated_grouped`) and C (`exact_grouped`), all four products and an external SciPy SVD. The public example is not the full A/B/C tutorial.

The prepared MIT V2 wheel used by the saved clean-install tutorial is `artifacts/nbpearson-0.1.0.dev1-py3-none-any.whl`, SHA-256 `a3d49b037a0ed3f12581ca686fcdb5f9d23385b8c4ba7dde100cb0c5b62613cc`. It is not rebuilt. The original historical evaluated wheel is separately preserved at `artifacts/historical_evaluated/nbpearson-0.1.0.dev1-py3-none-any.whl`, SHA-256 `6334eb9758d004ba7171b8c430f4b1df9d659ac2327ff152db26905b282238e7` (18,939 bytes), with its applicable original notice. The two archives contain identical five Python modules but have different packaging/metadata. Commands below use the prepared MIT V2 wheel that the clean-install tutorial actually validated; the historical wheel is retained for identity/provenance and is not silently substituted. The evaluated source commit is `c0f41107f888d69713c8e22e488bf1e7386f8c4d`; the release source commit is `e6ed51e58ddce5f12f39d6a36b59d42f240191ed`. The tag is `v0.1.0`; the package version remains `0.1.0.dev1`. All five Python modules in both wheels were checked statically against the frozen evaluated source. Historical README text embedded in this unchanged wheel describes its earlier packaging stage; it is not a current statement of repository visibility.

## Layout and integrity check

`FILE_MANIFEST.json` identifies every payload and wrapper except the manifest itself and `SHA256SUMS`. `SHA256SUMS` also hashes `FILE_MANIFEST.json` and excludes itself. Obtain the manifest hash through the eventual trusted deposit record, then run from this directory:

```sh
python3 -I -B verify_manifest.py
```

On Windows, use `py -3.12 -I -B verify_manifest.py`. This check uses only the Python standard library and performs no numerical work. Retain the manifest and record the download URL, timestamp and result before installing. Expected results and tolerances are in `EXPECTED_RESULTS.md`.

## Dependencies and installation

Use a writable recipient copy and a fresh Python 3.12 virtual environment. Saved Linux validation used CPython 3.12.3, NumPy 2.5.4 and SciPy 1.18.1. Investigator-led Windows 11 validation used Python 3.12.0 and the same dependencies. This is functional validation, not independent-user testing, a general platform guarantee or reproduction of the biological campaign. Original Windows receipt bytes were not available for file-level verification. Linux dependency-wheel acquisition was not independently authenticated.

NumPy/SciPy wheels and Python are not bundled. Obtain the exact pinned versions from an authorized distribution source into `wheelhouse/`, selecting wheels compatible with your Python, OS and architecture. Preserve wheel filenames, checksums, provider and retrieval evidence; inspect the distributions' licences. If unavailable, report an environment/access limitation rather than substituting unrecorded dependencies. The package's Python >=3.10 metadata does not establish validation on all such versions.

The following commands are a recipient procedure and were not run in this editorial task. Linux/macOS shell, from this directory:

```sh
python3.12 -I -m venv .tutorial-venv
.tutorial-venv/bin/python -I -m pip --isolated --disable-pip-version-check install --no-index --find-links wheelhouse --no-cache-dir --no-compile -r requirements-tested.txt
.tutorial-venv/bin/python -I -m pip --isolated --disable-pip-version-check install --no-index --no-deps --no-cache-dir --no-compile artifacts/nbpearson-0.1.0.dev1-py3-none-any.whl
.tutorial-venv/bin/python -I -m pip --isolated --disable-pip-version-check check
mkdir reviewer_outputs
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 .tutorial-venv/bin/python -I -B tutorial.py --expected expected/verified_outputs.json --output reviewer_outputs/outputs.json --diagnostics reviewer_outputs/diagnostics.json
```

Windows PowerShell, from this directory:

```powershell
py -3.12 -I -m venv .tutorial-venv
.\.tutorial-venv\Scripts\python.exe -I -m pip --isolated --disable-pip-version-check install --no-index --find-links wheelhouse --no-cache-dir --no-compile -r requirements-tested.txt
.\.tutorial-venv\Scripts\python.exe -I -m pip --isolated --disable-pip-version-check install --no-index --no-deps --no-cache-dir --no-compile artifacts/nbpearson-0.1.0.dev1-py3-none-any.whl
.\.tutorial-venv\Scripts\python.exe -I -m pip --isolated --disable-pip-version-check check
New-Item -ItemType Directory reviewer_outputs
$env:OPENBLAS_NUM_THREADS="1"
$env:OMP_NUM_THREADS="1"
$env:MKL_NUM_THREADS="1"
$env:NUMEXPR_NUM_THREADS="1"
.\.tutorial-venv\Scripts\python.exe -I -B tutorial.py --expected expected/verified_outputs.json --output reviewer_outputs/outputs.json --diagnostics reviewer_outputs/diagnostics.json
```

Retain stdout, stderr, exit code, outputs and diagnostics, including failed attempts. Compare the output using the script's existing expected-value assertions; independently interpret platform-dependent resource observations. Do not overwrite frozen expected outputs. Installation/import failures and numerical assertion failures are distinct outcomes.

## Rights and scope

`LICENSE`, `THIRD_PARTY_NOTICES.md` and `artifacts/historical_evaluated/THIRD_PARTY_NOTICES.md` are unchanged originals. The historical wheel retains its earlier notice stating that redistribution permission was unsettled at that time; it has not been rewritten. Before any publication, obtain explicit software-owner confirmation that current distribution authority covers this exact historical wheel as well as the MIT V2 payload. MIT applies within the documented nbpearson ownership assertion; Python, NumPy, SciPy and their bundled components retain separate terms. No third-party dependency distributions, biological matrices, campaign payloads, private communications or Windows receipts are included. Proposed publication requires author/content approval and an authorized deposit followed by retrieval verification; see `PUBLICATION_HANDOFF.md`.
